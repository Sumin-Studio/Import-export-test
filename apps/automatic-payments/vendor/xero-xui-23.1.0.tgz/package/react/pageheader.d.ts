import XUIBreadcrumbTrail, { type XUIBreadcrumbTrailProps } from './components/pageheader/XUIBreadcrumbTrail';
import XUIPageHeader, { type XUIPageHeaderProps } from './components/pageheader/XUIPageHeader';
export { XUIPageHeader as default, XUIBreadcrumbTrail, type XUIBreadcrumbTrailProps, XUIPageHeader, type XUIPageHeaderProps, };

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIFixedFooter", {
  enumerable: true,
  get: function () {
    return _XUIFixedFooter.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIFixedFooter.default;
  }
});
var _XUIFixedFooter = _interopRequireDefault(require("./components/fixedfooter/XUIFixedFooter"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=fixedfooter.js.map
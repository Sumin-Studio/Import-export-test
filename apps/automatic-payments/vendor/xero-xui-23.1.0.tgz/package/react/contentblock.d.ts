import XUIContentBlock, { type XUIContentBlockProps } from './components/contentblock/XUIContentBlock';
import XUIContentBlockItem, { type XUIContentBlockItemProps } from './components/contentblock/XUIContentBlockItem';
export { XUIContentBlock, XUIContentBlockItem, type XUIContentBlockItemProps, type XUIContentBlockProps, };

import XUISwitch, { type XUISwitchProps } from './components/switch/XUISwitch';
import XUISwitchGroup, { type XUISwitchGroupProps } from './components/switch/XUISwitchGroup';
export { XUISwitch as default, XUISwitch, XUISwitchGroup, type XUISwitchGroupProps, type XUISwitchProps, };

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIToggle", {
  enumerable: true,
  get: function () {
    return _XUIToggle.default;
  }
});
Object.defineProperty(exports, "XUIToggleOption", {
  enumerable: true,
  get: function () {
    return _XUIToggleOption.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIToggle.default;
  }
});
var _XUIToggle = _interopRequireDefault(require("./components/toggle/XUIToggle"));
var _XUIToggleOption = _interopRequireDefault(require("./components/toggle/XUIToggleOption"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=toggle.js.map
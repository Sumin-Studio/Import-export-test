"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIColumn", {
  enumerable: true,
  get: function () {
    return _XUIColumn.default;
  }
});
Object.defineProperty(exports, "XUIRow", {
  enumerable: true,
  get: function () {
    return _XUIRow.default;
  }
});
var _XUIColumn = _interopRequireDefault(require("./components/structural/XUIColumn"));
var _XUIRow = _interopRequireDefault(require("./components/structural/XUIRow"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=structural.js.map
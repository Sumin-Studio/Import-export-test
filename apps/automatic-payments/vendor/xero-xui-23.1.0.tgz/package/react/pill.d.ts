import XUIPill, { type XUIPillProps } from './components/pill/XUIPill';
export { XUIPill as default, XUIPill, type XUIPillProps };

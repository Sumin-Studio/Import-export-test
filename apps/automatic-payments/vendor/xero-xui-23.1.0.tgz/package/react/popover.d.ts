import XUIPopover, { type XUIPopoverProps } from './components/popover/XUIPopover';
import XUIPopoverBody, { type XUIPopoverBodyProps } from './components/popover/XUIPopoverBody';
import XUIPopoverFooter, { type XUIPopoverFooterProps } from './components/popover/XUIPopoverFooter';
import XUIPopoverHeader, { type XUIPopoverHeaderProps } from './components/popover/XUIPopoverHeader';
export { XUIPopover as default, XUIPopover, XUIPopoverBody, type XUIPopoverBodyProps, XUIPopoverFooter, type XUIPopoverFooterProps, XUIPopoverHeader, type XUIPopoverHeaderProps, type XUIPopoverProps, };

<div class="xui-margin-vertical">
	<a href="../section-components-navigation-tabs.html" isDocLink>Tabs in the XUI Documentation</a>
</div>

## About this pattern

The following terms are used to describe this pattern:

- **Tabs**: A set of tab elements and their tab panels
- **Tablist**: A set of tab elements contained in a tablist element
- **Tab**: An element in the tab list that acts as a label for the tab panel and can be activated to display the panel
- **Tabpanel**: The element containing the content associated with a tab

## When to use

Use tabs when you want to organise and separate related content on a page. Tabs can be used when the content in the tab panels does not follow a sequence, where that content does not need to be viewed together, and where showing/hiding that content does not necessitate navigating to a new page.

If the content follows a sequential structure, you must use [Stepper](#stepper) or an equivalent component intended for progressing through a series of steps instead. Similarly, if you intend to use tabs for navigating between pages, use [Page header](#pageheader) with [Picklist](#picklist) or an equivalent navigational component that uses links rather than tabs.

## How to use

Wrap the tabs and tab panels in `XUITabs` in order to connect them correctly. You must always have the same number of tab panels as tabs. Additionally, you must set up your tab panels in the same order as your tabs.

By default, tabs will be activated automatically. This means that a tab will become active and its panel is displayed when it receives keyboard focus. Set the `activation` prop to `manual` if you want to activate a tab and display its panel by pressing Space or Enter.

Use distinct and concise tab labels, and use as few tabs as possible for clarity and to avoid forcing the user to scroll to view hidden tabs. In addition to leading to poor discoverability of content, having too many tabs may make it difficult for people using assistive technology or devices with small viewports to easily locate and switch tabs.

If you wish to supply custom ids to the tabpanel, give the corresponding tab an id. The tabpanel will then have a custom id suffixed with `-panel`, i.e. `${tabId}-panel`.

If testing `getSelectedTabMessage` you will need to mock `scrollIntoView` by adding `window.HTMLElement.prototype.scrollIntoView = () => {};` to either your test file or global setup.

## Accessibility

To meet accessibility requirements, you must supply a label to `XUITabList`. To achieve this, you can either use the `XUITabListLabel` component or else set either the `aria-label` or `aria-labelledby` attribute yourself on `XUITabList` (see controlled example).

## Switching between tabs

While you should avoid overflowing content, in the event that additional tabs are available beyond the visible area (for example, on small viewports), chevrons will be displayed for navigation. When clicked, these will change the selected tab and announce the new tab selection to screen readers through the use of an `aria-live` region.

You must supply `XUITabList` with a `nextTabButtonLabel` and a `previousTabButtonLabel` to apply to the chevrons. Recommended values are `Next tab` and `Previous tab`. You must also provide `XUITabList` with the `getSelectedTabMessage` prop, which is a function that accepts the tab title and returns a string. This is the message that will be announced by assistive tech when a new tab is selected using a chevron button.

## Examples

### Horizontal automatic activation (default behaviour)

```jsx harmony
import {
  XUITabs,
  XUITab,
  XUITabList,
  XUITabPanels,
  XUITabPanel,
  XUITabListLabel
} from '@xero/xui/react/tabs';

const Example = () => (
  <XUITabs>
    <XUITabListLabel>
      <h2 className="xui-heading-large xui-margin-bottom-xsmall">Reports</h2>
    </XUITabListLabel>
    <XUITabList
      getSelectedTabMessage={(selectedTabTitle, tabNo, totalTabs) =>
        `${selectedTabTitle} tab selected, ${tabNo} of ${totalTabs}`
      }
      nextTabButtonLabel="Next tab"
      previousTabButtonLabel="Previous tab"
    >
      <XUITab>All</XUITab>
      <XUITab>Custom</XUITab>
      <XUITab>Draft</XUITab>
      <XUITab>Published</XUITab>
      <XUITab>Archived</XUITab>
    </XUITabList>
    <XUITabPanels>
      <XUITabPanel>
        <h3 className="xui-heading-medium">All reports</h3>
      </XUITabPanel>
      <XUITabPanel>
        <h3 className="xui-heading-medium">Custom reports</h3>
      </XUITabPanel>
      <XUITabPanel>
        <h3 className="xui-heading-medium">Draft reports</h3>
      </XUITabPanel>
      <XUITabPanel>
        <h3 className="xui-heading-medium">Published reports</h3>
      </XUITabPanel>
      <XUITabPanel>
        <h3 className="xui-heading-medium">Archived reports</h3>
      </XUITabPanel>
    </XUITabPanels>
  </XUITabs>
);

<Example />;
```

### Horizontal manual activation

```jsx harmony
import {
  XUITabs,
  XUITab,
  XUITabList,
  XUITabPanels,
  XUITabPanel,
  XUITabListLabel
} from '@xero/xui/react/tabs';

const Example = () => (
  <XUITabs activation="manual">
    <XUITabListLabel>
      <h2 className="xui-heading-large xui-margin-bottom-xsmall">Reports</h2>
    </XUITabListLabel>
    <XUITabList
      getSelectedTabMessage={(selectedTabTitle, tabNo, totalTabs) =>
        `${selectedTabTitle} tab selected, ${tabNo} of ${totalTabs}`
      }
      nextTabButtonLabel="Next tab"
      previousTabButtonLabel="Previous tab"
    >
      <XUITab>All</XUITab>
      <XUITab>Custom</XUITab>
      <XUITab>Draft</XUITab>
      <XUITab>Published</XUITab>
      <XUITab>Archived</XUITab>
    </XUITabList>
    <XUITabPanels>
      <XUITabPanel>
        <h3 className="xui-heading-medium">All reports</h3>
      </XUITabPanel>
      <XUITabPanel>
        <h3 className="xui-heading-medium">Custom reports</h3>
      </XUITabPanel>
      <XUITabPanel>
        <h3 className="xui-heading-medium">Draft reports</h3>
      </XUITabPanel>
      <XUITabPanel>
        <h3 className="xui-heading-medium">Published reports</h3>
      </XUITabPanel>
      <XUITabPanel>
        <h3 className="xui-heading-medium">Archived reports</h3>
      </XUITabPanel>
    </XUITabPanels>
  </XUITabs>
);

<Example />;
```

### Vertical variant

```jsx harmony
import {
  XUITabs,
  XUITab,
  XUITabList,
  XUITabPanels,
  XUITabPanel,
  XUITabListLabel
} from '@xero/xui/react/tabs';

const Example = () => (
  <XUITabs>
    <XUITabListLabel>
      <h2 className="xui-heading-large xui-margin-bottom-xsmall">Reports</h2>
    </XUITabListLabel>
    <div className="xui-u-flex">
      <XUITabList
        orientation="vertical"
        getSelectedTabMessage={(tabTitle, tabNo, totalTabs) =>
          `${tabTitle} tab selected, ${tabNo} of ${totalTabs}`
        }
        nextTabButtonLabel="Next tab"
        previousTabButtonLabel="Previous tab"
      >
        <XUITab>All</XUITab>
        <XUITab>Custom</XUITab>
        <XUITab>Draft</XUITab>
        <XUITab>Published</XUITab>
        <XUITab>Archived</XUITab>
      </XUITabList>
      <XUITabPanels>
        <XUITabPanel className="xui-margin-left-large">
          <h3 className="xui-heading-medium xui-margin-top-xsmall">All reports</h3>
        </XUITabPanel>
        <XUITabPanel className="xui-margin-left-large">
          <h3 className="xui-heading-medium xui-margin-top-xsmall">Custom reports</h3>
        </XUITabPanel>
        <XUITabPanel className="xui-margin-left-large">
          <h3 className="xui-heading-medium xui-margin-top-xsmall">Draft reports</h3>
        </XUITabPanel>
        <XUITabPanel className="xui-margin-left-large">
          <h3 className="xui-heading-medium xui-margin-top-xsmall">Published reports</h3>
        </XUITabPanel>
        <XUITabPanel className="xui-margin-left-large">
          <h3 className="xui-heading-medium xui-margin-top-xsmall">Archived reports</h3>
        </XUITabPanel>
      </XUITabPanels>
    </div>
  </XUITabs>
);

<Example />;
```

### Controlled

`XUITabs` can be used as a controlled component by giving each tab a custom `id` and specifying an `activeTabId` to use. Use the `onTabChange` event to update this when the user interacts with the tablist.

```jsx harmony
import {
  XUITabs,
  XUITab,
  XUITabList,
  XUITabPanels,
  XUITabPanel,
  XUITabListLabel
} from '@xero/xui/react/tabs';
import { useState } from 'react';

const Example = () => {
  const tabsArray = [
    {
      id: 'tab-1',
      title: 'All',
      panelContent: <h2 className="xui-heading-medium">All reports</h2>
    },
    {
      id: 'tab-2',
      title: 'Custom',
      panelContent: <h2 className="xui-heading-medium">Custom reports</h2>
    },
    {
      id: 'tab-3',
      title: 'Draft',
      panelContent: <h2 className="xui-heading-medium">Draft reports</h2>
    },
    {
      id: 'tab-4',
      title: 'Published',
      panelContent: <h2 className="xui-heading-medium">Published reports</h2>
    },
    {
      id: 'tab-5',
      title: 'Archived',
      panelContent: <h2 className="xui-heading-medium">Archived reports</h2>
    }
  ];
  const [activeTabId, setActiveTabId] = useState(tabsArray[1].id);

  const onTabChange = targetId => {
    setActiveTabId(targetId);
  };

  return (
    <XUITabs activeTabId={activeTabId} onTabChange={onTabChange}>
      <XUITabList
        aria-label="Reports"
        getSelectedTabMessage={(tabTitle, tabNo, totalTabs) =>
          `${tabTitle} tab selected, ${tabNo} of ${totalTabs}`
        }
        nextTabButtonLabel="Next tab"
        previousTabButtonLabel="Previous tab"
      >
        {tabsArray.map(tab => (
          <XUITab key={tab.id} id={tab.id}>
            {tab.title}
          </XUITab>
        ))}
      </XUITabList>
      <XUITabPanels>
        {tabsArray.map(tab => (
          <XUITabPanel key={`${tab.id}-tabpanel`}>{tab.panelContent}</XUITabPanel>
        ))}
      </XUITabPanels>
    </XUITabs>
  );
};

<Example />;
```

### Conditionally render content

By default, content will be rendered in the DOM as soon as the component mounts. In order to avoid this (e.g. for performance optimisation), you may choose to conditionally render content.

```jsx harmony
import {
  XUITabs,
  XUITab,
  XUITabList,
  XUITabPanels,
  XUITabPanel,
  XUITabListLabel
} from '@xero/xui/react/tabs';
import { useState, useEffect } from 'react';

const Example = () => {
  const tabsArray = [
    {
      id: 'tab-1',
      title: 'All',
      panelContent: <h2 className="xui-heading-medium">All reports</h2>
    },
    {
      id: 'tab-2',
      title: 'Custom',
      panelContent: <h2 className="xui-heading-medium">Custom reports</h2>
    },
    {
      id: 'tab-3',
      title: 'Draft',
      panelContent: <h2 className="xui-heading-medium">Draft reports</h2>
    },
    {
      id: 'tab-4',
      title: 'Published',
      panelContent: <h2 className="xui-heading-medium">Published reports</h2>
    },
    {
      id: 'tab-5',
      title: 'Archived',
      panelContent: <h2 className="xui-heading-medium">Archived reports</h2>
    }
  ];
  const [panelContent, setPanelContent] = useState(null);
  const [activeTabId, setActiveTabId] = useState(tabsArray[0].id);

  React.useEffect(() => {
    function mockFetchDataFromAPI() {
      return new Promise((resolve, reject) => {
        setTimeout(id => {
          resolve(tabsArray.find(item => item.id === activeTabId));
        }, 200);
      });
    }

    mockFetchDataFromAPI()
      .then(data => {
        setPanelContent(data.panelContent);
      })
      .catch(error => {
        console.error('Error fetching data:', error.message);
        setPanelContent(null);
      });
  }, [activeTabId]);

  const onTabChange = targetId => {
    setActiveTabId(targetId);
  };

  return (
    <XUITabs activeTabId={activeTabId} onTabChange={onTabChange}>
      <XUITabList
        aria-label="Reports"
        getSelectedTabMessage={(tabTitle, tabNo, totalTabs) =>
          `${tabTitle} tab selected, ${tabNo} of ${totalTabs}`
        }
        nextTabButtonLabel="Next tab"
        previousTabButtonLabel="Previous tab"
      >
        {tabsArray.map(tab => (
          <XUITab key={tab.id} id={tab.id}>
            {tab.title}
          </XUITab>
        ))}
      </XUITabList>
      <XUITabPanels>
        {tabsArray.map(tab => {
          return (
            <XUITabPanel key={`${tab.id}-tabpanel`}>
              {activeTabId === tab.id && panelContent}
            </XUITabPanel>
          );
        })}
      </XUITabPanels>
    </XUITabs>
  );
};

<Example />;
```

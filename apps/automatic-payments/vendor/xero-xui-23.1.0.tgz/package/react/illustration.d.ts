import XUIIllustration, { type XUIIllustrationProps } from './components/illustration/XUIIllustration';
export { XUIIllustration as default, XUIIllustration, type XUIIllustrationProps };

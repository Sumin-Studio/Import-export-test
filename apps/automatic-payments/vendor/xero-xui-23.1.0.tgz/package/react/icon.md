<div class="xui-margin-vertical">
	<a href="../section-fundamentals-icons.html#icons" isDocLink>Icon in the XUI Documentation</a>
</div>

## How to use the XUI Icon

1. Import required icon paths.
1. Provide `XUIIcon` with imported icon path (for standardised viewbox sizing) or the icon object (for icon-specific sizing that is only as big as the underlying icon).

### Accessibility

Unless copy in a sibling element provides ample context or the icon is decorative, you should supply a value to the `title` prop to include a brief, human-readable name for the icon. For example, additional text would not be necessary for a bank icon on a select box with a label of _Select your bank_, but for a Twitter icon used to solely label an input for a Twitter handle, a title of `Twitter` would be necessary to provide crucial information to assistive technology.

It is highly unlikely you will need to make use of the `description` prop to further convey meaning. This is typically used for longer, more detailed descriptions for complex images; however, this would likely not be the case when using an icon. This prop has been deprecated in XUI 22 and will be removed in XUI 23.

```jsx harmony
import arrow from '@xero/xui-icon/icons/arrow';
import fileExcel from '@xero/xui-icon/icons/file-excel';
import filePdf from '@xero/xui-icon/icons/file-pdf';
import invalid from '@xero/xui-icon/icons/invalid';
import star from '@xero/xui-icon/icons/star';

import XUIIcon from '@xero/xui/react/icon';

<div>
  <h3>Standard icon</h3>
  <XUIIcon icon={arrow} />
  <h3>Rotated icons</h3>
  <XUIIcon className="xui-margin-right" icon={arrow} rotation="90" />
  <XUIIcon className="xui-margin-right" icon={arrow} rotation="180" />
  <XUIIcon icon={arrow} rotation="270" />
  <h3>Coloured icons</h3>
  <XUIIcon className="xui-margin-right" color="yellow" icon={star} title="Add favourite" />
  <XUIIcon
    className="xui-margin-right"
    color="file_spreadsheet"
    icon={fileExcel}
    title="Upload Excel file"
  />
  <XUIIcon className="xui-margin-right" color="file_pdf" icon={filePdf} title="Upload PDF" />
  <XUIIcon color="red" icon={invalid} title="Invalid input" />
</div>;
```

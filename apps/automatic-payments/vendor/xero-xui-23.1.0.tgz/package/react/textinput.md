<div class="xui-margin-vertical">
	<a href="../section-components-controls-textinput.html" isDocLink>Text Input in the XUI Documentation</a>
</div>

## Examples

### Text Input

Most input use cases can be solved using `XUITextInput`'s base props. Additional attributes that aren't available as base props can be passed down to the `input` via `inputProps`.

```js
import XUITextInput from '@xero/xui/react/textinput';

<div>
  <h3>Standard text input</h3>
  <XUITextInput fieldClassName="xui-margin-bottom" label="Contact name" />
  <h3>Standard text input with default value</h3>
  <XUITextInput defaultValue="John Smith" fieldClassName="xui-margin-bottom" label="Contact name" />
  <h3>Number input with placeholder</h3>
  <XUITextInput
    fieldClassName="xui-margin-bottom"
    label="Time taken"
    placeholder="0:00"
    type="number"
  />
  <h3>Reverse-aligned input</h3>
  <XUITextInput
    fieldClassName="xui-margin-bottom"
    isValueReverseAligned
    label="Time taken"
    placeholder="0:00"
    type="number"
  />
  <h3>Read-only text input</h3>
  <XUITextInput defaultValue="John Smith" inputProps={{ readOnly: true }} label="Contact name" />
</div>;
```

#### HTML Attributes

We recommend being cautious when passing down a `type` to your input. Currently, some types don't work well for accessibility or internationalisation. For example, setting `type="number"` will not allow users to use `,` as a decimal separator, which is the correct decimal separator in many regions.

If you are trying to control the virtual keyboard that appears when entering data into your text input, you may wish to pass an `inputMode` prop. This reflects the [inputmode](https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes/inputmode) attribute, which can assist touch device users in entering data more quickly. You should confirm the native behaviour of these keyboards and consider internationalisation when choosing to adjust these.

### Labels

Labels can be set on `XUITextInput` by passing a value to the `label` prop.

```jsx harmony
import XUITextInput from '@xero/xui/react/textinput';

<XUITextInput label="Contact name" />;
```

### Optional fields indicator

#### As a label

If you want to indicate that the input is an optional field, you can do so by wrapping the input in `XUIForm`.

```jsx harmony
import XUITextInput from '@xero/xui/react/textinput';
import XUIForm from '@xero/xui/react/form';

<XUIForm optionalLabel="(Optional)" requiredLabel="(Required)">
  <XUITextInput label="Contact" />
</XUIForm>;
```

#### As a placeholder

If you want to provide an optional field indicator without a label, you can do so by adding the `(Optional)` text into the `placeholder` prop.

```jsx harmony
import XUITextInput from '@xero/xui/react/textinput';

<XUITextInput isLabelHidden label="Contact (Optional)" placeholder="Contact (Optional)" />;
```

#### Your own custom indicator

You can use the above patterns with text other than 'Optional' such as 'Required' too. Please take care to respect the form input guidance in the [XUI Documentation](../section-components-collectinginput-forms.html)

### Validation

Validation messages and styling should be added to inputs using the `validationMessage` and `isInvalid` props. Additionally, hint messages can be passed to inputs using the `hintMessage` prop. It's best to set `isFieldLayout=true` on all inputs to ensure consistent spacing between fields.

```jsx harmony
import { useState } from 'react';
import XUITextInput from '@xero/xui/react/textinput';

const TextInputExample = () => {
  const [hasFocus, setHasFocus] = useState(false);

  const onFocus = () => {
    setHasFocus(true);
  };

  const onBlur = () => {
    setHasFocus(false);
  };

  return (
    <div>
      <h3>Text input with validation message</h3>
      <XUITextInput
        isFieldLayout
        isInvalid
        label="Bank account number"
        validationMessage="Bank account numbers must have at least 9 digits"
      />

      <h3 className="xui-padding-top">Required text input with validation message</h3>
      <XUITextInput
        isFieldLayout
        isInvalid
        isRequired
        label="First name"
        validationMessage="First name is required"
      />

      <h3 className="xui-padding-top">Text input with hint message</h3>
      <XUITextInput
        hintMessage="Found on the top of your IR3 statement"
        isFieldLayout
        label="IRD number"
      />

      <h3 className="xui-padding-top">Text input with hint message when focused</h3>
      <XUITextInput
        hintMessage={(hasFocus && 'Found on the top of your IR3 statement') || ''}
        isFieldLayout
        label="IRD number"
        onFocus={onFocus}
        onBlur={onBlur}
      />
    </div>
  );
};

<TextInputExample />;
```

#### Multiline Input

`XUITextInput` can be made into a multiline textarea by setting `isMultiline` to `true`. Additionally, `minRows`, `maxRows`, and `rows` may be set to set the vertical height of the input.

```jsx harmony
import XUITextInput from '@xero/xui/react/textinput';

<div>
  <h3>Multiline input which grows automatically up to 5 rows high</h3>
  <XUITextInput isFieldLayout isMultiline label="Notes" maxRows={5} minRows={2} />

  <h3>Multiline input which grows automatically without limit</h3>
  <XUITextInput isFieldLayout isMultiline label="Notes" minRows={3} />

  <h3>Multiline input with a set number of rows</h3>
  <XUITextInput isFieldLayout isMultiline label="Notes" rows={3} />
</div>;
```

#### Side Elements

Content can be added to the side of a `XUITextInput` using the `leftElement` and `rightElement` props. It's recommended that you use the `XUITextInputSideElement` component to ensure the correct styling is applied. When using custom static side elements (e.g. icons, avatars), focus the input when the side element is clicked. (e.g. `<CustomElement onClick={ this.inputRef?.current?.focus() }>`).

If using text-only side elements, we recommend that you use `XUIControlGroup` to wrap inputs. Check out the `XUITextInput` Groups example to see how this can be implemented.

If using a `XUITextInputSideElement` with type `text` or `icon` that conveys necessary additional context, set `includeElementInLabel` as true to ensure that element is included as part of the input label recognised by screen readers.

```jsx harmony
import React from 'react';
import search from '@xero/xui-icon/icons/search';
import twitter from '@xero/xui-icon/icons/social-twitter';
import mobile from '@xero/xui-icon/icons/mobile';

import XUIAvatar from '@xero/xui/react/avatar';
import XUIButton from '@xero/xui/react/button';
import XUIControlGroup from '@xero/xui/react/controlgroup';
import XUIIcon from '@xero/xui/react/icon';
import XUIPill from '@xero/xui/react/pill';
import XUITextInput, { XUITextInputSideElement } from '@xero/xui/react/textinput';

const TextInputWithSideElementsExample = () => {
  return (
    <div>
      <h3>Standard text inputs with side content</h3>
      <XUITextInput
        isFieldLayout
        label="Contact"
        leftElement={
          <XUITextInputSideElement type="icon">
            <XUIIcon icon={search} isBoxed svgProps={{ 'aria-hidden': true }} />
          </XUITextInputSideElement>
        }
        placeholder="Search"
      />
      <XUITextInput
        isFieldLayout
        label="Amount"
        leftElement={
          <XUITextInputSideElement includeElementInLabel type="text">
            $
          </XUITextInputSideElement>
        }
        placeholder="0.00"
      />
      <XUITextInput
        isFieldLayout
        label="Tel"
        placeholder="Telephone number"
        leftElement={
          <XUITextInputSideElement includeElementInLabel type="icon">
            <XUIIcon icon={mobile} isBoxed title="Mobile" />
          </XUITextInputSideElement>
        }
      />
      <XUITextInput
        defaultValue="Jane Smith"
        isFieldLayout
        label="Contact"
        leftElement={
          <XUITextInputSideElement type="avatar">
            <XUIAvatar size="small" value="Jane Smith" />
          </XUITextInputSideElement>
        }
      />
      <XUITextInput
        isFieldLayout
        label="Contact"
        leftElement={
          <XUITextInputSideElement type="pill">
            <XUIPill
              avatarProps={{ value: 'Jane Smith' }}
              deleteButtonProps={{ ariaLabel: 'Remove Jane Smith' }}
              onDeleteClick={() => {
                console.log('XUIPill - onDeleteClick');
              }}
              value="Jane Smith"
            />
          </XUITextInputSideElement>
        }
      />
      <XUITextInput
        isFieldLayout
        label="Contact"
        leftElement={
          <XUITextInputSideElement type="button">
            <XUIButton
              onClick={() => {
                console.log('Clear - onClick');
              }}
              size="small"
            >
              Clear
            </XUIButton>
          </XUITextInputSideElement>
        }
        placeholder="Search"
      />
      <XUITextInput
        isFieldLayout
        label="Twitter"
        leftElement={
          <XUITextInputSideElement backgroundColor="twitter" type="icon">
            <XUIIcon icon={twitter} isBoxed svgProps={{ 'aria-hidden': true }} />
          </XUITextInputSideElement>
        }
        placeholder="@username"
      />
      <XUITextInput
        isFieldLayout
        label="Contact"
        placeholder="Search"
        rightElement={
          <XUITextInputSideElement type="button">
            <XUIButton
              onClick={() => {
                console.log('Clear - onClick');
              }}
              size="small"
            >
              Clear
            </XUIButton>
          </XUITextInputSideElement>
        }
      />
      <XUITextInput
        isFieldLayout
        label="Twitter"
        placeholder="@username"
        rightElement={
          <XUITextInputSideElement backgroundColor="twitter" type="icon">
            <XUIIcon icon={twitter} isBoxed svgProps={{ 'aria-hidden': true }} />
          </XUITextInputSideElement>
        }
      />
    </div>
  );
};

<TextInputWithSideElementsExample />;
```

```jsx harmony
import attach from '@xero/xui-icon/icons/attach';
import twitter from '@xero/xui-icon/icons/social-twitter';

import XUIButton, { XUIIconButton } from '@xero/xui/react/button';
import XUIIcon from '@xero/xui/react/icon';
import XUITextInput, { XUITextInputSideElement } from '@xero/xui/react/textinput';

<div>
  <h3>Multiline text inputs with side content</h3>
  <XUITextInput
    isFieldLayout
    isMultiline
    label="Twitter"
    leftElement={
      <XUITextInputSideElement alignment="top" backgroundColor="twitter" type="icon">
        <XUIIcon icon={twitter} isBoxed svgProps={{ 'aria-hidden': true }} />
      </XUITextInputSideElement>
    }
    placeholder="@username"
  />
  <XUITextInput
    defaultValue="jane@xero.com, john@xero.com"
    isFieldLayout
    isMultiline
    label="Emails"
    rightElement={
      <XUITextInputSideElement alignment="top" type="button">
        <XUIButton
          onClick={() => {
            console.log('Clear - onClick');
          }}
          size="small"
        >
          Clear
        </XUIButton>
      </XUITextInputSideElement>
    }
  />
  <XUITextInput
    defaultValue="jane@xero.com, john@xero.com"
    isFieldLayout
    isMultiline
    label="Emails"
    rightElement={
      <XUITextInputSideElement alignment="center" type="button">
        <XUIButton
          onClick={() => {
            console.log('Clear - onClick');
          }}
          size="small"
        >
          Clear
        </XUIButton>
      </XUITextInputSideElement>
    }
  />
  <XUITextInput
    defaultValue="jane@xero.com, john@xero.com"
    isFieldLayout
    isMultiline
    label="Emails"
    rightElement={
      <XUITextInputSideElement alignment="bottom" type="button">
        <XUIButton
          onClick={() => {
            console.log('Clear - onClick');
          }}
          size="small"
        >
          Clear
        </XUIButton>
      </XUITextInputSideElement>
    }
  />
  <XUITextInput
    isFieldLayout
    isMultiline
    label="Files"
    placeholder="Select file(s) to attach"
    rightElement={
      <XUITextInputSideElement alignment="top" type="icon">
        <XUIIconButton ariaLabel="attach" icon={attach} />
      </XUITextInputSideElement>
    }
  />
  <XUITextInput
    isFieldLayout
    isMultiline
    label="Files"
    placeholder="Select file(s) to attach"
    rightElement={
      <XUITextInputSideElement alignment="center" type="icon">
        <XUIIconButton ariaLabel="attach" icon={attach} />
      </XUITextInputSideElement>
    }
  />
  <XUITextInput
    isFieldLayout
    isMultiline
    label="Files"
    placeholder="Select file(s) to attach"
    rightElement={
      <XUITextInputSideElement alignment="bottom" type="icon">
        <XUIIconButton ariaLabel="attach" icon={attach} />
      </XUITextInputSideElement>
    }
  />
</div>;
```

### Sizes

Inputs also have `small` and `xsmall` variants. To use these size variants with side elements, you just need to make sure the input contents have a smaller size variant added.

Note that only avatars and text side elements have `2xsmall` size variants, so are the only side element options available for the `xsmall` text inputs.

```jsx harmony
import crossSmall from '@xero/xui-icon/icons/cross-small';
import XUIAvatar from '@xero/xui/react/avatar';
import XUIButton, { XUIIconButton } from '@xero/xui/react/button';
import XUIPill from '@xero/xui/react/pill';
import XUITextInput, { XUITextInputSideElement } from '@xero/xui/react/textinput';

<div>
  <XUITextInput
    defaultValue="Jane Smith"
    fieldClassName="xui-margin-bottom"
    label="Contact"
    leftElement={
      <XUITextInputSideElement type="avatar">
        <XUIAvatar size="small" value="Jane Smith" />
      </XUITextInputSideElement>
    }
    rightElement={
      <XUITextInputSideElement type="icon">
        <XUIIconButton
          ariaLabel="Clear content"
          icon={crossSmall}
          onClick={() => {
            console.log('Clear - onClick');
          }}
        />
      </XUITextInputSideElement>
    }
  />
  <XUITextInput
    defaultValue="Jane Smith"
    fieldClassName="xui-margin-bottom"
    label="Contact"
    leftElement={
      <XUITextInputSideElement type="avatar">
        <XUIAvatar size="xsmall" value="Jane Smith" />
      </XUITextInputSideElement>
    }
    rightElement={
      <XUITextInputSideElement type="icon">
        <XUIIconButton
          ariaLabel="Clear content"
          icon={crossSmall}
          onClick={() => {
            console.log('Clear - onClick');
          }}
          size="small"
        />
      </XUITextInputSideElement>
    }
    size="small"
  />
  <XUITextInput
    defaultValue="Jane Smith"
    fieldClassName="xui-margin-bottom"
    label="Contact"
    leftElement={
      <XUITextInputSideElement type="avatar">
        <XUIAvatar size="2xsmall" value="Jane Smith" />
      </XUITextInputSideElement>
    }
    rightElement={
      <XUITextInputSideElement type="icon">
        <XUIIconButton
          ariaLabel="Clear content"
          icon={crossSmall}
          onClick={() => {
            console.log('Clear - onClick');
          }}
          size="xsmall"
        />
      </XUITextInputSideElement>
    }
    size="xsmall"
  />
  <XUITextInput
    label="Contacts"
    leftElement={
      <XUITextInputSideElement type="pill">
        <XUIPill
          avatarProps={{ value: 'Jane Smith' }}
          deleteButtonProps={{ ariaLabel: 'Remove Jane Smith' }}
          onDeleteClick={() => {
            console.log('XUIPill - onDeleteClick');
          }}
          value="Jane Smith"
        />
      </XUITextInputSideElement>
    }
    rightElement={
      <XUITextInputSideElement type="button">
        <XUIButton
          onClick={() => {
            console.log('Clear - onClick');
          }}
          size="small"
          variant="standard"
        >
          Clear
        </XUIButton>
      </XUITextInputSideElement>
    }
  />
</div>;
```

#### Groups

`XUITextInput` can be grouped using `XUIControlGroup`. <a href="#control-group">More about Control Groups</a>.

**Note:** _Don’t vertically stack `small` and `xsmall` text inputs due to poor touch interaction potential._

```jsx harmony
import XUITextInput, { XUITextInputSideElement } from '@xero/xui/react/textinput';
import XUIControlGroup from '@xero/xui/react/controlgroup';

<div>
  <XUIControlGroup className="xui-field-layout" label="Name">
    <XUITextInput
      isLabelHidden
      label="First name"
      leftElement={<XUITextInputSideElement type="text">First name:</XUITextInputSideElement>}
    />
    <XUITextInput
      isLabelHidden
      label="Middle name"
      leftElement={<XUITextInputSideElement type="text">Middle name:</XUITextInputSideElement>}
    />
    <XUITextInput
      isLabelHidden
      label="Last name"
      leftElement={<XUITextInputSideElement type="text">Last name:</XUITextInputSideElement>}
    />
  </XUIControlGroup>

  <XUIControlGroup isLockedVertical label="Details">
    <XUITextInput
      isLabelHidden
      label="First name"
      leftElement={<XUITextInputSideElement type="text">First name:</XUITextInputSideElement>}
    />
    <XUITextInput
      isLabelHidden
      label="Middle name"
      leftElement={<XUITextInputSideElement type="text">Middle name:</XUITextInputSideElement>}
    />
    <XUITextInput
      isLabelHidden
      label="Last name"
      leftElement={<XUITextInputSideElement type="text">Last name:</XUITextInputSideElement>}
    />
  </XUIControlGroup>
</div>;
```

#### Borderless Variants

```jsx harmony
import XUITextInput from '@xero/xui/react/textinput';

const styles = {
  backgroundColor: '#f5f6f7',
  padding: '10px'
};

<div>
  <h3>Transparent borderless</h3>
  <div style={styles}>
    <XUITextInput
      defaultValue="John Smith"
      isBorderlessTransparent
      label="Contact name"
      placeholder="E.g. John Smith"
    />
  </div>

  <h3>Solid borderless</h3>
  <div style={styles}>
    <XUITextInput
      defaultValue="John Smith"
      placeholder="E.g. John Smith"
      isBorderlessSolid
      label="Contact name"
    />
  </div>
</div>;
```

#### Inverted Borderless Variant

```jsx harmony
import XUITextInput, { XUITextInputSideElement } from '@xero/xui/react/textinput';
import ExampleContainer from './docs/ExampleContainer';

<div>
  <h3>Inverted transparent borderless</h3>
  <ExampleContainer className="xui-padding-xsmall" isInverted>
    <XUITextInput
      isBorderlessTransparent
      isInverted
      label="Contact name"
      leftElement={<XUITextInputSideElement type="text">Contact name:</XUITextInputSideElement>}
      placeholder="E.g. John Smith"
    />
  </ExampleContainer>

  <h3>Inverted solid borderless</h3>
  <ExampleContainer className="xui-padding-xsmall" isInverted>
    <XUITextInput
      isBorderlessSolid
      isInverted
      label="Contact name"
      leftElement={<XUITextInputSideElement type="text">Contact name:</XUITextInputSideElement>}
      placeholder="E.g. John Smith"
    />
  </ExampleContainer>
</div>;
```

#### Stateful Clear Button

```js
import { useState } from 'react';
import clear from '@xero/xui-icon/icons/clear';
import url from '@xero/xui-icon/icons/url';

import XUIIcon from '@xero/xui/react/icon';
import { XUIIconButton } from '@xero/xui/react/button';
import XUITextInput, { XUITextInputSideElement } from '@xero/xui/react/textinput';

const TextInputExample = () => {
  const [value, setValue] = useState('https://www.xero.com');

  const onChange = event => {
    setValue(event.target.value);
  };

  const onClearButtonClick = () => {
    setValue('');
  };

  const button = <XUIIconButton ariaLabel="clear" icon={clear} onClick={onClearButtonClick} />;

  return (
    <XUITextInput
      label="Website"
      leftElement={
        <XUITextInputSideElement type="icon">
          <XUIIcon icon={url} isBoxed svgProps={{ 'aria-hidden': true }} />
        </XUITextInputSideElement>
      }
      onChange={onChange}
      placeholder="https://www.google.com"
      rightElement={<XUITextInputSideElement type="icon">{button}</XUITextInputSideElement>}
      value={value}
    />
  );
};

<TextInputExample />;
```

#### Character counter

A character counter can be added by using the `maxCharCount` prop. This counter tracks the length of characters in the input. This feature can be used with both controlled and uncontrolled usages of Text Input.

You must also add a validation message using the `characterCounterValidationMessage` prop. This validation message will show when the length of input exceeds the `maxCharCount`.

**Note**: _The character counter will display when the length of `value` is 90% of `maxCharCount` - 5 characters_

##### Controlled example

```js
import { useState } from 'react';
import XUITextInput from '@xero/xui/react/textinput';

const TextInputExample = () => {
  const [value, setValue] = useState('xero_user_20201030019');

  const onChange = event => {
    setValue(event.target.value);
  };

  const maxCount = 20;

  return (
    <XUITextInput
      characterCounter={{
        maxCharCount: maxCount,
        validationMessage: `Username should be no longer than ${maxCount} characters`,
        characterCounterMessage: (currentCharCount, maxCharCount) =>
          `${currentCharCount} out of ${maxCharCount} characters typed`
      }}
      label="Username"
      onChange={onChange}
      value={value}
    />
  );
};

<TextInputExample />;
```

##### Uncontrolled example

```js
import XUITextInput from '@xero/xui/react/textinput';

const TextInputExample = () => {
  const maxCount = 20;

  return (
    <XUITextInput
      defaultValue="xero_user_20201030019"
      characterCounter={{
        maxCharCount: maxCount,
        validationMessage: `Username should be no longer than ${maxCount} characters`,
        characterCounterMessage: (currentCharCount, maxCharCount) =>
          `${currentCharCount} out of ${maxCharCount} characters typed`
      }}
      label="Username"
    />
  );
};

<TextInputExample />;
```

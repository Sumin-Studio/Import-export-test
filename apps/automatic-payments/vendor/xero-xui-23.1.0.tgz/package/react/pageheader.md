<div class="xui-margin-vertical">
	<a href="../section-components-navigation-page-header.html" isDocLink>Page Header in the XUI Documentation</a>
</div>

The `XUIPageHeader` appears beneath the global header on a page. In a basic example, it is a white bar with a title. In more complex cases it could contain a [`XUIBreadcrumbTrail`](#xuibreadcrumbtrail), a [`XUIAvatar`](#avatar), a [`XUITabs`](#tabs) to present tabs for organising related content, a [`XUIPicklist`](#picklist) to present navigating between pages with links, or a [`XUIActions`](#actions) component (and some combinations).

[Container Queries](#container-queries) could be used to detect the container size and adjust the layout of PageHeader responsively.

#### Examples

```jsx harmony
import XUIPageHeader from '@xero/xui/react/pageheader';

<XUIPageHeader title="Account settings" />;
```

You can use the [tabs](#tabs) component with `XUIPageHeader` by adding the `enableUsingXUITabs` prop to `XUIPageHeader`. This component addresses many accessibility issues associated with `XUIPicklist`, and tabs implementations using `XUIPicklist` should eventually be replaced with this tabs experience once there are suitable alternatives for all possible configurations.

```jsx harmony
import XUIPageHeader from '@xero/xui/react/pageheader';
import { XUITabs, XUITab, XUITabList, XUITabPanels, XUITabPanel } from '@xero/xui/react/tabs';

const builtTabs = (
  <XUITabList aria-label="Contacts">
    <XUITab>All</XUITab>
    <XUITab>Customers</XUITab>
    <XUITab>Suppliers</XUITab>
  </XUITabList>
);

const wrapperStyles = {
  overflow: 'hidden',
  resize: 'horizontal'
};

<div className="xui-panel xui-padding-xsmall" style={wrapperStyles}>
  <XUITabs>
    <XUIPageHeader enableUsingXUITabs tabs={builtTabs} title="Contacts" />
    <XUITabPanels>
      <XUITabPanel>
        <h3 className="xui-heading-medium xui-margin-left-small">All contacts</h3>
      </XUITabPanel>
      <XUITabPanel>
        <h3 className="xui-heading-medium xui-margin-left-small">Customer information</h3>
      </XUITabPanel>
      <XUITabPanel>
        <h3 className="xui-heading-medium xui-margin-left-small">Supplier information</h3>
      </XUITabPanel>
    </XUITabPanels>
  </XUITabs>
</div>;
```

```jsx harmony
import overflow from '@xero/xui-icon/icons/overflow';
import XUIActions from '@xero/xui/react/actions';
import XUIButton, { XUIIconButton } from '@xero/xui/react/button';
import XUIPageHeader from '@xero/xui/react/pageheader';

const builtActions = (
  <XUIActions
    hasLayout={false}
    primaryAction={<XUIIconButton icon={overflow} key="moreOptions" ariaLabel="More options" />}
    secondaryAction={
      <XUIButton
        key="newContact"
        onClick={() => {
          console.log('onClick');
        }}
        size="small"
        variant="create"
      >
        New contact
      </XUIButton>
    }
  />
);

<XUIPageHeader actions={builtActions} title="Contacts" />;
```

```jsx harmony
import XUIActions from '@xero/xui/react/actions';
import XUIAvatar from '@xero/xui/react/avatar';
import XUIButton from '@xero/xui/react/button';
import XUIPageHeader, { XUIBreadcrumbTrail } from '@xero/xui/react/pageheader';
import { XUITabs, XUITab, XUITabList, XUITabPanels, XUITabPanel } from '@xero/xui/react/tabs';
import XUITag from '@xero/xui/react/tag';

const builtActions = (
  <XUIActions
    hasLayout={false}
    primaryAction={
      <XUIButton
        key="create"
        onClick={() => {
          console.log('onClick');
        }}
        size="small"
        variant="create"
      >
        Create
      </XUIButton>
    }
    secondaryAction={
      <XUIButton
        key="discard"
        onClick={() => {
          console.log('onClick');
        }}
        size="small"
      >
        Discard
      </XUIButton>
    }
  />
);

const breadcrumbLinks = [
  { href: '#organisation-settings', key: '1', label: 'Organisation settings' },
  { href: '#edit-organisation', key: '2', label: 'Edit organisation' }
];
const builtBreadcrumb = <XUIBreadcrumbTrail breadcrumbs={breadcrumbLinks} />;

const builtTabs = (
  <XUITabList aria-label="Contacts">
    <XUITab>See all</XUITab>
    <XUITab>Edit</XUITab>
    <XUITab>Add</XUITab>
  </XUITabList>
);

<XUITabs>
  <XUIPageHeader
    actions={builtActions}
    avatar={<XUIAvatar size="small" value="Dave Forett" />}
    breadcrumb={builtBreadcrumb}
    enableUsingXUITabs
    secondary="Dave Forett"
    supplementary="Saved"
    tabs={builtTabs}
    tags={[
      <XUITag key="pending" size="small">
        Pending
      </XUITag>
    ]}
    title="New member"
  />
</XUITabs>;
```

If you are using a navigational links pattern with PageHeader, use horizontal picklist. This also offers a compact version for responsive support.

(Refer to the document for prop `swapAtBreakpoint` in the `Horizontal variant` section of [Picklist](#picklist).)

Try to resize: Click and drag the bottom right corner of the following container.

```jsx harmony
import XUIPageHeader from '@xero/xui/react/pageheader';
import XUIPicklist, { XUIPickitem } from '@xero/xui/react/picklist';

const builtTabs = (
  <XUIPicklist swapAtBreakpoint="small">
    <XUIPickitem href="/" id="all-2">
      All
    </XUIPickitem>
    <XUIPickitem href="/" id="customers-2" isSelected>
      Customers
    </XUIPickitem>
    <XUIPickitem href="/" id="suppliers-2">
      Suppliers
    </XUIPickitem>
  </XUIPicklist>
);

const wrapperStyles = {
  overflow: 'hidden',
  resize: 'horizontal'
};

<div className="xui-panel xui-padding-xsmall" style={wrapperStyles}>
  <XUIPageHeader tabs={builtTabs} title="Contacts" />
</div>;
```

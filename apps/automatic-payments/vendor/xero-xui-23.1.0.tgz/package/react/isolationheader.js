"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIIsolationHeader", {
  enumerable: true,
  get: function () {
    return _XUIIsolationHeader.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIIsolationHeader.default;
  }
});
var _XUIIsolationHeader = _interopRequireDefault(require("./components/isolationheader/XUIIsolationHeader"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=isolationheader.js.map
import XUITag, { type XUITagProps } from './components/tag/XUITag';
export { XUITag as default, XUITag, type XUITagProps };

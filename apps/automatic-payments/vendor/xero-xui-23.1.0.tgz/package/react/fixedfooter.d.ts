import XUIFixedFooter, { type XUIFixedFooterProps } from './components/fixedfooter/XUIFixedFooter';
export { XUIFixedFooter as default, XUIFixedFooter, type XUIFixedFooterProps };

<div class="xui-margin-vertical">
	<a href="../section-components-navigation-stepper.html" isDocLink>Stepper in the XUI Documentation</a>
</div>

The stepper renders a set of _steps_ and a _content_ area corresponding to the currently _active_ step.<br />`import XUIStepper from '@xero/xui/react/stepper';`.

## Responsive

By default the stepper will automatically change the positioning of steps and content in respect to the `currentStep` prop: either inline within the stepper for narrow viewports, or below the stepper for wider viewports to ensure optimal usability in the widest range of responsive scenarios.

The content elements must be passed as children to the stepper component so that the stepper can take control of their layout. Without this, you will not get the full benefits of the stepper's responsive behaviour.

You can opt out of the stepper's responsive functionality, however we **strongly** recommend that you retain these capabilities and **not** use the `lockLayout` prop. By not supporting all device sizes you are creating a reduced user experience.

## Accessibility

Under the hood, `XUIStepper` uses links to indicate that a user is progressing through a sequence of steps. You must use the `ariaLabel` prop to provide the outer `nav` element with a suitable accessible label.

Additionally, you must provide each step with a `status` to indicate the user's progression to screen readers. Example values include `Error` and `Complete`.

When the step changes, send focus to the heading of the updated content.

## Examples

#### Inline _(standard)_

Lock by supplying the string `inline` to the prop `lockLayout`.

```jsx harmony
import { useState, useRef, useEffect } from 'react';
import XUIStepper from '@xero/xui/react/stepper';

const steps = [
  { name: 'Plan', status: 'Incomplete' },
  { name: 'Billing', status: 'Incomplete' },
  { name: 'Review', status: 'Incomplete' }
];
const content = ['Select a plan', 'Payment details', 'Confirm purchase'];

const StepperExample = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const headingRef = useRef();

  const updateCurrentStep = step => {
    setCurrentStep(step);
    // Send focus to the heading when the currentStep updates
    headingRef.current.focus();
  };

  return (
    <XUIStepper
      ariaLabel="Plan selection progress"
      currentStep={currentStep}
      id="stepper-inline-standard"
      lockLayout="inline"
      stepTitle="Step"
      steps={steps}
      updateCurrentStep={updateCurrentStep}
    >
      <h3 className="xui-text-align-center" ref={headingRef} tabIndex="0">
        {content[currentStep]}
      </h3>
    </XUIStepper>
  );
};

<StepperExample />;
```

#### Inline _(stacked buttons)_

The `inline` layout also has the ability to stack its button content using the prop `hasStackedButtons`.

- You can use this prop in both a _locked_ or _default_ layout state.

```jsx harmony
import { useState, useRef, useEffect } from 'react';
import XUIStepper from '@xero/xui/react/stepper';

const steps = [
  { name: 'Plan', status: 'Incomplete' },
  { name: 'Billing', status: 'Incomplete' },
  { name: 'Review', status: 'Incomplete' }
];
const content = ['Select a plan', 'Payment details', 'Confirm purchase'];

const StepperExample = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const headingRef = useRef();

  const updateCurrentStep = step => {
    setCurrentStep(step);
    // Send focus to the heading when the currentStep updates
    headingRef.current.focus();
  };

  return (
    <XUIStepper
      ariaLabel="Plan selection progress"
      currentStep={currentStep}
      hasStackedButtons
      id="stepper-inline-stacked"
      lockLayout="inline"
      stepTitle="Step"
      steps={steps}
      updateCurrentStep={updateCurrentStep}
    >
      <h3 className="xui-text-align-center" ref={headingRef} tabIndex="0">
        {content[currentStep]}
      </h3>
    </XUIStepper>
  );
};

<StepperExample />;
```

#### Side Bar

Lock by supplying the string `sidebar` to the prop `lockLayout`.

```jsx harmony
import { useState, useRef, useEffect } from 'react';
import XUIStepper from '@xero/xui/react/stepper';

const steps = [
  { name: 'Plan', status: 'Incomplete' },
  { name: 'Billing', status: 'Incomplete' },
  { name: 'Review', status: 'Incomplete' }
];
const content = ['Select a plan', 'Payment details', 'Confirm purchase'];

const StepperExample = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const headingRef = useRef();

  const updateCurrentStep = step => {
    setCurrentStep(step);
    // Send focus to the heading when the currentStep updates
    headingRef.current.focus();
  };

  return (
    <XUIStepper
      ariaLabel="Plan selection progress"
      currentStep={currentStep}
      id="stepper-sidebar-standard"
      lockLayout="sidebar"
      stepTitle="Step"
      steps={steps}
      updateCurrentStep={updateCurrentStep}
    >
      <h3 ref={headingRef} tabIndex="0">
        {content[currentStep]}
      </h3>
    </XUIStepper>
  );
};

<StepperExample />;
```

#### Stacked

Lock by supplying the string `stacked` to the prop `lockLayout`.

```jsx harmony
import { useState, useRef, useEffect } from 'react';
import XUIStepper from '@xero/xui/react/stepper';

const steps = [
  { name: 'Plan', status: 'Incomplete' },
  { name: 'Billing', status: 'Incomplete' },
  { name: 'Review', status: 'Incomplete' }
];
const content = ['Select a plan', 'Payment details', 'Confirm purchase'];

const StepperExample = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const headingRef = useRef();

  const updateCurrentStep = step => {
    setCurrentStep(step);
    // Send focus to the heading when the currentStep updates
    headingRef.current.focus();
  };

  return (
    <XUIStepper
      ariaLabel="Plan selection progress"
      currentStep={currentStep}
      id="stepper-stacked-standard"
      lockLayout="stacked"
      stepTitle="Step"
      steps={steps}
      updateCurrentStep={updateCurrentStep}
    >
      <h3 ref={headingRef} tabIndex="0">
        {content[currentStep]}
      </h3>
    </XUIStepper>
  );
};

<StepperExample />;
```

### Tab options

You as a developer control the step configuration via the `steps` prop. This gives granularity to customise the component visually but to also control the usability e.g. force the user to proceed through the _steps_ linearly or arbitrarily.

#### Generic

- The simplest step layout can be achieved by supplying just a `name` prop.
- Add a _description_ via the `description` prop.
- Change a step to an _error_ state via the `isError` prop.
- Change a step to a _complete_ state via the `isComplete` prop.

```jsx harmony
import { useState, useRef, useEffect } from 'react';
import XUIStepper from '@xero/xui/react/stepper';

const steps = [
  { description: 'All sections answered', isComplete: true, name: 'Plan', status: 'Complete' },
  {
    description: 'Missing payment details',
    isError: true,
    name: 'Billing',
    status: 'Error'
  },
  {
    description: 'Add/view subscription details',
    name: 'Subscription details',
    status: 'Incomplete'
  },
  { description: 'Review & pay', isDisabled: true, name: 'Review' }
];
const content = ['Select a plan', 'Payment details', 'Subscription details', 'Confirm purchase'];

const StepperExample = () => {
  const [currentStep, setCurrentStep] = useState(2);
  const headingRef = useRef();

  const updateCurrentStep = step => {
    setCurrentStep(step);
    // Send focus to the heading when the currentStep updates
    headingRef.current.focus();
  };

  return (
    <XUIStepper
      ariaLabel="Plan selection progress"
      currentStep={currentStep}
      id="stepper-step-generic"
      lockLayout="stacked"
      stepTitle="Step"
      steps={steps}
      updateCurrentStep={updateCurrentStep}
    >
      <h3 ref={headingRef} tabIndex="0">
        {content[currentStep]}
      </h3>
    </XUIStepper>
  );
};

<StepperExample />;
```

#### Progress Indicator

In addition to the generic step format a **Progress Indicator** can be included with the `isProgress` prop.

- Visualise _progress_ by supplying a `totalProgress` and `currentProgress` prop.
- You can either lock a step to the _complete_ state with the `isComplete` prop or if the `totalProgress` and `currentProgress` values are equal the _complete_ state
  will be applied automatically.

```jsx harmony
import { useState, useRef, useEffect } from 'react';
import XUIStepper from '@xero/xui/react/stepper';

const steps = [
  {
    currentProgress: 5,
    status: 'Complete',
    description: 'All sections answered',
    isComplete: true,
    isInProgress: true,
    name: 'Plan',
    totalProgress: 5
  },
  {
    currentProgress: 3,
    status: 'Error',
    description: 'Payment details are incomplete',
    isError: true,
    isInProgress: true,
    name: 'Billing',
    totalProgress: 5
  },
  {
    currentProgress: 3,
    status: 'Incomplete',
    description: 'Add/view subscription details',
    isInProgress: true,
    name: 'Subscription details',
    totalProgress: 5
  },
  { description: 'Review & pay', isDisabled: true, name: 'Review' }
];
const content = ['Select a plan', 'Payment details', 'Subscription details', 'Confirm purchase'];

const StepperExample = () => {
  const [currentStep, setCurrentStep] = useState(2);
  const headingRef = useRef();

  const updateCurrentStep = step => {
    setCurrentStep(step);
    // Send focus to the heading when the currentStep updates
    headingRef.current.focus();
  };

  return (
    <XUIStepper
      currentStep={currentStep}
      id="stepper-step-progress"
      lockLayout="stacked"
      stepTitle="Step"
      steps={steps}
      updateCurrentStep={updateCurrentStep}
    >
      <h3 ref={headingRef} tabIndex="0">
        {content[currentStep]}
      </h3>
    </XUIStepper>
  );
};

<StepperExample />;
```

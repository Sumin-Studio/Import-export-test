"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIRange", {
  enumerable: true,
  get: function () {
    return _XUIRange.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIRange.default;
  }
});
var _XUIRange = _interopRequireDefault(require("./components/range/XUIRange"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=range.js.map
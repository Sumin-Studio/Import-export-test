import XUIControlGroup, { type XUIControlGroupProps } from './components/controlgroup/XUIControlGroup';
export { XUIControlGroup as default, XUIControlGroup, type XUIControlGroupProps };

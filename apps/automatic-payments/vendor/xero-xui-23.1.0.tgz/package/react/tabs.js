"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUITab", {
  enumerable: true,
  get: function () {
    return _XUITab.default;
  }
});
Object.defineProperty(exports, "XUITabList", {
  enumerable: true,
  get: function () {
    return _XUITabList.default;
  }
});
Object.defineProperty(exports, "XUITabListLabel", {
  enumerable: true,
  get: function () {
    return _XUITabListLabel.default;
  }
});
Object.defineProperty(exports, "XUITabPanel", {
  enumerable: true,
  get: function () {
    return _XUITabPanel.default;
  }
});
Object.defineProperty(exports, "XUITabPanels", {
  enumerable: true,
  get: function () {
    return _XUITabPanels.default;
  }
});
Object.defineProperty(exports, "XUITabs", {
  enumerable: true,
  get: function () {
    return _XUITabs.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUITabs.default;
  }
});
var _XUITab = _interopRequireDefault(require("./components/tabs/XUITab"));
var _XUITabList = _interopRequireDefault(require("./components/tabs/XUITabList"));
var _XUITabListLabel = _interopRequireDefault(require("./components/tabs/XUITabListLabel"));
var _XUITabPanel = _interopRequireDefault(require("./components/tabs/XUITabPanel"));
var _XUITabPanels = _interopRequireDefault(require("./components/tabs/XUITabPanels"));
var _XUITabs = _interopRequireDefault(require("./components/tabs/XUITabs"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=tabs.js.map
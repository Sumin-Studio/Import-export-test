import XUIColumn, { type XUIColumnProps } from './components/structural/XUIColumn';
import XUIRow, { type XUIRowProps } from './components/structural/XUIRow';
export { XUIColumn, type XUIColumnProps, XUIRow, type XUIRowProps };

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIDateInput", {
  enumerable: true,
  get: function () {
    return _XUIDateInput.default;
  }
});
Object.defineProperty(exports, "XUIDateRangeInput", {
  enumerable: true,
  get: function () {
    return _XUIDateRangeInput.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIDateInput.default;
  }
});
var _XUIDateInput = _interopRequireDefault(require("./components/dateinput/XUIDateInput"));
var _XUIDateRangeInput = _interopRequireDefault(require("./components/dateinput/XUIDateRangeInput"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=dateinput.js.map
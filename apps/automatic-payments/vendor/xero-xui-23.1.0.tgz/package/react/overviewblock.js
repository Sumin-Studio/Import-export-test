"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIOverviewBlock", {
  enumerable: true,
  get: function () {
    return _XUIOverviewBlock.default;
  }
});
Object.defineProperty(exports, "XUIOverviewSection", {
  enumerable: true,
  get: function () {
    return _XUIOverviewSection.default;
  }
});
var _XUIOverviewBlock = _interopRequireDefault(require("./components/overviewblock/XUIOverviewBlock"));
var _XUIOverviewSection = _interopRequireDefault(require("./components/overviewblock/XUIOverviewSection"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=overviewblock.js.map
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUISwitch", {
  enumerable: true,
  get: function () {
    return _XUISwitch.default;
  }
});
Object.defineProperty(exports, "XUISwitchGroup", {
  enumerable: true,
  get: function () {
    return _XUISwitchGroup.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUISwitch.default;
  }
});
var _XUISwitch = _interopRequireDefault(require("./components/switch/XUISwitch"));
var _XUISwitchGroup = _interopRequireDefault(require("./components/switch/XUISwitchGroup"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=switch.js.map
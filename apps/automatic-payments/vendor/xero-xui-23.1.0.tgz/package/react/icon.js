"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIIcon", {
  enumerable: true,
  get: function () {
    return _XUIIcon.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIIcon.default;
  }
});
var _XUIIcon = _interopRequireDefault(require("./components/icon/XUIIcon"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=icon.js.map
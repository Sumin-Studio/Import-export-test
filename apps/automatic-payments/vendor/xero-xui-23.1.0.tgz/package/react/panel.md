<div class="xui-margin-vertical">
	<a href="../section-components-displayingdata-panel.html" isDocLink>Panels in the XUI Documentation</a>
</div>

Panels are top-level containers for grouping page content. XUIPanel can optionally accept XUIPanelHeader and XUIPanelFooter components as props, as well as content designated as a sidebar. XUIPanelHeading and XUIPanelSectionHeading components can also be passed through as the first child component of XUIPanel and XUIPanelSection respectively, if required.

#### Default Panel

```jsx harmony
import XUIActions from '@xero/xui/react/actions';
import XUIButton from '@xero/xui/react/button';
import XUIIcon from '@xero/xui/react/icon';
import XUIPanel from '@xero/xui/react/panel';
import external from '@xero/xui-icon/icons/external';

<XUIPanel className="xui-padding-large">
  <p>
    Xero has a new VAT return that's compatible with Making Tax Digital (MTD). MTD allows you to
    easily review and submit VAT returns directly to HMRC.
  </p>
  <p>
    Most businesses registered for VAT will have been notified by HMRC if they need to start
    submitting VAT returns using MTD Compatible software. If you don't set up MTD for VAT now, you
    can still do VAT returns and set up MTD for VAT later.
  </p>
  <p>
    <a href="#mtd">
      Learn more about MTD for VAT <XUIIcon icon={external} />
    </a>
  </p>
  <XUIActions
    className="xui-padding-top"
    primaryAction={<XUIButton variant="main">Set up MTD for VAT in Xero</XUIButton>}
    secondaryAction={<XUIButton>Go to VAT returns without MTD</XUIButton>}
  />
</XUIPanel>;
```

#### Panel with Sections

```jsx harmony
import XUIButton from '@xero/xui/react/button';
import XUIDateInput from '@xero/xui/react/dateinput';
import XUIPanel, { XUIPanelSection, XUIPanelSectionHeading } from '@xero/xui/react/panel';
import XUITextInput from '@xero/xui/react/textinput';

<XUIPanel>
  <XUIPanelSection className="xui-padding-large">
    <XUIPanelSectionHeading className="xui-margin-bottom" headingLevel={2}>
      Personal details
    </XUIPanelSectionHeading>
    <form className="xui-form-layout">
      <XUITextInput isFieldLayout label="Name" />
      <XUITextInput isFieldLayout label="Email" type="email" />
    </form>
  </XUIPanelSection>
  <XUIPanelSection className="xui-padding-large">
    <XUIPanelSectionHeading className="xui-margin-bottom" headingLevel={2}>
      Employment information
    </XUIPanelSectionHeading>
    <form className="xui-form-layout">
      <XUIDateInput
        datePickerAriaLabel="Choose date"
        inputLabel="Start date"
        isFieldLayout
        locale="en-NZ"
        monthDropdownAriaLabel="Select month"
        nextButtonAriaLabel="Next month"
        prevButtonAriaLabel="Previous month"
        yearDropdownAriaLabel="Select year"
      />
    </form>
  </XUIPanelSection>
</XUIPanel>;
```

#### Panel with Sidebar, Header, and Footer

Use the [tabs](#tabs) component with `XUIPanel` when you wish to include a sidebar and you are showing/hiding related content in the panel. Consult the [tabs](#tabs) documentation for further information on when this pattern is suitable.

```jsx harmony
import XUIActions from '@xero/xui/react/actions';
import XUIButton from '@xero/xui/react/button';
import XUIPanel, {
  XUIPanelFooter,
  XUIPanelHeader,
  XUIPanelHeading,
  XUIPanelSection,
  XUIPanelSectionHeading
} from '@xero/xui/react/panel';
import XUIPicklist, { XUIPickitem } from '@xero/xui/react/picklist';
import XUITextInput from '@xero/xui/react/textinput';
import plus from '@xero/xui-icon/icons/plus';
import { useState } from 'react';
import { XUITabs, XUITab, XUITabList, XUITabPanels, XUITabPanel } from '@xero/xui/react/tabs';

const PanelExample = () => {
  const [activeTabId, setActiveTabId] = useState('tab-3');

  const header = (
    <XUIPanelHeader>
      <XUIPanelHeading headingLevel={2}>Your information</XUIPanelHeading>
    </XUIPanelHeader>
  );

  const footer = (
    <XUIPanelFooter className="xui-padding-large">
      <XUIActions
        primaryAction={
          <XUIButton
            onClick={() => {
              console.log('onClick');
            }}
            variant="main"
          >
            Save
          </XUIButton>
        }
      />
    </XUIPanelFooter>
  );

  const sidebar = (
    <XUITabList
      aria-label="Your details"
      className="xui-margin-top-small xui-margin-bottom-small"
      orientation="vertical"
    >
      <XUITab>Personal details</XUITab>
      <XUITab>Employment information</XUITab>
      <XUITab id="tab-3">Payment information</XUITab>
    </XUITabList>
  );

  const onTabChange = targetId => {
    setActiveTabId(targetId);
  };

  return (
    <XUITabs activeTabId={activeTabId} onTabChange={onTabChange}>
      <XUIPanel footer={footer} header={header} sidebar={sidebar}>
        <XUIPanelSection className="xui-padding-large">
          <XUITabPanels>
            <XUITabPanel>
              <XUIPanelSectionHeading
                className="xui-text-align-left xui-form-layout xui-padding-vertical"
                headingLevel={2}
              >
                Personal details
              </XUIPanelSectionHeading>
              <form className="xui-form-layout">
                <XUITextInput defaultValue="Jane Smith" isFieldLayout label="Name" />
                <XUITextInput defaultValue="123456789" isFieldLayout label="Phone number" />
              </form>
            </XUITabPanel>
            <XUITabPanel>
              <XUIPanelSectionHeading
                className="xui-text-align-left xui-form-layout xui-padding-vertical"
                headingLevel={2}
              >
                Employment information
              </XUIPanelSectionHeading>
              <form className="xui-form-layout">
                <XUITextInput defaultValue="Xero" isFieldLayout label="Employer" />
              </form>
            </XUITabPanel>
            <XUITabPanel>
              <XUIPanelSectionHeading
                className="xui-text-align-left xui-form-layout xui-padding-vertical"
                headingLevel={2}
              >
                Payment details
              </XUIPanelSectionHeading>
              <XUIPanelSectionHeading
                className="xui-text-align-left xui-form-layout xui-padding-vertical xui-heading-small"
                headingLevel={3}
              >
                Primary bank account
              </XUIPanelSectionHeading>
              <form className="xui-form-layout">
                <XUITextInput defaultValue="Jane Smith" isFieldLayout label="Account name" />
                <XUITextInput
                  defaultValue="06-0705-0201419-000"
                  isFieldLayout
                  label="Account number"
                />
              </form>
            </XUITabPanel>
          </XUITabPanels>
        </XUIPanelSection>
      </XUIPanel>
    </XUITabs>
  );
};

<PanelExample />;
```

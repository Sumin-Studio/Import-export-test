"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIEmptyState.default;
  }
});
var _XUIEmptyState = _interopRequireDefault(require("./components/emptystate/XUIEmptyState"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=emptystate.js.map
import XUIIcon, { type XUIIconProps } from './components/icon/XUIIcon';
export { XUIIcon as default, XUIIcon, type XUIIconProps };

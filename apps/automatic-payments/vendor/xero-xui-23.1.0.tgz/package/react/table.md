<div class="xui-margin-vertical">
		<a href="../section-components-displayingdata-table.html" isDocLink>Table component in the XUI Documentation</a>
</div>

The Table scaffold is a convenient way to lay out data sets with an _accessible_ and _responsive_ design mindset.

The scaffold is broken up into three key components.<br />`import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';`

## Basic

The bare minimum _Table_ component requires a data schema and a basic _Column / Cell_ combination.

The `data` prop requires an object with **unique** keys that differentiate each row.

Each _Cell_ inside the _Column_ `body` prop is a function that passes through each row’s `data` independently so you can cherry pick the relevant content for a particular _Cell_.

```jsx harmony
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';
import { XUIButton } from '@xero/xui/react/button';

const data = {
  1: {
    number: 'INV-0001',
    ref: 'Monthly support',
    to: 'Apple',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 550.0,
    status: 'Draft',
    sent: false
  }
};

<XUITable
  data={data}
  loaderAriaLabel="Loading more data"
  emptyMessage="No invoices found"
  checkOneRowAriaLabel="Select row"
  checkAllRowsAriaLabel="Select all rows"
  caption="List of invoices"
>
  <XUITableColumn
    head={<XUITableCell>Number</XUITableCell>}
    body={({ number }) => <XUITableCell>{number}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Ref</XUITableCell>}
    body={({ ref }) => <XUITableCell>{ref}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>To</XUITableCell>}
    body={({ to }) => (
      <XUITableCell>
        <XUIButton>{to}</XUIButton>
      </XUITableCell>
    )}
  />
</XUITable>;
```

If there is no _JSX_ supplied to **any** _Column_ `head` prop the _Table_ `<th />` _Cells_ will **not** be rendered.

```jsx harmony
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';

const data = {
  1: {
    number: 'INV-0001',
    ref: 'Monthly support',
    to: 'Apple',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 550.0,
    status: 'Draft',
    sent: false
  }
};

<XUITable
  data={data}
  loaderAriaLabel="Loading more data"
  emptyMessage="No invoices found"
  checkOneRowAriaLabel="Select row"
  checkAllRowsAriaLabel="Select all rows"
  caption="List of invoices"
>
  <XUITableColumn body={({ number }) => <XUITableCell>{number}</XUITableCell>} />
  <XUITableColumn body={({ ref }) => <XUITableCell>{ref}</XUITableCell>} />
  <XUITableColumn body={({ to }) => <XUITableCell>{to}</XUITableCell>} />
</XUITable>;
```

## Responsive

The `isResponsive` tag allows the _Table_ to become horizontally scrollable when the amount of _Column_ content causes an overflow.

```jsx harmony
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';

const data = {
  1: {
    number: 'INV-0001',
    ref: 'Monthly support',
    to: 'Apple',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 550.0,
    status: 'Draft',
    sent: false
  },
  2: {
    number: 'INV-0002',
    ref: 'Software licenses',
    to: 'Microsoft',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 365.0,
    status: 'Awaiting payment',
    sent: false
  },
  3: {
    number: 'INV-0003',
    ref: 'Cloud services',
    to: 'Amazon',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 7890.5,
    status: 'Awaiting payment',
    sent: true
  }
};

const formatDate = date =>
  new Date(date).toLocaleDateString('en-NZ', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
const currencyFormatter = Intl.NumberFormat('en-NZ', { style: 'currency', currency: 'NZD' });

<XUITable
  data={data}
  isResponsive
  loaderAriaLabel="Loading more data"
  emptyMessage="No invoices found"
  checkOneRowAriaLabel="Select row"
  checkAllRowsAriaLabel="Select all rows"
  caption="List of invoices"
>
  <XUITableColumn
    head={<XUITableCell>Number</XUITableCell>}
    body={({ number }) => <XUITableCell>{number}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Ref</XUITableCell>}
    body={({ ref }) => <XUITableCell>{ref}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>To</XUITableCell>}
    body={({ to }) => <XUITableCell>{to}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Invoice date</XUITableCell>}
    body={({ date }) => <XUITableCell>{formatDate(date)}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Due date</XUITableCell>}
    body={({ dueDate }) => <XUITableCell>{formatDate(dueDate)}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Amount paid</XUITableCell>}
    body={({ paid }) => <XUITableCell>{currencyFormatter.format(paid)}</XUITableCell>}
    inlineAlignment="end"
  />
  <XUITableColumn
    head={<XUITableCell>Amount due</XUITableCell>}
    body={({ due }) => <XUITableCell>{currencyFormatter.format(due)}</XUITableCell>}
    inlineAlignment="end"
  />
  <XUITableColumn
    head={<XUITableCell>Status</XUITableCell>}
    body={({ status }) => <XUITableCell>{status}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Sent</XUITableCell>}
    body={({ sent }) => <XUITableCell>{sent ? 'Sent' : ''}</XUITableCell>}
  />
</XUITable>;
```

## Truncation

Changes overflowing _Column_ content into a truncated _Column_ view if a reasonable amount of legibility can still be maintained.

```jsx harmony
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';

const data = {
  1: {
    number: 'INV-0001',
    ref: 'Monthly support',
    to: 'Apple',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 550.0,
    status: 'Draft',
    sent: false
  },
  2: {
    number: 'INV-0002',
    ref: 'Software licenses',
    to: 'Microsoft',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 365.0,
    status: 'Awaiting payment',
    sent: false
  },
  3: {
    number: 'INV-0003',
    ref: 'Cloud services',
    to: 'Amazon',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 7890.5,
    status: 'Awaiting payment',
    sent: true
  }
};

const formatDate = date =>
  new Date(date).toLocaleDateString('en-NZ', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
const currencyFormatter = Intl.NumberFormat('en-NZ', { style: 'currency', currency: 'NZD' });

<XUITable
  data={data}
  isResponsive
  isTruncated
  loaderAriaLabel="Loading more data"
  emptyMessage="No invoices found"
  checkOneRowAriaLabel="Select row"
  checkAllRowsAriaLabel="Select all rows"
  caption="List of invoices"
>
  <XUITableColumn
    head={<XUITableCell>Number</XUITableCell>}
    body={({ number }) => <XUITableCell>{number}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Ref</XUITableCell>}
    body={({ ref }) => <XUITableCell>{ref}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>To</XUITableCell>}
    body={({ to }) => <XUITableCell>{to}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Invoice date</XUITableCell>}
    body={({ date }) => <XUITableCell>{formatDate(date)}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Due date</XUITableCell>}
    body={({ dueDate }) => <XUITableCell>{formatDate(dueDate)}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Amount paid</XUITableCell>}
    body={({ paid }) => <XUITableCell>{currencyFormatter.format(paid)}</XUITableCell>}
    inlineAlignment="end"
  />
  <XUITableColumn
    head={<XUITableCell>Amount due</XUITableCell>}
    body={({ due }) => <XUITableCell>{currencyFormatter.format(due)}</XUITableCell>}
    inlineAlignment="end"
  />
  <XUITableColumn
    head={<XUITableCell>Status</XUITableCell>}
    body={({ status }) => <XUITableCell>{status}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Sent</XUITableCell>}
    body={({ sent }) => <XUITableCell>{sent ? 'Sent' : ''}</XUITableCell>}
  />
</XUITable>;
```

## Wrapping

Wrapping can be defined on a per _Cell_ basis using the `hasWrapping` prop. By default a _Cell_ is **not** multiline.

**Note:** If `isTruncated` is set, `hasWrapping` cannot be applied to a cell within the table. This is because with `isTruncated` enabled, cells within that table will always be displayed as a single line.

```jsx harmony
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';

const data = {
  1: {
    number: 'INV-0001',
    ref: 'Monthly support',
    to: 'Apple',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 550.0,
    status: 'Draft',
    sent: false
  },
  2: {
    number: 'INV-0002',
    ref: 'Software licenses',
    to: 'Microsoft',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 365.0,
    status: 'Awaiting payment',
    sent: false
  },
  3: {
    number: 'INV-0003',
    ref: 'Cloud services',
    to: 'Amazon',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 7890.5,
    status: 'Awaiting payment',
    sent: true
  }
};

const formatDate = date =>
  new Date(date).toLocaleDateString('en-NZ', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
const currencyFormatter = Intl.NumberFormat('en-NZ', { style: 'currency', currency: 'NZD' });

<XUITable
  data={data}
  loaderAriaLabel="Loading more data"
  emptyMessage="No invoices found"
  checkOneRowAriaLabel="Select row"
  checkAllRowsAriaLabel="Select all rows"
  caption="List of invoices"
>
  <XUITableColumn
    head={<XUITableCell>Number</XUITableCell>}
    body={({ number }) => <XUITableCell>{number}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Ref</XUITableCell>}
    body={({ ref }) => <XUITableCell hasWrapping>{ref}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>To</XUITableCell>}
    body={({ to }) => <XUITableCell>{to}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Invoice date</XUITableCell>}
    body={({ date }) => <XUITableCell>{formatDate(date)}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Due date</XUITableCell>}
    body={({ dueDate }) => <XUITableCell>{formatDate(dueDate)}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Amount paid</XUITableCell>}
    body={({ paid }) => <XUITableCell>{currencyFormatter.format(paid)}</XUITableCell>}
    inlineAlignment="end"
  />
  <XUITableColumn
    head={<XUITableCell>Amount due</XUITableCell>}
    body={({ due }) => <XUITableCell>{currencyFormatter.format(due)}</XUITableCell>}
    inlineAlignment="end"
  />
  <XUITableColumn
    head={<XUITableCell>Status</XUITableCell>}
    body={({ status }) => <XUITableCell>{status}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Sent</XUITableCell>}
    body={({ sent }) => <XUITableCell>{sent ? 'Sent' : ''}</XUITableCell>}
  />
</XUITable>;
```

## Alignment

All cells except cells in the last column of the table align left by default. We recommend aligning numbers, including currency to the right. The `inlineAlignment` prop can be used on `XUITableColumn` to change the text alignment.

```jsx harmony
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';

const data = {
  1: {
    number: 'INV-0001',
    ref: 'Monthly support',
    to: 'Apple',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 550.0,
    status: 'Draft',
    sent: false
  }
};

const currencyFormatter = Intl.NumberFormat('en-NZ', { style: 'currency', currency: 'NZD' });

<XUITable
  data={data}
  loaderAriaLabel="Loading more data"
  emptyMessage="No invoices found"
  checkOneRowAriaLabel="Select row"
  checkAllRowsAriaLabel="Select all rows"
  caption="List of invoices"
>
  <XUITableColumn
    head={<XUITableCell>Number</XUITableCell>}
    body={({ number }) => <XUITableCell>{number}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Ref</XUITableCell>}
    body={({ ref }) => <XUITableCell>{ref}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>To</XUITableCell>}
    body={({ to }) => <XUITableCell>{to}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Amount paid</XUITableCell>}
    body={({ paid }) => <XUITableCell>{currencyFormatter.format(paid)}</XUITableCell>}
    inlineAlignment="end"
  />
  <XUITableColumn
    head={<XUITableCell>Amount due</XUITableCell>}
    body={({ due }) => <XUITableCell>{currencyFormatter.format(due)}</XUITableCell>}
    inlineAlignment="end"
  />
</XUITable>;
```

## Custom CSS Classes

Pass the `className` prop to the `<XUITable>` to add CSS classes to the outer most element of the the _Table_ scaffold.

```jsx harmony
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';

const data = {
  1: {
    number: 'INV-0001',
    ref: 'Monthly support',
    to: 'Apple',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 550.0,
    status: 'Draft',
    sent: false
  }
};
const node = document.createElement('style');

node.innerHTML = `
.xui-table-reactdocs-shadow {
	box-shadow: 0 0 0 1px rgba(50,70,90,0.2), 0 8px 16px 0 rgba(50,70,90,0.2);
}
`;
document.head.appendChild(node);

<XUITable
  data={data}
  className="xui-table-reactdocs-shadow"
  loaderAriaLabel="Loading more data"
  emptyMessage="No invoices found"
  checkOneRowAriaLabel="Select row"
  checkAllRowsAriaLabel="Select all rows"
  caption="List of invoices"
>
  <XUITableColumn
    head={<XUITableCell>Number</XUITableCell>}
    body={({ number }) => <XUITableCell>{number}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Ref</XUITableCell>}
    body={({ ref }) => <XUITableCell>{ref}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>To</XUITableCell>}
    body={({ to }) => <XUITableCell>{to}</XUITableCell>}
  />
</XUITable>;
```

Pass the `rowClassName` key in a row object of the `data` prop of `<XUITable>` to apply a custom class.

```jsx harmony
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';

const data = {
  1: {
    number: 'INV-0001',
    ref: 'Monthly support',
    to: 'Apple',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 550.0,
    status: 'Draft',
    sent: false,
    rowClassName: 'xui-table-reactdocs-row'
  }
};
const node = document.createElement('style');

node.innerHTML = `
.xui-table-reactdocs-row {
	font-weight: bold;
}
`;
document.head.appendChild(node);

<XUITable data={data} className="xui-table-reactdocs-shadow" caption="List of invoices">
  <XUITableColumn
    head={<XUITableCell>Number</XUITableCell>}
    body={({ number }) => <XUITableCell>{number}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Ref</XUITableCell>}
    body={({ ref }) => <XUITableCell>{ref}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>To</XUITableCell>}
    body={({ to }) => <XUITableCell>{to}</XUITableCell>}
  />
</XUITable>;
```

Pass the `className` prop to the `<XUITableCell>` to add CSS classes to each _Cell_ on an individual basis.

```jsx harmony
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';

const data = {
  1: {
    number: 'INV-0001',
    ref: 'Monthly support',
    to: 'Apple',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 550.0,
    status: 'Draft',
    sent: false
  },
  2: {
    number: 'INV-0002',
    ref: 'Software licenses',
    to: 'Microsoft',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 365.0,
    status: 'Awaiting payment',
    sent: false
  },
  3: {
    number: 'INV-0003',
    ref: 'Cloud services',
    to: 'Amazon',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 7890.5,
    status: 'Awaiting payment',
    sent: true
  }
};

const formatDate = date =>
  new Date(date).toLocaleDateString('en-NZ', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
const currencyFormatter = Intl.NumberFormat('en-NZ', { style: 'currency', currency: 'NZD' });

<XUITable
  data={data}
  loaderAriaLabel="Loading more data"
  emptyMessage="No invoices found"
  checkOneRowAriaLabel="Select row"
  checkAllRowsAriaLabel="Select all rows"
  overflowMenuColumnHeaderText="Actions"
  overflowMenuTitle="More row options"
  caption="List of invoices"
>
  <XUITableColumn
    head={<XUITableCell>Number</XUITableCell>}
    body={({ number }) => <XUITableCell>{number}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Ref</XUITableCell>}
    body={({ ref }) => <XUITableCell hasWrapping>{ref}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>To</XUITableCell>}
    body={({ to }) => <XUITableCell>{to}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Invoice date</XUITableCell>}
    body={({ date }) => <XUITableCell>{formatDate(date)}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Due date</XUITableCell>}
    body={({ dueDate }) => <XUITableCell>{formatDate(dueDate)}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Amount paid</XUITableCell>}
    body={({ paid }) => <XUITableCell>{currencyFormatter.format(paid)}</XUITableCell>}
    inlineAlignment="end"
  />
  <XUITableColumn
    head={<XUITableCell>Amount due</XUITableCell>}
    body={({ due }) => <XUITableCell>{currencyFormatter.format(due)}</XUITableCell>}
    inlineAlignment="end"
  />
  <XUITableColumn
    head={<XUITableCell>Status</XUITableCell>}
    body={({ status }) => <XUITableCell>{status}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell className="xui-heading-small">Sent</XUITableCell>}
    body={({ sent }) => (
      <XUITableCell className={sent ? 'xui-textcolor-positive' : 'xui-textcolor-negative'}>
        {sent ? 'Sent' : 'Not sent'}
      </XUITableCell>
    )}
  />
</XUITable>;
```

## Custom column width

`XUITable` has the `columnWidths` property which accepts an array of desired column widths. If using pixel values, we recommend setting at least one column to "auto" and setting a minWidth on the table itself, to avoid excess shrinkage.
Alternatively, you can specify widths on the cells in the first row (this may be the header cells). This is helpful if you expect the columns to change and would prefer not to maintain the ordered array.

When calculating a table `maxWidth` to match the sum of explicit column widths, include space for 1px cell borders. Otherwise, the widths of the cell borders will cause the table to overflow horizontally, and you will see the scroll-indicator overlay shadow

When passing `minWidth` together with `columnWidths` as pixel values (without an `auto` sized column), make sure that `minWidth` doesn't exceed the sum of all the column widths. If it does, utility button columns (like delete or drag and drop) will stretch and lose proper size.

### Custom widths with responsive behaviour

To use custom column widths in the table while maintaining some responsive behaviour, use the [container query](#container-queries) or [resize observer](#resize-observers) APIs.

The resize observer API can be used to programmatically adjust the `columnWidths` object, while the container query API can be used to adjust the `columnWidths` object according to the default breakpoints and/or breakpoints you define yourself.

See the code snippet below for an example of the container query API.

Try to resize: Click and drag the bottom right corner of the following container.

```jsx harmony
import React from 'react';
import useContainerQuery from '@xero/xui/react/helpers/useContainerQuery';
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';

const wrapperStyles = {
  resize: 'horizontal',
  overflow: 'hidden'
};

const data = {
  1: {
    number: 'INV-0001',
    ref: 'Monthly support',
    to: 'Apple',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 550.0,
    status: 'Draft',
    sent: false
  },
  2: {
    number: 'INV-0002',
    ref: 'Software licenses',
    to: 'Microsoft',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 365.0,
    status: 'Awaiting payment',
    sent: false
  },
  3: {
    number: 'INV-0003',
    ref: 'Cloud services',
    to: 'Amazon',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 7890.5,
    status: 'Awaiting payment',
    sent: true
  }
};

const ResponsiveColumnWidthsExample = () => {
  const { isWidthAboveBreakpoint, observedElementRef } = useContainerQuery();

  let columnWidths = ['33%', '33%', '33%'];

  // start with larger breakpoints for the shortest code path
  if (isWidthAboveBreakpoint('small')) {
    columnWidths = ['40%', '20%', '20%'];
  } else if (isWidthAboveBreakpoint('xsmall')) {
    columnWidths = ['20%', '60%', '20%'];
  }

  return (
    <div className="xui-panel xui-padding-xlarge" ref={observedElementRef} style={wrapperStyles}>
      <XUITable
        data={data}
        columnWidths={columnWidths}
        minWidth="250px"
        loaderAriaLabel="Loading more data"
        emptyMessage="No invoices found"
        checkOneRowAriaLabel="Select row"
        checkAllRowsAriaLabel="Select all rows"
        caption="List of invoices"
      >
        <XUITableColumn
          head={<XUITableCell>Number</XUITableCell>}
          body={({ number }) => <XUITableCell>{number}</XUITableCell>}
        />
        <XUITableColumn
          head={<XUITableCell>Ref</XUITableCell>}
          body={({ ref }) => <XUITableCell>{ref}</XUITableCell>}
        />
        <XUITableColumn
          head={<XUITableCell>To</XUITableCell>}
          body={({ to }) => <XUITableCell>{to}</XUITableCell>}
        />
      </XUITable>
    </div>
  );
};

<ResponsiveColumnWidthsExample />;
```

## Checkboxes

Prepend the table rows with a check box action with the `hasCheckbox` prop.

Each row's _Checked_ state is derived from checking for _"truthy"_ row key / value pairs in the `checkedIds` prop.

Each row's _Disabled_ state is derived from checking for _"truthy"_ row key / value pairs in the `disabledIds` prop.

**Note: Make sure the state of the _disabled_ checkbox will not be changed via the bulk-select. For reference, There's an example `onCheckAllToggle` callback function below.**

Interactions for the _"master"_ and _"single"_ checkbox toggles can be handled using the `onCheckAllToggle` and `onCheckOneToggle` props. If you provide these, you must also provide the corresponding `checkAllRowsAriaLabel` and `checkOneRowAriaLabel` for accessibility purposes.

The header checkbox state is derived from comparing `checkedIds` with `data`. You can override this using `checkAllValue` and `isCheckAllDisabled`. This is useful for paginated data, where the selection might be larger than the currently displayed data.

```jsx harmony
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';
import { useState } from 'react';

const data = {
  1: {
    number: 'INV-0001',
    ref: 'Monthly support',
    to: 'Apple',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 550.0,
    status: 'Draft',
    sent: false
  },
  2: {
    number: 'INV-0002',
    ref: 'Software licenses',
    to: 'Microsoft',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 365.0,
    status: 'Awaiting payment',
    sent: false
  },
  3: {
    number: 'INV-0003',
    ref: 'Cloud services',
    to: 'Amazon',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 7890.5,
    status: 'Awaiting payment',
    sent: true
  }
};

const CheckboxesExample = () => {
  const [checkedIds, setCheckedIds] = useState({ 1: true, 2: false, 3: true });
  const [disabledIds, setDisabledIds] = useState({ 3: true });
  const [activeSortKey, setActiveSortKey] = useState('number');
  const [isSortAsc, setIsSortAsc] = useState(true);

  const handleCheckAllToggle = () => {
    const dataKeys = Object.keys(data);
    let totalData = dataKeys.length;
    const keepCheckedIds = {};
    const keepUncheckedIds = {};
    let totalChecked = Object.keys(checkedIds).reduce(
      (acc, key) => (checkedIds[key] ? acc + 1 : acc),
      0
    );
    Object.keys(disabledIds).forEach(key => {
      if (checkedIds[key]) {
        keepCheckedIds[key] = true;
      } else {
        keepUncheckedIds[key] = true;
        totalChecked++;
      }
    });
    if (totalData === totalChecked) {
      setCheckedIds({ ...keepCheckedIds });
    } else {
      setCheckedIds(dataKeys.reduce((acc, key) => ({ ...acc, [key]: !keepUncheckedIds[key] }), {}));
    }
  };

  const handleCheckOneToggle = (event, _id) => {
    const isChecked = Boolean(checkedIds[_id]);
    setCheckedIds({ ...checkedIds, [_id]: !isChecked });
  };

  const handleSortChange = newKey => {
    const newIsAsc = activeSortKey === newKey ? !isSortAsc : true;
    setActiveSortKey(newKey);
    setIsSortAsc(newIsAsc);
  };

  return (
    <XUITable
      activeSortKey={activeSortKey}
      caption="List of invoices"
      checkAllRowsAriaLabel="Select all rows"
      checkboxColumnHiddenHeaderText="Row selection actions"
      checkedIds={checkedIds}
      checkOneRowAriaLabel="Select row"
      data={data}
      disabledIds={disabledIds}
      emptyMessage="No invoices found"
      hasCheckbox
      isSortAsc={isSortAsc}
      loaderAriaLabel="Loading more data"
      onCheckAllToggle={handleCheckAllToggle}
      onCheckOneToggle={handleCheckOneToggle}
      onSortChange={handleSortChange}
      overflowMenuTitle="More row options"
    >
      <XUITableColumn
        head={<XUITableCell>Number</XUITableCell>}
        body={({ number }) => <XUITableCell>{number}</XUITableCell>}
      />
      <XUITableColumn
        head={<XUITableCell>Ref</XUITableCell>}
        body={({ ref }) => <XUITableCell>{ref}</XUITableCell>}
      />
      <XUITableColumn
        head={<XUITableCell>To</XUITableCell>}
        body={({ to }) => <XUITableCell>{to}</XUITableCell>}
      />
    </XUITable>
  );
};

<CheckboxesExample />;
```

## Overflow Menu

You can append a menu to a table row by adding `hasOverflowMenu` and providing a `createOverflowMenu` function. The menu will not be rendered if you don’t provide these; however, if you do, you must also provide an `overviewMenuColumnHeaderText` and `overflowMenuTitle` for accessibility purposes.

```jsx harmony
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';
import { XUIPickitem } from '@xero/xui/react/picklist';

const data = {
  1: {
    number: 'INV-0001',
    ref: 'Monthly support',
    to: 'Apple',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 550.0,
    status: 'Draft',
    sent: false
  },
  2: {
    number: 'INV-0002',
    ref: 'Software licenses',
    to: 'Microsoft',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 365.0,
    status: 'Awaiting payment',
    sent: false
  },
  3: {
    number: 'INV-0003',
    ref: 'Cloud services',
    to: 'Amazon',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 7890.5,
    status: 'Awaiting payment',
    sent: true
  }
};

<XUITable
  data={data}
  hasOverflowMenu
  createOverflowMenu={({ to, sent }) =>
    !sent && [
      <XUIPickitem key="0" id="0" onClick={() => alert(`Send invoice to ${to}`)}>
        Send invoice to {to}
      </XUIPickitem>
    ]
  }
  loaderAriaLabel="Loading more data"
  emptyMessage="No invoices found"
  checkOneRowAriaLabel="Select row"
  checkAllRowsAriaLabel="Select all rows"
  overflowMenuColumnHeaderText="Actions"
  overflowMenuTitle="More row options"
  caption="List of invoices"
>
  <XUITableColumn
    head={<XUITableCell>Number</XUITableCell>}
    body={({ number }) => <XUITableCell>{number}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Ref</XUITableCell>}
    body={({ ref }) => <XUITableCell>{ref}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>To</XUITableCell>}
    body={({ to }) => <XUITableCell>{to}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Sent</XUITableCell>}
    body={({ sent }) => <XUITableCell>{sent ? 'Sent' : ''}</XUITableCell>}
  />
</XUITable>;
```

## Pinned Actions

If an **action** column is **active** in the _Table_ it can be pinned to the relevant side of the scaffold.

- **Checkboxes** are pinned to the left of the scaffold by using the `hasPinnedFirstColumn` prop.
- **Overflow Menu** are pinned to the right of the scaffold by using the `hasPinnedLastColumn` prop.

```jsx harmony
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';
import { XUIPickitem } from '@xero/xui/react/picklist';
import { useState } from 'react';

const data = {
  1: {
    number: 'INV-0001',
    ref: 'Monthly support',
    to: 'Apple',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 550.0,
    status: 'Draft',
    sent: false
  }
};

const PinnedActionsExample = () => {
  const [checkedIds, setCheckedIds] = useState({});

  const handleCheckAllToggle = () => {
    const dataKeys = Object.keys(data);
    const totalData = dataKeys.length;
    const totalChecked = Object.keys(checkedIds).reduce(
      (acc, key) => (checkedIds[key] ? acc + 1 : acc),
      0
    );
    if (totalData === totalChecked) {
      setCheckedIds({});
    } else {
      setCheckedIds(dataKeys.reduce((acc, key) => ({ ...acc, [key]: true }), {}));
    }
  };

  const handleCheckOneToggle = (event, _id) => {
    const isChecked = Boolean(checkedIds[_id]);
    setCheckedIds({ ...checkedIds, [_id]: !isChecked });
  };

  const currencyFormatter = Intl.NumberFormat('en-NZ', { style: 'currency', currency: 'NZD' });

  return (
    <XUITable
      caption="List of invoices"
      checkAllRowsAriaLabel="Select all rows"
      checkboxColumnHiddenHeaderText="Row selection actions"
      checkedIds={checkedIds}
      checkOneRowAriaLabel="Select row"
      createOverflowMenu={() => [
        <XUIPickitem key="0" id="0" onClick={() => {}}>
          Edit
        </XUIPickitem>
      ]}
      data={data}
      emptyMessage="No invoices found"
      hasCheckbox
      hasOverflowMenu
      hasPinnedFirstColumn
      hasPinnedLastColumn
      isResponsive
      loaderAriaLabel="Loading more data"
      onCheckAllToggle={handleCheckAllToggle}
      onCheckOneToggle={handleCheckOneToggle}
      overflowMenuColumnHeaderText="Actions"
      overflowMenuTitle="More row options"
    >
      <XUITableColumn
        head={<XUITableCell>Number</XUITableCell>}
        body={({ number }) => <XUITableCell>{number}</XUITableCell>}
      />
      <XUITableColumn
        head={<XUITableCell>Ref</XUITableCell>}
        body={({ ref }) => <XUITableCell>{ref}</XUITableCell>}
      />
      <XUITableColumn
        head={<XUITableCell>To</XUITableCell>}
        body={({ to }) => <XUITableCell>{to}</XUITableCell>}
      />
      <XUITableColumn
        head={<XUITableCell>Invoice date</XUITableCell>}
        body={({ date }) => (
          <XUITableCell>
            {new Date(date).toLocaleDateString('en-NZ', {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            })}
          </XUITableCell>
        )}
      />
      <XUITableColumn
        head={<XUITableCell>Due date</XUITableCell>}
        body={({ dueDate }) => (
          <XUITableCell>
            {new Date(dueDate).toLocaleDateString('en-NZ', {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            })}
          </XUITableCell>
        )}
      />
      <XUITableColumn
        head={<XUITableCell>Amount paid</XUITableCell>}
        body={({ paid }) => <XUITableCell>{currencyFormatter.format(paid)}</XUITableCell>}
        inlineAlignment="end"
      />
      <XUITableColumn
        head={<XUITableCell>Amount due</XUITableCell>}
        body={({ due }) => <XUITableCell>{currencyFormatter.format(due)}</XUITableCell>}
        inlineAlignment="end"
      />
      <XUITableColumn
        head={<XUITableCell>Status</XUITableCell>}
        body={({ status }) => <XUITableCell>{status}</XUITableCell>}
      />
      <XUITableColumn
        head={<XUITableCell>Sent</XUITableCell>}
        body={({ sent }) => <XUITableCell>{sent ? 'Sent' : ''}</XUITableCell>}
      />
    </XUITable>
  );
};

<PinnedActionsExample />;
```

### Disabling pinned actions

For enhanced accessibility, you can disable pinned actions at a given breakpoint, using the `disablePinnedColumnsAtBreakpoint` prop. This can be helpful for users with visual impairments which require a high zoom level, to avoid pinned actions covering the content of the table itself.

You can use a preset breakpoint, or specify your own (in px).

```jsx harmony
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';
import { XUIPickitem } from '@xero/xui/react/picklist';
import { useState } from 'react';

const data = {
  1: {
    number: 'INV-0001',
    ref: 'Monthly support',
    to: 'Apple',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 550.0,
    status: 'Draft',
    sent: false
  }
};

const PinnedActionsBreakpointExample = () => {
  const [checkedIds, setCheckedIds] = useState({});

  const handleCheckAllToggle = () => {
    const dataKeys = Object.keys(data);
    const totalData = dataKeys.length;
    const totalChecked = Object.keys(checkedIds).reduce(
      (acc, key) => (checkedIds[key] ? acc + 1 : acc),
      0
    );
    if (totalData === totalChecked) {
      setCheckedIds({});
    } else {
      setCheckedIds(dataKeys.reduce((acc, key) => ({ ...acc, [key]: true }), {}));
    }
  };

  const handleCheckOneToggle = (event, _id) => {
    const isChecked = Boolean(checkedIds[_id]);
    setCheckedIds({ ...checkedIds, [_id]: !isChecked });
  };

  const currencyFormatter = Intl.NumberFormat('en-NZ', { style: 'currency', currency: 'NZD' });

  return (
    <XUITable
      caption="List of invoices"
      checkAllRowsAriaLabel="Select all rows"
      checkboxColumnHiddenHeaderText="Row selection actions"
      checkedIds={checkedIds}
      checkOneRowAriaLabel="Select row"
      createOverflowMenu={() => [
        <XUIPickitem key="0" id="0" onClick={() => {}}>
          Edit
        </XUIPickitem>
      ]}
      data={data}
      disablePinnedColumnsAtBreakpoint="large"
      emptyMessage="Nothing to show here"
      hasCheckbox
      hasOverflowMenu
      hasPinnedFirstColumn
      hasPinnedLastColumn
      isResponsive
      loaderAriaLabel="Loading more data"
      onCheckAllToggle={handleCheckAllToggle}
      onCheckOneToggle={handleCheckOneToggle}
      overflowMenuColumnHeaderText="Actions"
      overflowMenuTitle="More row options"
    >
      <XUITableColumn
        head={<XUITableCell>Number</XUITableCell>}
        body={({ number }) => <XUITableCell>{number}</XUITableCell>}
      />
      <XUITableColumn
        head={<XUITableCell>Ref</XUITableCell>}
        body={({ ref }) => <XUITableCell>{ref}</XUITableCell>}
      />
      <XUITableColumn
        head={<XUITableCell>To</XUITableCell>}
        body={({ to }) => <XUITableCell>{to}</XUITableCell>}
      />
      <XUITableColumn
        head={<XUITableCell>Invoice date</XUITableCell>}
        body={({ date }) => (
          <XUITableCell>
            {new Date(date).toLocaleDateString('en-NZ', {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            })}
          </XUITableCell>
        )}
      />
      <XUITableColumn
        head={<XUITableCell>Due date</XUITableCell>}
        body={({ dueDate }) => (
          <XUITableCell>
            {new Date(dueDate).toLocaleDateString('en-NZ', {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            })}
          </XUITableCell>
        )}
      />
      <XUITableColumn
        head={<XUITableCell>Amount paid</XUITableCell>}
        body={({ paid }) => <XUITableCell>{currencyFormatter.format(paid)}</XUITableCell>}
        inlineAlignment="end"
      />
      <XUITableColumn
        head={<XUITableCell>Amount due</XUITableCell>}
        body={({ due }) => <XUITableCell>{currencyFormatter.format(due)}</XUITableCell>}
        inlineAlignment="end"
      />
      <XUITableColumn
        head={<XUITableCell>Status</XUITableCell>}
        body={({ status }) => <XUITableCell>{status}</XUITableCell>}
      />
      <XUITableColumn
        head={<XUITableCell>Sent</XUITableCell>}
        body={({ sent }) => <XUITableCell>{sent ? 'Sent' : ''}</XUITableCell>}
      />
    </XUITable>
  );
};

<PinnedActionsBreakpointExample />;
```

## Sorting

Convert _Column_ `head` cells into buttons with sorting functionality by introducing the following props.

- `sortKey` affiliates a `head` _Cell_ with a key value in the `data` schema.
- `activeSortKey` determines which `sortKey` should be used to sort the _Table_ rows.
- `isSortAsc` defines the sort order to be _ascending_ / _descending_.

### Custom sorting

By default sorting is determined by a generic [sort](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/sort) function. This provides basic alphabetical and numerical ordering out of the box.

By supplying the `customSort` prop you can create your own custom sort system. In this example we are sorting the `tags` column based on the length of the supplied array in each row.

```jsx harmony
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';
import { XUITag } from '@xero/xui/react/tag';
import { useState } from 'react';

const data = {
  1: {
    number: 'INV-0001',
    ref: 'Monthly support',
    to: 'Apple',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 550.0,
    status: 'Draft',
    sent: false,
    tags: [{ name: 'Recurring', variant: 'positive' }]
  },
  2: {
    number: 'INV-0002',
    ref: 'Software licenses',
    to: 'Microsoft',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 365.0,
    status: 'Awaiting payment',
    sent: false,
    tags: [
      { name: 'Recurring', variant: 'positive' },
      { name: 'Annual', variant: 'neutral' }
    ]
  },
  3: {
    number: 'INV-0003',
    ref: 'Cloud services',
    to: 'Amazon',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 7890.5,
    status: 'Awaiting payment',
    sent: true,
    tags: [
      { name: 'Recurring', variant: 'positive' },
      { name: 'Annual', variant: 'neutral' },
      { name: 'Services', variant: 'standard' }
    ]
  }
};

const CustomSortingExample = () => {
  const [activeSortKey, setActiveSortKey] = useState('to');
  const [isSortAsc, setIsSortAsc] = useState(true);

  const handleSortChange = newKey => {
    const newIsAsc = activeSortKey === newKey ? !isSortAsc : true;
    setActiveSortKey(newKey);
    setIsSortAsc(newIsAsc);
  };

  const handleTagSort = (items, isAsc) => {
    const comparison = isAsc
      ? (a, b) => a.tags.length > b.tags.length
      : (a, b) => a.tags.length < b.tags.length;
    return items.sort((a, b) => (comparison(a, b) ? 1 : -1));
  };

  return (
    <XUITable
      data={data}
      activeSortKey={activeSortKey}
      isSortAsc={isSortAsc}
      onSortChange={handleSortChange}
      customSort={activeSortKey === 'tags' ? handleTagSort : null}
      loaderAriaLabel="Loading more data"
      emptyMessage="No invoices found"
      checkOneRowAriaLabel="Select row"
      checkAllRowsAriaLabel="Select all rows"
      caption="List of fruits with tags and sorting"
    >
      <XUITableColumn
        head={<XUITableCell sortKey="number">Number</XUITableCell>}
        body={({ number }) => <XUITableCell>{number}</XUITableCell>}
      />
      <XUITableColumn
        head={<XUITableCell sortKey="ref">Ref</XUITableCell>}
        body={({ ref }) => <XUITableCell>{ref}</XUITableCell>}
      />
      <XUITableColumn
        head={<XUITableCell sortKey="to">To</XUITableCell>}
        body={({ to }) => <XUITableCell>{to}</XUITableCell>}
      />
      <XUITableColumn
        head={<XUITableCell sortKey="tags">Tags</XUITableCell>}
        body={({ tags }) => (
          <XUITableCell>
            {tags.map(({ name, variant }, index) => (
              <XUITag
                key={index}
                className={index == tags.length - 1 ? '' : 'xui-margin-right-xsmall'}
                variant={variant}
              >
                {name}
              </XUITag>
            ))}
          </XUITableCell>
        )}
      />
    </XUITable>
  );
};

<CustomSortingExample />;
```

## Header / Footer

Inject custom _JSX_ into the header and footer area of the _Table_ with the `header` and `footer` props.

```jsx harmony
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';

const data = {
  1: {
    number: 'INV-0001',
    ref: 'Monthly support',
    to: 'Apple',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 550.0,
    status: 'Draft',
    sent: false
  }
};
const Header = () => (
  <div className="xui-heading xui-heading-medium xui-padding-vertical-large xui-padding-horizontal-small">
    Invoices
  </div>
);

const Footer = () => (
  <div className="xui-heading xui-heading-xsmall xui-padding-vertical-small xui-padding-horizontal-small">
    Total invoices 1
  </div>
);

<XUITable
  data={data}
  header={<Header />}
  footer={<Footer />}
  loaderAriaLabel="Loading more data"
  emptyMessage="No invoices found"
  checkOneRowAriaLabel="Select row"
  checkAllRowsAriaLabel="Select all rows"
  caption="List of invoices with invoice number, reference, and recipient"
>
  <XUITableColumn
    head={<XUITableCell>Number</XUITableCell>}
    body={({ number }) => <XUITableCell>{number}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Ref</XUITableCell>}
    body={({ ref }) => <XUITableCell>{ref}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>To</XUITableCell>}
    body={({ to }) => <XUITableCell>{to}</XUITableCell>}
  />
</XUITable>;
```

## With pagination

If you’re dealing with large amounts of data, you can pass a [`<XUIPagination />`](#pagination) to the `footer`.

### Fixing column widths

As the user navigates between pages of table content the table columns may change width to match the content.

To prevent this you can fix the column widths of the table one of three ways.

1. Provide the table with specific column widths.
2. Set the table's `useFixedLayout` prop to `true`, this will tell the table to calculate the column widths based on the first row (heading row) which shouldn't change as the user navigates through the table data.
3. Use the prop `columnWidths` of `XUITable`.

```jsx
import { useEffect, useState } from 'react';
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';
import { XUIPagination } from '@xero/xui/react/pagination';
import {
  defaultCreateCountContent,
  defaultCreatePagingContent
} from './components/pagination/private/helpers';

const data = {
  1: { number: 'INV-0001', to: 'Apple', paid: 0.0, due: 550.0 },
  2: { number: 'INV-0002', to: 'Microsoft', paid: 0.0, due: 365.0 },
  3: { number: 'INV-0003', to: 'Amazon', paid: 0.0, due: 7890.5 },
  4: { number: 'INV-0004', to: 'Apple', paid: 0.0, due: 550.0 },
  5: { number: 'INV-0005', to: 'Microsoft', paid: 0.0, due: 365.0 },
  6: { number: 'INV-0006', to: 'Amazon', paid: 0.0, due: 7890.5 },
  7: { number: 'INV-0007', to: 'Apple', paid: 0.0, due: 550.0 },
  8: { number: 'INV-0008', to: 'Microsoft', paid: 0.0, due: 365.0 },
  9: { number: 'INV-0009', to: 'Amazon', paid: 0.0, due: 7890.5 },
  10: { number: 'INV-0010', to: 'Apple', paid: 0.0, due: 550.0 },
  11: { number: 'INV-0011', to: 'Microsoft', paid: 0.0, due: 365.0 },
  12: { number: 'INV-0012', to: 'Amazon', paid: 0.0, due: 7890.5 },
  13: { number: 'INV-0013', to: 'Apple', paid: 0.0, due: 550.0 },
  14: { number: 'INV-0014', to: 'Microsoft', paid: 0.0, due: 365.0 },
  15: { number: 'INV-0015', to: 'Amazon', paid: 0.0, due: 7890.5 },
  16: { number: 'INV-0016', to: 'Apple', paid: 0.0, due: 550.0 },
  17: { number: 'INV-0017', to: 'Microsoft', paid: 0.0, due: 365.0 },
  18: { number: 'INV-0018', to: 'Amazon', paid: 0.0, due: 7890.5 },
  19: { number: 'INV-0019', to: 'Apple', paid: 0.0, due: 550.0 },
  20: { number: 'INV-0020', to: 'Microsoft', paid: 0.0, due: 365.0 },
  21: { number: 'INV-0021', to: 'Amazon', paid: 0.0, due: 7890.5 },
  22: { number: 'INV-0022', to: 'Apple', paid: 0.0, due: 550.0 },
  23: { number: 'INV-0023', to: 'Microsoft', paid: 0.0, due: 365.0 },
  24: { number: 'INV-0024', to: 'Amazon', paid: 0.0, due: 7890.5 },
  25: { number: 'INV-0025', to: 'Apple', paid: 0.0, due: 550.0 }
};

const defaultPerPageCountOptions = [10, 25, 50, 100, 200];

const [page, setPage] = useState(1);
const [perPageCount, setPerPageCount] = useState(defaultPerPageCountOptions[0]);
const [tableData, setTableData] = useState(data);
const [dataLength, setDataLength] = useState(Object.keys(data).length);

useEffect(() => {
  setDataLength(Object.keys(data).length);
}, [data]);

useEffect(() => {
  onPageChange(page);
}, [page, perPageCount]);

const onPageChange = page => {
  setPage(page);

  const firstIndex = (page - 1) * perPageCount;
  const lastIndex = firstIndex + perPageCount;

  const filteredTableData = Object.entries(data).reduce((acc, [rowIndex, row], index) => {
    if (index >= firstIndex && index < lastIndex) {
      acc[rowIndex] = row;
    }
    return acc;
  }, {});

  setTableData(filteredTableData);
};

const onPerPageCountChange = perPageCount => {
  setPerPageCount(perPageCount);

  const pageCount = Math.ceil(data.length / perPageCount);

  setPage(page > pageCount ? pageCount : page);
};

const currencyFormatter = Intl.NumberFormat('en-NZ', { style: 'currency', currency: 'NZD' });

<XUITable
  data={tableData}
  loaderAriaLabel="Loading more data"
  emptyMessage="No invoices found"
  checkOneRowAriaLabel="Select row"
  checkAllRowsAriaLabel="Select all rows"
  caption="List of invoices"
  footer={
    <XUIPagination
      ariaLabel="Pagination"
      count={dataLength}
      createCountContent={defaultCreateCountContent}
      createPagingContent={defaultCreatePagingContent}
      nextPageLabel="Next Page"
      onPageChange={onPageChange}
      onPerPageCountChange={onPerPageCountChange}
      page={page}
      pageSelectLabel="Select a page"
      perPageContent="Items per page"
      perPageCount={perPageCount}
      previousPageLabel="Previous Page"
    />
  }
  useFixedLayout
>
  <XUITableColumn
    head={<XUITableCell>Number</XUITableCell>}
    body={({ number }) => <XUITableCell>{number}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>To</XUITableCell>}
    body={({ to }) => <XUITableCell>{to}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Amount paid</XUITableCell>}
    body={({ paid }) => <XUITableCell>{currencyFormatter.format(paid)}</XUITableCell>}
    inlineAlignment="end"
  />
  <XUITableColumn
    head={<XUITableCell>Amount due</XUITableCell>}
    body={({ due }) => <XUITableCell>{currencyFormatter.format(due)}</XUITableCell>}
    inlineAlignment="end"
  />
</XUITable>;
```

## Loader

Appends a `<XUILoader />` after the last _Row_ in the _Table_ with the `isLoading` prop. If you provide this prop, you must also provide a `loaderAriaLabel` for accessibility purposes.

```jsx harmony
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';

const data = {
  1: {
    number: 'INV-0001',
    ref: 'Monthly support',
    to: 'Apple',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 550.0,
    status: 'Draft',
    sent: false
  },
  2: {
    number: 'INV-0002',
    ref: 'Software licenses',
    to: 'Microsoft',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 365.0,
    status: 'Awaiting payment',
    sent: false
  },
  3: {
    number: 'INV-0003',
    ref: 'Cloud services',
    to: 'Amazon',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 7890.5,
    status: 'Awaiting payment',
    sent: true
  }
};

<XUITable
  data={data}
  isLoading
  loaderAriaLabel="Loading more data"
  emptyMessage="No invoices found"
  checkOneRowAriaLabel="Select row"
  checkAllRowsAriaLabel="Select all rows"
  caption="List of invoices"
>
  <XUITableColumn
    head={<XUITableCell>Number</XUITableCell>}
    body={({ number }) => <XUITableCell>{number}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Ref</XUITableCell>}
    body={({ ref }) => <XUITableCell>{ref}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>To</XUITableCell>}
    body={({ to }) => <XUITableCell>{to}</XUITableCell>}
  />
</XUITable>;
```

## Links

Ensure that any links in tables use anchor (`<a />`) tags, and that the link text describes the link destination. Consider bolding a single column to support scanning, which may contain either linked or non-linked content. Only include interactive components such as `XUICheckbox` and overflow menu buttons in the far left and far right cells.

The `xui-text-minorlink` class is automatically applied to provide appropriate link text styling.

### Single destination

Use the `onRowClick` prop and ensure that it takes users to the same destination as the link. Use the `shouldRowClick` parameter to control which rows will have an `onclick` given the row data.

```jsx harmony
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';
import { XUIPickitem } from '@xero/xui/react/picklist';
import { useState } from 'react';

const data = {
  1: {
    number: 'INV-001',
    ref: 'Monthly support',
    to: 'Apple',
    due: 550.0
  },
  2: {
    number: 'INV-002',
    ref: 'Software licenses',
    to: 'Microsoft',
    due: 365.0
  },
  3: {
    number: 'INV-003',
    ref: 'Cloud services',
    to: 'Amazon',
    due: 7890.5
  }
};

const SingleDestinationExample = () => {
  const [checkedIds, setCheckedIds] = useState({});

  const handleCheckAllToggle = () => {
    const dataKeys = Object.keys(data);
    const totalData = dataKeys.length;
    const totalChecked = Object.keys(checkedIds).reduce(
      (acc, key) => (checkedIds[key] ? acc + 1 : acc),
      0
    );
    if (totalData === totalChecked) {
      setCheckedIds({});
    } else {
      setCheckedIds(dataKeys.reduce((acc, key) => ({ ...acc, [key]: true }), {}));
    }
  };

  const handleCheckOneToggle = (event, _id) => {
    const isChecked = Boolean(checkedIds[_id]);
    setCheckedIds({ ...checkedIds, [_id]: !isChecked });
  };

  const currencyFormatter = Intl.NumberFormat('en-NZ', { style: 'currency', currency: 'NZD' });

  const test = () => console.log('test');

  return (
    <XUITable
      caption="List of invoices"
      checkAllRowsAriaLabel="Select all rows"
      checkboxColumnHiddenHeaderText="Row selection actions"
      checkedIds={checkedIds}
      checkOneRowAriaLabel="Select row"
      createOverflowMenu={() => [
        <XUIPickitem key="0" id="0" onClick={() => {}}>
          Pay
        </XUIPickitem>
      ]}
      data={data}
      emptyMessage="No invoices found"
      hasCheckbox
      hasOverflowMenu
      isResponsive
      loaderAriaLabel="Loading more data"
      onCheckAllToggle={handleCheckAllToggle}
      onCheckOneToggle={handleCheckOneToggle}
      onRowClick={(event, _, test) => (window.location.href = '')}
      overflowMenuColumnHeaderText="Actions"
      overflowMenuTitle="More row options"
      shouldRowClick={() => true}
    >
      <XUITableColumn
        head={<XUITableCell>Number</XUITableCell>}
        body={({ number }) => (
          <XUITableCell className="xui-text-emphasis">
            <a href="">{number}</a>
          </XUITableCell>
        )}
      />
      <XUITableColumn
        head={<XUITableCell>Ref</XUITableCell>}
        body={({ ref }) => <XUITableCell>{ref}</XUITableCell>}
      />
      <XUITableColumn
        head={<XUITableCell>To</XUITableCell>}
        body={({ to }) => <XUITableCell>{to}</XUITableCell>}
      />
      <XUITableColumn
        head={<XUITableCell>Amount due</XUITableCell>}
        body={({ due }) => <XUITableCell>{currencyFormatter.format(due)}</XUITableCell>}
        inlineAlignment="end"
      />
    </XUITable>
  );
};

<SingleDestinationExample />;
```

### Multiple destinations

Don’t assign an `onRowClick` prop to table rows with multiple link destinations, instead, just use anchor tags (`<a />`) directly in the cells.

```jsx harmony
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';
import { XUIPickitem } from '@xero/xui/react/picklist';
import { useState } from 'react';

const data = {
  1: {
    number: 'INV-001',
    ref: 'Monthly support',
    to: 'Apple',
    due: 550.0
  },
  2: {
    number: 'INV-002',
    ref: 'Software licenses',
    to: 'Microsoft',
    due: 365.0
  },
  3: {
    number: 'INV-003',
    ref: 'Cloud services',
    to: 'Amazon',
    due: 7890.5
  }
};

const MultipleDestinationExample = () => {
  const currencyFormatter = Intl.NumberFormat('en-NZ', { style: 'currency', currency: 'NZD' });

  return (
    <XUITable
      data={data}
      isResponsive
      hasPinnedLastColumn
      hasOverflowMenu
      createOverflowMenu={() => [
        <XUIPickitem key="0" id="0" onClick={() => {}}>
          Pay
        </XUIPickitem>
      ]}
      loaderAriaLabel="Loading more data"
      emptyMessage="No invoices found"
      overflowMenuColumnHeaderText="Actions"
      overflowMenuTitle="More row options"
      caption="List of invoices"
    >
      <XUITableColumn
        head={<XUITableCell>Number</XUITableCell>}
        body={({ number }) => (
          <XUITableCell>
            <a href="">{number}</a>
          </XUITableCell>
        )}
      />
      <XUITableColumn
        head={<XUITableCell>Ref</XUITableCell>}
        body={({ ref }) => (
          <XUITableCell>
            <a href="">{ref}</a>
          </XUITableCell>
        )}
      />
      <XUITableColumn
        head={<XUITableCell>To</XUITableCell>}
        body={({ to }) => <XUITableCell>{to}</XUITableCell>}
      />
      <XUITableColumn
        head={<XUITableCell>Amount due</XUITableCell>}
        body={({ due }) => <XUITableCell>{currencyFormatter.format(due)}</XUITableCell>}
        inlineAlignment="end"
      />
    </XUITable>
  );
};

<MultipleDestinationExample />;
```

## Empty State

If no data is supplied to `<XUITable />` then the _empty state_ component will be rendered instead. In that case, you must provide an `emptyMessage` or replace the entire empty state component by providing your own e.g. `<XUIEmptyState />`. Learn more about [empty states](#empty-state).

```jsx harmony
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';

const data = {};

<XUITable
  data={data}
  loaderAriaLabel="Loading more data"
  emptyMessage="No invoices found"
  checkOneRowAriaLabel="Select row"
  checkAllRowsAriaLabel="Select all rows"
  caption="List of invoices"
>
  <XUITableColumn
    head={<XUITableCell>Number</XUITableCell>}
    body={({ number }) => <XUITableCell>{number}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Ref</XUITableCell>}
    body={({ ref }) => <XUITableCell>{ref}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>To</XUITableCell>}
    body={({ to }) => <XUITableCell>{to}</XUITableCell>}
  />
</XUITable>;
```

```jsx harmony
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';
import XUIEmptyState from '@xero/xui/react/emptystate';

const data = {};
const emptyStateComponent = (
  <XUIEmptyState
    illustrationProps={{
      src: 'https://edge.xero.com/illustration/send-online-quotes-01/send-online-quotes-01.svg'
    }}
    heading="No invoices for this project"
    headingLevel={2}
    message={
      <p>
        Create an invoice from the <b>Invoice</b> button or assign a line item on an invoice
      </p>
    }
  />
);

<XUITable
  data={data}
  emptyStateComponent={emptyStateComponent}
  loaderAriaLabel="Loading more data"
  emptyMessage="No invoices found"
  checkOneRowAriaLabel="Select row"
  checkAllRowsAriaLabel="Select all rows"
  caption="List of invoices"
>
  <XUITableColumn
    head={<XUITableCell>Number</XUITableCell>}
    body={({ number }) => <XUITableCell>{number}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>Ref</XUITableCell>}
    body={({ ref }) => <XUITableCell>{ref}</XUITableCell>}
  />
  <XUITableColumn
    head={<XUITableCell>To</XUITableCell>}
    body={({ to }) => <XUITableCell>{to}</XUITableCell>}
  />
</XUITable>;
```

## Hiding and showing columns

There are two possible approaches for hiding and showing columns.

- Selectively exclude the `XUITableColumn` you wish to hide.
- Using the `XUITable` `hiddenColumns` API.

The `hiddenColumns` API is optimal for very large tables, in which re-rendering all the rows and cells is not desired, and the order of columns is not expected to change. For best performance in these cases, cells should be [memoized](https://reactjs.org/docs/react-api.html#reactmemo) to reduce unnecessary renders. For more details, check [XUI Performance tips](https://xui.xero.com/latest/section-getting-started-performance.html#getting-started-performance-3-1).

To use this feature, pass an array of column indexes that should be hidden (zero-based, inclusive of any controls, like checkboxes) to the `hiddenColumns` prop for `XUITable`

```jsx harmony
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';
import { XUIActions } from '@xero/xui/react/actions';
import { XUISelectBox, XUISelectBoxOption } from '@xero/xui/react/selectbox';
import { useState } from 'react';

const data = {
  1: {
    number: 'INV-0001',
    ref: 'Monthly support',
    to: 'Apple',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 550.0,
    status: 'Draft',
    sent: false
  },
  2: {
    number: 'INV-0002',
    ref: 'Software licenses',
    to: 'Microsoft',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 365.0,
    status: 'Awaiting payment',
    sent: false
  },
  3: {
    number: 'INV-0003',
    ref: 'Cloud services',
    to: 'Amazon',
    date: 1651579200000,
    dueDate: 1654257600000,
    paid: 0.0,
    due: 7890.5,
    status: 'Awaiting payment',
    sent: true
  }
};

const currencyFormatter = Intl.NumberFormat('en-NZ', { style: 'currency', currency: 'NZD' });

const HideShowExample = () => {
  const [hiddenColumns, setHiddenColumns] = useState([]);
  const columns = {
    number: 'Number',
    ref: 'Ref',
    to: 'To',
    date: 'Invoice date',
    dueDate: 'Due date',
    paid: 'Amount paid',
    due: 'Amount due',
    status: 'Status',
    sent: 'Sent'
  };
  const columnIndices = Object.keys(columns);
  const hiddenColumnIndices = hiddenColumns.map(column => columnIndices.indexOf(column));

  const onColumnSelect = value => {
    if (hiddenColumns.indexOf(value) > -1) {
      setHiddenColumns(hiddenColumns.filter(column => column !== value));
    } else {
      setHiddenColumns(prevState => [...prevState, value]);
    }
  };

  const getButtonText = (values, placeholder) => {
    const text = values
      .map(value => columns[value])
      .sort()
      .join(', ');
    return text || placeholder;
  };

  const columnSelectBox = (
    <XUISelectBox
      buttonContent={getButtonText(hiddenColumns, 'Hide columns')}
      closeAfterSelection={false}
      onSelect={onColumnSelect}
      matchTriggerWidth={false}
      label="Hidden columns"
    >
      {Object.keys(columns).map((column, index) => {
        return (
          <XUISelectBoxOption
            id={column}
            isSelected={hiddenColumns.indexOf(column) >= 0}
            key={index + column + 'userDefined Key'}
            showCheckboxes
            value={column}
          >
            {columns[column]}
          </XUISelectBoxOption>
        );
      })}
    </XUISelectBox>
  );

  return (
    <>
      <XUIActions className="xui-margin-bottom">{columnSelectBox}</XUIActions>
      <XUITable
        data={data}
        loaderAriaLabel="Loading more data"
        emptyMessage="No invoices found"
        checkOneRowAriaLabel="Select row"
        caption="List of invoices"
        hiddenColumns={hiddenColumnIndices}
      >
        <XUITableColumn
          head={<XUITableCell>{columns['number']}</XUITableCell>}
          body={({ number }) => <XUITableCell>{number}</XUITableCell>}
        />
        <XUITableColumn
          head={<XUITableCell>{columns['ref']}</XUITableCell>}
          body={({ ref }) => <XUITableCell>{ref}</XUITableCell>}
        />
        <XUITableColumn
          head={<XUITableCell>{columns['to']}</XUITableCell>}
          body={({ to }) => <XUITableCell>{to}</XUITableCell>}
        />
        <XUITableColumn
          head={<XUITableCell>{columns['date']}</XUITableCell>}
          body={({ date }) => (
            <XUITableCell>
              {new Date(date).toLocaleDateString('en-NZ', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
              })}
            </XUITableCell>
          )}
        />
        <XUITableColumn
          head={<XUITableCell>{columns['dueDate']}</XUITableCell>}
          body={({ dueDate }) => (
            <XUITableCell>
              {new Date(dueDate).toLocaleDateString('en-NZ', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
              })}
            </XUITableCell>
          )}
        />
        <XUITableColumn
          head={<XUITableCell>{columns['paid']}</XUITableCell>}
          body={({ paid }) => <XUITableCell>{currencyFormatter.format(paid)}</XUITableCell>}
          inlineAlignment="end"
        />
        <XUITableColumn
          head={<XUITableCell>{columns['due']}</XUITableCell>}
          body={({ due }) => <XUITableCell>{currencyFormatter.format(due)}</XUITableCell>}
          inlineAlignment="end"
        />
        <XUITableColumn
          head={<XUITableCell>{columns['status']}</XUITableCell>}
          body={({ status }) => <XUITableCell>{status}</XUITableCell>}
        />
        <XUITableColumn
          head={<XUITableCell>{columns['sent']}</XUITableCell>}
          body={({ sent }) => <XUITableCell>{sent ? 'Sent' : ''}</XUITableCell>}
        />
      </XUITable>
    </>
  );
};

<HideShowExample />;
```

## TypeScript

XUITable components take an optional generic type that represents the shape of an individual row's
data. The `ValueType` helper can be used to determine the type of your row data.

```tsx harmony static
import { XUITable, XUITableColumn, XUITableCell } from '@xero/xui/react/table';
import ValueType from '@xero/xui/react/helpers/ValueType';

const data = {
  1: { to: 'Apple' },
  2: { to: 'Microsoft' },
  3: { to: 'Amazon' }
};

<XUITable data={data}>
  <XUITableColumn<ValueType<typeof data>>
    body={({ to }) => <XUITableCell<ValueType<typeof data>>>{to}</XUITableCell>}
  />
</XUITable>;
```

The `customSort` prop will infer types where it can, but in some cases you'll need to specify the
type of your `customSort` function. The key to getting this type to work correctly is using a
generic to ensure the input and output data are the same shape.

```ts harmony static
import ValueType from '@xero/xui/react/helpers/ValueType';

const data = {
  1: { to: 'Apple' },
  2: { to: 'Microsoft' },
  3: { to: 'Amazon' }
};

function customSort<Items extends Array<ValueType<typeof data>>>(
  items: Items,
  isAscending?: boolean,
  activeSortKey?: string
): Items {
  return items;
}
```

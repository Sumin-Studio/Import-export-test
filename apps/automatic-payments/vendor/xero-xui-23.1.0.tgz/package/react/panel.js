"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIPanel", {
  enumerable: true,
  get: function () {
    return _XUIPanel.default;
  }
});
Object.defineProperty(exports, "XUIPanelFooter", {
  enumerable: true,
  get: function () {
    return _XUIPanelFooter.default;
  }
});
Object.defineProperty(exports, "XUIPanelHeader", {
  enumerable: true,
  get: function () {
    return _XUIPanelHeader.default;
  }
});
Object.defineProperty(exports, "XUIPanelHeading", {
  enumerable: true,
  get: function () {
    return _XUIPanelHeading.default;
  }
});
Object.defineProperty(exports, "XUIPanelSection", {
  enumerable: true,
  get: function () {
    return _XUIPanelSection.default;
  }
});
Object.defineProperty(exports, "XUIPanelSectionHeading", {
  enumerable: true,
  get: function () {
    return _XUIPanelSectionHeading.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIPanel.default;
  }
});
var _XUIPanel = _interopRequireDefault(require("./components/panel/XUIPanel"));
var _XUIPanelFooter = _interopRequireDefault(require("./components/panel/XUIPanelFooter"));
var _XUIPanelHeader = _interopRequireDefault(require("./components/panel/XUIPanelHeader"));
var _XUIPanelHeading = _interopRequireDefault(require("./components/panel/XUIPanelHeading"));
var _XUIPanelSection = _interopRequireDefault(require("./components/panel/XUIPanelSection"));
var _XUIPanelSectionHeading = _interopRequireDefault(require("./components/panel/XUIPanelSectionHeading"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=panel.js.map
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIModal", {
  enumerable: true,
  get: function () {
    return _XUIModal.default;
  }
});
Object.defineProperty(exports, "XUIModalBody", {
  enumerable: true,
  get: function () {
    return _XUIModalBody.default;
  }
});
Object.defineProperty(exports, "XUIModalFooter", {
  enumerable: true,
  get: function () {
    return _XUIModalFooter.default;
  }
});
Object.defineProperty(exports, "XUIModalHeader", {
  enumerable: true,
  get: function () {
    return _XUIModalHeader.default;
  }
});
Object.defineProperty(exports, "XUIModalHeading", {
  enumerable: true,
  get: function () {
    return _XUIModalHeading.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIModal.default;
  }
});
var _XUIModal = _interopRequireDefault(require("./components/modal/XUIModal"));
var _XUIModalBody = _interopRequireDefault(require("./components/modal/XUIModalBody"));
var _XUIModalFooter = _interopRequireDefault(require("./components/modal/XUIModalFooter"));
var _XUIModalHeader = _interopRequireDefault(require("./components/modal/XUIModalHeader"));
var _XUIModalHeading = _interopRequireDefault(require("./components/modal/XUIModalHeading"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=modal.js.map
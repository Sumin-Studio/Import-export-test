"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIBarChart", {
  enumerable: true,
  get: function () {
    return _XUIBarChart.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIBarChart.default;
  }
});
var _XUIBarChart = _interopRequireDefault(require("./components/chart/XUIBarChart"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=barchart.js.map
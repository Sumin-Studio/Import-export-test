import XUIFilePreview, { type XUIFilePreviewProps } from './components/filepreview/XUIFilePreview';
import XUIFilePreviewFooter, { type XUIFilePreviewFooterProps } from './components/filepreview/XUIFilePreviewFooter';
import XUIFilePreviewHeader, { type XUIFilePreviewHeaderProps } from './components/filepreview/XUIFilePreviewHeader';
export { XUIFilePreview as default, XUIFilePreview, XUIFilePreviewFooter, type XUIFilePreviewFooterProps, XUIFilePreviewHeader, type XUIFilePreviewHeaderProps, type XUIFilePreviewProps, };

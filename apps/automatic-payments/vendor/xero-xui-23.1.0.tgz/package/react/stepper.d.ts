import XUIStepper, { type XUIStepperProps } from './components/stepper/XUIStepper';
export { XUIStepper as default, XUIStepper, type XUIStepperProps };

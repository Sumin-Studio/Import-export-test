"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIDatePicker", {
  enumerable: true,
  get: function () {
    return _XUIDatePicker.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIDatePicker.default;
  }
});
var _XUIDatePicker = _interopRequireDefault(require("./components/datepicker/XUIDatePicker"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=datepicker.js.map
import XUIProgressCircular, { type XUIProgressCircularProps } from './components/progressindicator/XUIProgressCircular';
import XUIProgressLinear, { type XUIProgressLinearProps } from './components/progressindicator/XUIProgressLinear';
declare const progressTypes: {
    XUIProgressCircular: typeof XUIProgressCircular;
    XUIProgressLinear: typeof XUIProgressLinear;
};
export { progressTypes as default, progressTypes, XUIProgressCircular, type XUIProgressCircularProps, XUIProgressLinear, type XUIProgressLinearProps, };

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIControlGroup", {
  enumerable: true,
  get: function () {
    return _XUIControlGroup.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIControlGroup.default;
  }
});
var _XUIControlGroup = _interopRequireDefault(require("./components/controlgroup/XUIControlGroup"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=controlgroup.js.map
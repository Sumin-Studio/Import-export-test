import * as PropTypes from 'prop-types';
/**
 * Custom propType validator for checking if a prop is offered when the corresponding `basedProp` is `true`.
 *
 * @param {String} basedProp The name of the corresponding basedProp for checking.
 * @param {Function} propType The validator function for configuring type definitions. For example, PropTypes.string.
 * @param  {...any} parameters All parameters supplied by propTypes.
 */
declare const checkRequiredProps: (basedProp: string, propType: PropTypes.Validator<unknown>, ...parameters: [Record<string, unknown>, string, string, string, string]) => Error | null;
export default checkRequiredProps;

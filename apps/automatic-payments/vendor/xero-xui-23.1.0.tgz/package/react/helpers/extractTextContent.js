"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/es.promise.js");
var React = _interopRequireWildcard(require("react"));
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
const isReactPortal = node => !!node && typeof node === 'object' && 'children' in node;
const isReactElement = node => !!node && typeof node === 'object' && 'props' in node && 'children' in node.props;
const extractTextContent = node => {
  if (!node) return '';
  let children;
  switch (typeof node) {
    case 'string':
    case 'number':
      return `${node}`;
    case 'object':
      if (isReactPortal(node)) ({
        children
      } = node);else if (isReactElement(node)) {
        ({
          children
        } = node.props);
      } else if (Array.isArray(node)) {
        node.forEach(item => extractTextContent(item));
      } else {
        return '';
      }
      break;
    default:
      return '';
  }
  let textContent = '';
  React.Children.map(React.Children.toArray(children), child => {
    textContent += `${textContent.length > 0 ? ' ' : ''}${extractTextContent(child)}`;
    return textContent;
  });
  return textContent;
};
var _default = exports.default = extractTextContent;
//# sourceMappingURL=extractTextContent.js.map
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "observe", {
  enumerable: true,
  get: function () {
    return _resizeObserver.observe;
  }
});
Object.defineProperty(exports, "unobserve", {
  enumerable: true,
  get: function () {
    return _resizeObserver.unobserve;
  }
});
var _resizeObserver = require("../components/helpers/resizeObserver");
//# sourceMappingURL=resizeObserver.js.map
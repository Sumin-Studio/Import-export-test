"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _reactKeyHandler = require("../components/helpers/reactKeyHandler");
function queryIsValidInteraction(event) {
  return event.type === 'click' || (0, _reactKeyHandler.isKeyClick)(event);
}
var _default = exports.default = queryIsValidInteraction;
//# sourceMappingURL=isQueryValidInteraction.js.map
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var PropTypes = _interopRequireWildcard(require("prop-types"));
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
/**
 * Custom propType validator for checking if a prop is offered when the corresponding `basedProp` is `true`.
 *
 * @param {String} basedProp The name of the corresponding basedProp for checking.
 * @param {Function} propType The validator function for configuring type definitions. For example, PropTypes.string.
 * @param  {...any} parameters All parameters supplied by propTypes.
 */
const checkRequiredProps = (basedProp, propType, ...parameters) => {
  const [props, propName, location, componentName] = parameters;
  if (props[basedProp]) {
    if (props[propName]) {
      PropTypes.checkPropTypes(propType, props[propName], location, componentName);
    } else {
      return new Error(`${propName} is required when ${basedProp} is true.`);
    }
  }
  return null;
};
var _default = exports.default = checkRequiredProps;
//# sourceMappingURL=checkRequiredProps.js.map
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _useContainerQuery = _interopRequireDefault(require("../components/helpers/useContainerQuery"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
var _default = exports.default = _useContainerQuery.default;
//# sourceMappingURL=useContainerQuery.js.map
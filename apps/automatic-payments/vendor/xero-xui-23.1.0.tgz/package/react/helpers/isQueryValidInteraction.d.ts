declare function queryIsValidInteraction(event: React.MouseEvent | React.KeyboardEvent): boolean;
export default queryIsValidInteraction;

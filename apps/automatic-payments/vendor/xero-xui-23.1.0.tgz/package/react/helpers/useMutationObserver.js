"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _useMutationObserver.default;
  }
});
var _useMutationObserver = _interopRequireDefault(require("../components/helpers/useMutationObserver"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=useMutationObserver.js.map
import React from 'react';

import XUIButton from '../../components/button/XUIButton';
import XUIPanel from '../../components/panel/XUIPanel';
import extractTextContent from '../extractTextContent';

describe('extractTextContent', () => {
  it('returns an empty string if given an undefined value for node', () => {
    // Arrange
    const node = undefined;

    // Act
    const textContent = extractTextContent(node);

    // Assert
    expect(textContent).toBe('');
  });

  it('returns an empty string if given a null value for node', () => {
    // Arrange
    const node = null;

    // Act
    const textContent = extractTextContent(node);

    // Assert
    expect(textContent).toBe('');
  });

  it('returns the string value of a node passed in that is of type string', () => {
    // Arrange
    const node = 'test';

    // Act
    const textContent = extractTextContent(node);

    // Assert
    expect(textContent).toBe('test');
  });
  it('returns the string child of a React element passed in', () => {
    // Arrange
    const node = <XUIButton>test</XUIButton>;

    // Act
    const textContent = extractTextContent(node);

    // Assert
    expect(textContent).toBe('test');
  });
  it('returns the string child of an HTML element passed in', () => {
    // Arrange
    const node = <span>test</span>;

    // Act
    const textContent = extractTextContent(node);

    // Assert
    expect(textContent).toBe('test');
  });
  it('returns the string children from multiple layers of depth seperated by a space', () => {
    // Arrange
    const node = (
      <XUIPanel>
        layer1
        <div>
          layer2
          <XUIButton>
            layer3<span>layer4</span>
          </XUIButton>
        </div>
        layer1AfterDiv
      </XUIPanel>
    );
    // Act
    const textContent = extractTextContent(node);

    // Assert
    expect(textContent).toBe('layer1 layer2 layer3 layer4 layer1AfterDiv');
  });

  it('returns the string children from a node containing a fragment and a true boolean', () => {
    // Arrange
    const node = (
      <>
        layer1
        <XUIButton>
          layer2
          {true && <span>layer3</span>}
        </XUIButton>
      </>
    );
    // Act
    const textContent = extractTextContent(node);

    // Assert
    expect(textContent).toBe('layer1 layer2 layer3');
  });

  it('returns the string children from a node containing a fragment and a false boolean', () => {
    // Arrange
    const node = (
      <>
        layer1
        <XUIButton>
          layer2
          {false && <span>layer3</span>}
        </XUIButton>
      </>
    );
    // Act
    const textContent = extractTextContent(node);

    // Assert
    expect(textContent).toBe('layer1 layer2');
  });
});

## Prettify | 21.1.0

This generic type is used to 'Prettify' intersection types, ensuring that the IDE displays the types from _within_ the intersection types themselves, rather than just showing the names of the types the intersection is created from.

It can be used like so:

```ts static
import { Prettify } from '@xero/xui/react/helpers/helperTypes';

type MyIntersectionType = SomeOtherType & {
  anotherProp: string;
};

type MyType = Prettify<MyIntersectionType>;

// Alternatively, you can wrap the intersection directly to avoid needing an additional type declaration
type MyOtherType = Prettify<
  SomeOtherType & {
    anotherProp: string;
  }
>;
```

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.asyncAccessibilityTest = asyncAccessibilityTest;
require("core-js/modules/es.promise.js");
var _jestAxe = require("jest-axe");
var _testUtils = require("react-dom/test-utils");
/* eslint-disable import/no-extraneous-dependencies */

async function asyncAccessibilityTest(container) {
  return (0, _testUtils.act)(async () => {
    const results = await (0, _jestAxe.axe)(container);
    expect(results).toHaveNoViolations();
  });
}
//# sourceMappingURL=testHelpers.js.map
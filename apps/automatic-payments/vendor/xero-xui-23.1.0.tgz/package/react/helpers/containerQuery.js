"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "getWidthClasses", {
  enumerable: true,
  get: function () {
    return _containerQuery.getWidthClassesFromState;
  }
});
Object.defineProperty(exports, "observe", {
  enumerable: true,
  get: function () {
    return _containerQuery.observe;
  }
});
Object.defineProperty(exports, "unobserve", {
  enumerable: true,
  get: function () {
    return _containerQuery.unobserve;
  }
});
var _containerQuery = require("../components/helpers/containerQuery");
//# sourceMappingURL=containerQuery.js.map
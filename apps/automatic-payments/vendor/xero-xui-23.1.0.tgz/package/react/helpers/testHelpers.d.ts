export declare function asyncAccessibilityTest(container: string | Element): Promise<void>;

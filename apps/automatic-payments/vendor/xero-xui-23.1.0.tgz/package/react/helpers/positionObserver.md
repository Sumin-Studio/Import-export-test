XUI provides a position observer for monitoring and taking action depending on if the position of an element has changed in the DOM.

XUI offers two versions of a position observer: one built for function components (using React Hooks), and one built for class components. Steps to implement each are detailed below.

### Function components (React Hooks)

1. Import `usePositionObserver` from `usePositionObserver.ts` in XUI.
2. Inside the component, attach a ref to the `HTMLElement` you wish to observe.
3. Pass the ref as an argument to `usePositionObserver()`. This hook returns the current `clientRect` of the observed node.
4. `usePositionObserver()` optionally accepts a callback function that is passed the current `clientRect` as an argument. This function will be called each time the observed element's position changes and can be used to re-render your component. Alternatively, you may implement this logic yourself by using the properties of the returned `clientRect` as the dependencies of React's `useLayoutEffect` hook within your component. This callback function should be memoised with `useCallback` to avoid unnecessary rerenders.

#### Dynamically update absolute positioning with a position observer

```jsx harmony
import { useState, useCallback, useRef } from 'react';
import info from '@xero/xui-icon/icons/info';
import { XUIIconButton } from '@xero/xui/react/button';
import usePositionObserver from '@xero/xui/react/components/helpers/UsePositionObserver/usePositionObserver';

const wrapperStyles = {
  position: 'absolute'
};

const PositionObserverExample = () => {
  const observedElementRef = useRef(null);

  const [position, setPosition] = useState({ top: 0, left: 0 });

  const callback = useCallback(
    updatedRect => {
      setPosition({
        top: updatedRect.top + window.scrollY,
        left: updatedRect.left + updatedRect.width
      });
    },
    [window]
  );

  usePositionObserver(observedElementRef, callback);

  return (
    <>
      <XUIIconButton ariaLabel="More options" icon={info} ref={observedElementRef} />
      <div className="xui-panel xui-padding-xsmall" style={{ position: 'absolute', ...position }}>
        I'm positioned in response to the trigger
      </div>
    </>
  );
};
<PositionObserverExample />;
```

### Class components

1. Import or require `observe` and `unobserve` from `positionObserver.ts` in XUI.
2. Create a `ref` to the `DOM node` you wish to observe, using React's `createRef` method.
3. In `componentDidMount`, `observe` the component, after ensuring the node ref is present. If the node ref is not present at mount, you can also begin observing in `componentDidUpdate` -- just remember to only fire this once during the component lifecycle. Pass in the ref and the callback function to be executed when position changes. This callback receives the `clientRect` of the element.
4. Likewise, in `componentWillUnmount`, `unobserve` the component.

#### Dynamically update absolute positioning with a position observer

```jsx harmony
import { Component } from 'react';
import info from '@xero/xui-icon/icons/info';
import XUIIcon from '@xero/xui/react/icon';
import { XUIIconButton } from '@xero/xui/react/button';
import {
  observe,
  unobserve
} from '@xero/xui/react/components/helpers/UsePositionObserver/positionObserver';

const iconWrapperStyles = {
  height: '40px',
  width: '40px',
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center'
};

class PositionObserverExample extends Component {
  constructor(props) {
    super(props);
    this._target = React.createRef();
    this.state = { top: 0, left: 0 };
  }

  componentDidMount() {
    if (this._target.current) {
      observe(this._target, updatedRect => {
        this.setState({
          top: updatedRect.top + window.scrollY,
          left: updatedRect.left + updatedRect.width
        });
      });
    }
  }

  componentWillUnmount() {
    this._target.current && unobserve(this);
  }

  _onPositionChange(updatedRect) {
    this.setState({
      top: updatedRect.top + window.scrollY,
      left: updatedRect.left + updatedRect.width
    });
  }

  render() {
    return (
      <>
        <div style={iconWrapperStyles} ref={this._target}>
          <XUIIcon ariaLabel="More options" icon={info} />
        </div>
        <div
          className="xui-panel xui-padding-xsmall"
          style={{ position: 'absolute', ...this.state }}
        >
          I'm positioned in response to the trigger
        </div>
      </>
    );
  }
}
<PositionObserverExample />;
```

/**
 * Prettifies a given intersection type to ensure it appears as its resolved types, instead of the intersections.
 */
type Prettify<T> = {
    [K in keyof T]: T[K];
} & {};
export type { Prettify };

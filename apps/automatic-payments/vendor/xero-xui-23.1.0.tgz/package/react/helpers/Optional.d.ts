/**
 * From T, make a selection of properties whose keys are in the union K optional
 *
 * @example
 * Optional<{ a: string, b: number}, 'a'> // { a?: string, b: number }
 */
type Optional<T, K extends keyof T> = Pick<Partial<T>, K> & Omit<T, K>;
export default Optional;

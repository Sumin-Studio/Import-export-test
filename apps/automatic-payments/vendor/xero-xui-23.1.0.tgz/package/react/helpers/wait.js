"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = wait;
require("core-js/modules/es.promise.js");
async function wait(ms) {
  // eslint-disable-next-line no-promise-executor-return
  await new Promise(resolve => setTimeout(resolve, ms));
}
//# sourceMappingURL=wait.js.map
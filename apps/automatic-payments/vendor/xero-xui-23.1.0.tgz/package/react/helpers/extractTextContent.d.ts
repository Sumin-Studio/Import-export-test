import * as React from 'react';
declare const extractTextContent: (node: React.ReactNode) => string;
export default extractTextContent;

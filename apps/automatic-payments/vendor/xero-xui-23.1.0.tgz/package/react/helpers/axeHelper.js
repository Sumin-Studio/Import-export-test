"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _jestAxe = require("jest-axe");
// eslint-disable-next-line import/no-extraneous-dependencies

const axe = (0, _jestAxe.configureAxe)({
  globalOptions: {
    // Turns off the ding for not containing our components
    // in a landmark region – not necessary in unit tests
    // https://dequeuniversity.com/rules/axe/4.1/region
    checks: [{
      id: 'region',
      evaluate: 'region-evaluate',
      enabled: false
    }]
  }
});
var _default = exports.default = axe;
//# sourceMappingURL=axeHelper.js.map
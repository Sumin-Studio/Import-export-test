"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIIllustration", {
  enumerable: true,
  get: function () {
    return _XUIIllustration.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIIllustration.default;
  }
});
var _XUIIllustration = _interopRequireDefault(require("./components/illustration/XUIIllustration"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=illustration.js.map
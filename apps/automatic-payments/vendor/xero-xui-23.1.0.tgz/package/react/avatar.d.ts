import XUIAvatar, { type XUIAvatarProps } from './components/avatar/XUIAvatar';
import XUIAvatarGroup, { type XUIAvatarGroupProps } from './components/avatar/XUIAvatarGroup';
export { XUIAvatar as default, XUIAvatar, XUIAvatarGroup, type XUIAvatarGroupProps, type XUIAvatarProps, };

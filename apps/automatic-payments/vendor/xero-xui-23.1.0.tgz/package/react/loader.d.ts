import XUILoader, { type XUILoaderProps } from './components/loader/XUILoader';
export { XUILoader as default, XUILoader, type XUILoaderProps };

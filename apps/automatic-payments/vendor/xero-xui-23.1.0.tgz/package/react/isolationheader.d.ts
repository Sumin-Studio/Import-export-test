import XUIIsolationHeader, { type XUIIsolationHeaderProps } from './components/isolationheader/XUIIsolationHeader';
export { XUIIsolationHeader as default, XUIIsolationHeader, type XUIIsolationHeaderProps };

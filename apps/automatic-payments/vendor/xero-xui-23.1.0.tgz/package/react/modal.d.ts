import XUIModal, { XUIModalProps } from './components/modal/XUIModal';
import XUIModalBody, { XUIModalBodyProps } from './components/modal/XUIModalBody';
import XUIModalFooter, { XUIModalFooterProps } from './components/modal/XUIModalFooter';
import XUIModalHeader, { XUIModalHeaderProps } from './components/modal/XUIModalHeader';
import XUIModalHeading from './components/modal/XUIModalHeading';
export { XUIModal as default, XUIModal, XUIModalBody, type XUIModalBodyProps, XUIModalFooter, type XUIModalFooterProps, XUIModalHeader, type XUIModalHeaderProps, XUIModalHeading, type XUIModalProps, };

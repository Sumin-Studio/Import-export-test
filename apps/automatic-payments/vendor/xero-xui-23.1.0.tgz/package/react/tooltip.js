"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUITooltip", {
  enumerable: true,
  get: function () {
    return _XUITooltip.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUITooltip.default;
  }
});
var _XUITooltip = _interopRequireDefault(require("./components/tooltip/XUITooltip"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=tooltip.js.map
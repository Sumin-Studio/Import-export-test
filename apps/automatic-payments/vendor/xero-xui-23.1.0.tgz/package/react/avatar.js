"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIAvatar", {
  enumerable: true,
  get: function () {
    return _XUIAvatar.default;
  }
});
Object.defineProperty(exports, "XUIAvatarGroup", {
  enumerable: true,
  get: function () {
    return _XUIAvatarGroup.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIAvatar.default;
  }
});
var _XUIAvatar = _interopRequireDefault(require("./components/avatar/XUIAvatar"));
var _XUIAvatarGroup = _interopRequireDefault(require("./components/avatar/XUIAvatarGroup"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=avatar.js.map
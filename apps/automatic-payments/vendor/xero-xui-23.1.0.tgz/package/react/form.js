"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIForm", {
  enumerable: true,
  get: function () {
    return _XUIForm.default;
  }
});
Object.defineProperty(exports, "XUILabelIndicator", {
  enumerable: true,
  get: function () {
    return _XUILabelIndicator.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIForm.default;
  }
});
Object.defineProperty(exports, "useXUIForm", {
  enumerable: true,
  get: function () {
    return _useXUIForm.useXUIForm;
  }
});
var _useXUIForm = require("./components/form/useXUIForm");
var _XUIForm = _interopRequireDefault(require("./components/form/XUIForm"));
var _XUILabelIndicator = _interopRequireDefault(require("./components/form/XUILabelIndicator"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=form.js.map
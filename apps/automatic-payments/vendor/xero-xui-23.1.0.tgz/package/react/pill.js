"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIPill", {
  enumerable: true,
  get: function () {
    return _XUIPill.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIPill.default;
  }
});
var _XUIPill = _interopRequireDefault(require("./components/pill/XUIPill"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=pill.js.map
import XUIPagination, { type XUIPaginationProps } from './components/pagination/XUIPagination';
export { XUIPagination as default, XUIPagination, type XUIPaginationProps };

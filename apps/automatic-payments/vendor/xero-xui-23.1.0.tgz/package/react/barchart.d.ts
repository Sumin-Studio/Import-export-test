import XUIBarChart, { type XUIBarChartProps } from './components/chart/XUIBarChart';
export { XUIBarChart as default, XUIBarChart, type XUIBarChartProps };

import XUIEmptyState from './components/emptystate/XUIEmptyState';
export { XUIEmptyState as default };

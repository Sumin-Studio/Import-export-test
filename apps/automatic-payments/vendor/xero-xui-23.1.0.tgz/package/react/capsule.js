"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUICapsule", {
  enumerable: true,
  get: function () {
    return _XUICapsule.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUICapsule.default;
  }
});
var _XUICapsule = _interopRequireDefault(require("./components/capsule/XUICapsule"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=capsule.js.map
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIBreadcrumbTrail", {
  enumerable: true,
  get: function () {
    return _XUIBreadcrumbTrail.default;
  }
});
Object.defineProperty(exports, "XUIPageHeader", {
  enumerable: true,
  get: function () {
    return _XUIPageHeader.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIPageHeader.default;
  }
});
var _XUIBreadcrumbTrail = _interopRequireDefault(require("./components/pageheader/XUIBreadcrumbTrail"));
var _XUIPageHeader = _interopRequireDefault(require("./components/pageheader/XUIPageHeader"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=pageheader.js.map
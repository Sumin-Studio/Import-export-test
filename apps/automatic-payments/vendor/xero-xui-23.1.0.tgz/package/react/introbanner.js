"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIIntroBanner", {
  enumerable: true,
  get: function () {
    return _XUIIntroBanner.default;
  }
});
Object.defineProperty(exports, "XUIIntroBannerBody", {
  enumerable: true,
  get: function () {
    return _XUIIntroBannerBody.default;
  }
});
Object.defineProperty(exports, "XUIIntroBannerFooter", {
  enumerable: true,
  get: function () {
    return _XUIIntroBannerFooter.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIIntroBanner.default;
  }
});
var _XUIIntroBanner = _interopRequireDefault(require("./components/introbanner/XUIIntroBanner"));
var _XUIIntroBannerBody = _interopRequireDefault(require("./components/introbanner/XUIIntroBannerBody"));
var _XUIIntroBannerFooter = _interopRequireDefault(require("./components/introbanner/XUIIntroBannerFooter"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=introbanner.js.map
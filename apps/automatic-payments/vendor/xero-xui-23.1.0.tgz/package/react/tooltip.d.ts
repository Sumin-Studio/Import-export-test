import XUITooltip, { type XUITooltipProps } from './components/tooltip/XUITooltip';
export { XUITooltip as default, XUITooltip, type XUITooltipProps };

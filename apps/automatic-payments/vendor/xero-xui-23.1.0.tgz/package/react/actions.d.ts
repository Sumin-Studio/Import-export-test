import XUIActions, { type XUIActionsProps } from './components/actions/XUIActions';
export { XUIActions as default, XUIActions, type XUIActionsProps };

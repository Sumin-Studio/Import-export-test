import XUICapsule, { type XUICapsuleProps } from './components/capsule/XUICapsule';
export { XUICapsule as default, XUICapsule, type XUICapsuleProps };

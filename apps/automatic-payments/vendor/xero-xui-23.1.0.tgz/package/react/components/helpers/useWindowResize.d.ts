export interface Size {
    height: number | undefined;
    width: number | undefined;
}
declare const getHeight: () => number | undefined;
declare const getWidth: () => number | undefined;
declare function useWindowResize(debounceTimeout?: number): Size;
export { useWindowResize as default, getHeight, getWidth, useWindowResize };

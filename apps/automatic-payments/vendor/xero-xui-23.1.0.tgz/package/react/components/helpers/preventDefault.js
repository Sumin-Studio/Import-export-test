"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = preventDefault;
function preventDefault(event) {
  event.preventDefault();
}
//# sourceMappingURL=preventDefault.js.map
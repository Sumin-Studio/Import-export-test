"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = usePrevious;
var _react = require("react");
function usePrevious(value) {
  const ref = (0, _react.useRef)();

  // Store current value in ref
  (0, _react.useEffect)(() => {
    ref.current = value;
  }, [value]); // Only re-run if value changes

  // Return previous value (happens before update in useEffect above)
  return ref.current;
}
//# sourceMappingURL=usePrevious.js.map
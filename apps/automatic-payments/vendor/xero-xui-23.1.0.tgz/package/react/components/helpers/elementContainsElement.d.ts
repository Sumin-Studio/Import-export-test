/**
 * `elementContainsElement` extends [`node.contains`](https://developer.mozilla.org/en-US/docs/Web/API/Node/contains)
 * with support for portalled elements.
 *
 * This function relies on the correct implementation of the
 * [`aria-owns`](https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Attributes/aria-owns)
 * attribute.
 *
 * @param containerElement The element to search within
 * @param elementToFind The element expected to be found within `containerElement`
 * @returns `true` if `containerElement` contains `elementToFind`, otherwise returns `false`
 */
declare function elementContainsElement(containerElement: HTMLElement, elementToFind: HTMLElement): boolean;
export default elementContainsElement;

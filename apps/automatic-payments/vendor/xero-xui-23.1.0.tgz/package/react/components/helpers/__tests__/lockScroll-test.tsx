import { render } from '@testing-library/react';
import React from 'react';

import { isScrollLocked, lockScroll, unlockScroll } from '../lockScroll';

describe('lock scroll', () => {
  test('should start unlocked', () => {
    render(<div>Hello</div>);
    expect(isScrollLocked()).toBe(false);
  });

  test('should unlock scrolling after locking it', () => {
    render(<div>Hello</div>);

    lockScroll();
    expect(isScrollLocked()).toBe(true);

    unlockScroll();
    expect(isScrollLocked()).toBe(false);
  });

  test('should follow unlocking rules based on lock depth', () => {
    render(<div>Hello</div>);

    lockScroll();
    expect(isScrollLocked()).toBe(true);

    lockScroll();
    expect(isScrollLocked()).toBe(true);

    // Locked twice, single unlock should still be locked
    unlockScroll();
    expect(isScrollLocked()).toBe(true);

    // Final unlock, should unlock the view
    unlockScroll();
    expect(isScrollLocked()).toBe(false);
  });
});

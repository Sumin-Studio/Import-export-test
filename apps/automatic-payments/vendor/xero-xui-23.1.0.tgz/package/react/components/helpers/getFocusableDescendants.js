"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = getFocusableDescendants;
exports.focusableElements = exports.focusableDescendantsSelector = void 0;
const focusableElements = exports.focusableElements = ['[contentEditable]', '[tabindex]', 'a[href]', 'area[href]', 'button', 'details', 'iframe', 'input', 'select', 'textarea'];
const unfocusableStates = [':not([contentEditable="false"])', ':not([disabled])', ':not([tabindex="-1"])'];
const focusableDescendantsSelector = exports.focusableDescendantsSelector = focusableElements.map(focusableElement => [focusableElement, ...unfocusableStates].join('')).join(', ');
function getFocusableDescendants(element) {
  return element.querySelectorAll(focusableDescendantsSelector);
}
//# sourceMappingURL=getFocusableDescendants.js.map
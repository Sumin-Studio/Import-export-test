"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useWindowResize = exports.default = useWindowResize;
exports.getWidth = exports.getHeight = void 0;
var React = _interopRequireWildcard(require("react"));
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
const getHeight = () => {
  var _window, _document, _document2;
  return ((_window = window) === null || _window === void 0 ? void 0 : _window.innerHeight) || ((_document = document) === null || _document === void 0 || (_document = _document.documentElement) === null || _document === void 0 ? void 0 : _document.clientHeight) || ((_document2 = document) === null || _document2 === void 0 || (_document2 = _document2.body) === null || _document2 === void 0 ? void 0 : _document2.clientHeight) || undefined;
};
exports.getHeight = getHeight;
const getWidth = () => {
  var _window2, _document3, _document4;
  return ((_window2 = window) === null || _window2 === void 0 ? void 0 : _window2.innerWidth) || ((_document3 = document) === null || _document3 === void 0 || (_document3 = _document3.documentElement) === null || _document3 === void 0 ? void 0 : _document3.clientWidth) || ((_document4 = document) === null || _document4 === void 0 || (_document4 = _document4.body) === null || _document4 === void 0 ? void 0 : _document4.clientWidth) || undefined;
};
exports.getWidth = getWidth;
function useWindowResize(debounceTimeout = 150) {
  const [dimensions, setDimensions] = React.useState({
    height: getHeight(),
    width: getWidth()
  });
  React.useEffect(() => {
    let timeout;
    function handleResize() {
      if (timeout) {
        clearTimeout(timeout);
      } else {
        // first call to handleResize should set dimensions, following are debounced
        setDimensions({
          height: getHeight(),
          width: getWidth()
        });
      }
      timeout = setTimeout(() => setDimensions({
        height: getHeight(),
        width: getWidth()
      }), debounceTimeout);
    }
    window.addEventListener('resize', handleResize);
    return function unmountWindowResize() {
      setDimensions({
        height: undefined,
        width: undefined
      });
      window.removeEventListener('resize', handleResize);
    };
  }, [debounceTimeout]);
  return dimensions;
}
//# sourceMappingURL=useWindowResize.js.map
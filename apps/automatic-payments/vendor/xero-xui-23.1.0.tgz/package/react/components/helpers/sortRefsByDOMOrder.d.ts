export default function sortRefsByDOMOrder<T extends HTMLElement>(refs: Array<React.RefObject<T>>): import("react").RefObject<T>[];

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.unobserve = exports.observe = void 0;
var _positionObserverHelpers = require("./helpers/positionObserver-helpers");
var _getTriggerElementRef = _interopRequireDefault(require("../getTriggerElementRef"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
/* eslint-disable */

//@ts-ignore

// Create a single PositionObserver instance to handle all
// target elements. The instance is created with a callback,
// which is invoked as soon as an element is observed as well
// as any time that element's position changes.
const po = new _positionObserverHelpers.PositionObserver();
const observe = (elementRef, callback) => {
  const element = (0, _getTriggerElementRef.default)(elementRef).current;
  if (!element) {
    return;
  }
  po === null || po === void 0 || po.observeElement(element, callback);
};
exports.observe = observe;
const unobserve = elementRef => {
  const element = (0, _getTriggerElementRef.default)(elementRef).current;
  if (!element) {
    return;
  }
  po === null || po === void 0 || po.unobserveElement(element);
};
exports.unobserve = unobserve;
//# sourceMappingURL=positionObserver.js.map
import { render, screen } from '@testing-library/react';
import React from 'react';

import { XUIBannerAction } from '../../../banner';
import { setXUIClassNamespace } from '../xuiClassNamespace';

describe('setXUIClassNamespace', () => {
  test('should render elements with differently-prefixed class names after calling setXUIClassNamespace', () => {
    setXUIClassNamespace('zooey');

    // Note the elements we test here should have ns referenced in render, rather
    // than in a constants file
    render(<XUIBannerAction qaHook="testHook">Hai</XUIBannerAction>);
    expect(screen.getByTestId('testHook')).toHaveClass('zooey-banner--action');

    // Restore class namespace
    setXUIClassNamespace('xui');
  });
});

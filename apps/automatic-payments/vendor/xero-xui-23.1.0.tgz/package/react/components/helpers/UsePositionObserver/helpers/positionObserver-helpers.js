"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PositionObserver = void 0;
var _helpers = require("./helpers");
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
class PositionObserver {
  constructor() {
    _defineProperty(this, "listenersAttached", false);
    _defineProperty(this, "observerAttached", false);
    _defineProperty(this, "targetElements", []);
    _defineProperty(this, "listenerCallback", () => {
      this.targetElements = (0, _helpers.updateTargetPositions)(this.targetElements);
    });
    _defineProperty(this, "resizeListenerCallback", () => {
      this.targetElements = (0, _helpers.updateTargetPositions)(this.targetElements, true);
    });
    _defineProperty(this, "mutationCallback", () => {
      (0, _helpers.updateTargetPositions)(this.targetElements);
    });
    if (typeof window !== 'object') {
      return;
    }
    if (!this.listenersAttached && (0, _helpers.addListeners)(this.listenerCallback, this.resizeListenerCallback)) {
      this.listenersAttached = true;
    }
    const {
      observe
    } = (0, _helpers.observeDocumentForMutations)(this.mutationCallback);
    if (!this.observerAttached && observe()) {
      this.observerAttached = true;
    }
  }
  observeElement(element, callback) {
    if (!element) {
      return;
    }
    if (!this.listenersAttached && (0, _helpers.addListeners)(this.listenerCallback, this.resizeListenerCallback)) {
      this.listenersAttached = true;
    }
    const {
      observe
    } = (0, _helpers.observeDocumentForMutations)(this.mutationCallback);
    if (!this.observerAttached && observe()) {
      this.observerAttached = true;
    }
    const currentClientRect = element.getBoundingClientRect();
    this.targetElements.push({
      element,
      previousClientRect: currentClientRect,
      callback
    });
    callback(currentClientRect);
  }
  unobserveElement(element) {
    if (!element) {
      return;
    }
    this.targetElements = this.targetElements.filter(observedElement => observedElement.element !== element);
    if (!this.targetElements.length) {
      (0, _helpers.removeListeners)(this.listenerCallback, this.resizeListenerCallback);
      this.listenersAttached = false;
      const {
        unobserve
      } = (0, _helpers.observeDocumentForMutations)(this.mutationCallback);
      unobserve();
      this.observerAttached = false;
    }
  }
}
exports.PositionObserver = PositionObserver;
//# sourceMappingURL=positionObserver-helpers.js.map
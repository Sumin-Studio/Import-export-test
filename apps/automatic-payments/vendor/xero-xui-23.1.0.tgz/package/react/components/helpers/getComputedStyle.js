"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
const getComputedStyle = (element, prop) => {
  if (window.getComputedStyle && window.getComputedStyle(element, null)) {
    return window.getComputedStyle(element, null).getPropertyValue(prop);
  }
  return element.style[prop];
};
var _default = exports.default = getComputedStyle;
//# sourceMappingURL=getComputedStyle.js.map
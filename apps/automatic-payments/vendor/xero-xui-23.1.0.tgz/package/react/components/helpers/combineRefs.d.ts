declare const combineRefs: <T extends HTMLElement = HTMLElement>(...refs: Array<React.Ref<T>>) => (element: T | null) => void;
export default combineRefs;

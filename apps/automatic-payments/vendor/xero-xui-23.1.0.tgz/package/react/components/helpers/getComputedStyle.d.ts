declare const getComputedStyle: (element: HTMLElement, prop: string) => string;
export default getComputedStyle;

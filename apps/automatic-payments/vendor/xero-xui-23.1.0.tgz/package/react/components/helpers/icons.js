"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.flattenedIconMap = exports.flattenedIconList = void 0;
var _iconData = _interopRequireDefault(require("@xero/xui-icon/lib/private/iconData"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const flattenedIconMap = exports.flattenedIconMap = {};
const flattenedIconList = exports.flattenedIconList = [];
Object.keys(_iconData.default).forEach(groupKey => {
  Object.keys(_iconData.default[groupKey]).forEach(iconKey => {
    flattenedIconMap[iconKey] = _iconData.default[groupKey][iconKey];
    flattenedIconList.push(iconKey);
  });
});
//# sourceMappingURL=icons.js.map
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = useResizeObserver;
var React = _interopRequireWildcard(require("react"));
var _resizeObserverPolyfill = _interopRequireDefault(require("resize-observer-polyfill"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
/**
 * `useResizeObserver` will observe an `HTMLElement` with a `ResizeObserver` and provide a
 * `contentRect` detailing the size of the element.
 *
 * Start by attaching the provided `observedElementRef` to an `HTMLElement`.
 *
 * To re-render a component on resize you can use the properties of the provided `contentRect` as
 * the dependencies of a `React.useLayoutEffect`.
 */
function useResizeObserver() {
  const observedElementRef = React.useRef(null);
  const [resizeObserverEntry, setResizeObserverEntry] = React.useState();
  const [resizeObserver] = React.useState(new _resizeObserverPolyfill.default(entries => {
    const currentEntry = entries.find(entry => entry.target === observedElementRef.current);
    setResizeObserverEntry(currentEntry);
  }));
  const observe = React.useCallback(() => {
    if (observedElementRef.current) {
      resizeObserver.observe(observedElementRef.current);
    }
  }, [resizeObserver]);
  const unobserve = React.useCallback(() => {
    if (observedElementRef.current) {
      resizeObserver.unobserve(observedElementRef.current);
    }
  }, [resizeObserver]);
  React.useLayoutEffect(() => {
    observe();
    return () => unobserve();
  }, [observedElementRef, observe, unobserve]);
  const contentRect = (resizeObserverEntry === null || resizeObserverEntry === void 0 ? void 0 : resizeObserverEntry.contentRect) || {};
  return {
    observedElementRef,
    contentRect
  };
}
//# sourceMappingURL=useResizeObserver.js.map
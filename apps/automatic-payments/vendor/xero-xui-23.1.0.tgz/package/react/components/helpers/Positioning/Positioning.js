"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/es.promise.js");
var _clsx = _interopRequireDefault(require("clsx"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react = _interopRequireDefault(require("react"));
var _reactPortal = require("react-portal");
var _shallowCompare = _interopRequireDefault(require("../../../helpers/shallowCompare"));
var _constants = require("../../positioning/private/constants");
var _utils = require("../../positioning/private/utils");
var _doAsync = _interopRequireDefault(require("../doAsync"));
var _positionObserver = require("../UsePositionObserver/positionObserver");
var _xuiClassNamespace = require("../xuiClassNamespace");
var _positioning = _interopRequireDefault(require("./helpers/positioning"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
class Positioning extends _react.default.Component {
  constructor(...args) {
    super(...args);
    _defineProperty(this, "ref", /*#__PURE__*/_react.default.createRef());
    _defineProperty(this, "observing", false);
    _defineProperty(this, "state", {});
    _defineProperty(this, "setMaxDimensions", popupRect => {
      var _this$props$triggerRe;
      const baseRect = popupRect || ((_this$props$triggerRe = this.props.triggerRef) === null || _this$props$triggerRe === void 0 || (_this$props$triggerRe = _this$props$triggerRe.current) === null || _this$props$triggerRe === void 0 ? void 0 : _this$props$triggerRe.getBoundingClientRect());
      const {
        maxHeight,
        maxWidth,
        preferredLocation,
        shouldRestrictMaxHeight,
        triggerGap,
        viewportGutter,
        isNotResponsive
      } = this.props;
      const triggerDOM = this.props.triggerRef.current;
      const maxDimensions = (0, _utils.calculateMaxDimensions)(baseRect, maxHeight, maxWidth, preferredLocation, shouldRestrictMaxHeight, triggerGap, viewportGutter, triggerDOM, isNotResponsive);
      if (maxDimensions) {
        this.ref.current.firstChild.style.maxWidth = `${maxDimensions.maxWidth}px`;
        this.ref.current.firstChild.style.maxHeight = `${maxDimensions.maxHeight}px`;
      }
    });
    /* eslint-disable no-param-reassign */
    _defineProperty(this, "getContentRect", (contentElement, triggerRect) => {
      const previousStyle = {
        left: contentElement.style.left,
        top: contentElement.style.top
      };
      /**
       * We place the contentElement at the top left of the page before retrieving its measurements so
       * that the size is not influenced by the edges of the page.
       */
      contentElement.style.left = '0';
      contentElement.style.top = '0';
      const contentRect = contentElement.getBoundingClientRect();
      contentElement.style.left = previousStyle.left;
      contentElement.style.top = previousStyle.top;
      if (this.props.positionInViewport) {
        this.setMaxDimensions(triggerRect);
      }
      return contentRect;
    });
    /* eslint-enable no-param-reassign */
    _defineProperty(this, "updatePosition", async (updateSynchronously, currentTriggerRect) => {
      let triggerRect = currentTriggerRect;
      /**
       * This function uses mutable refs that can change at any time (e.g. if the component is
       * unmounted the refs will be set to `null`).
       *
       * We also run this function intermittently (which leads to poor performance, see the comment at
       * the end of this method for more info) and asynchronously (to help alleviate that poor
       * performance).
       *
       * Fortunately we don't actually care if this function fails after the component has been
       * unmounted so we can wrap the whole thing in a try/catch statement that swallows errors after
       * the component has been unmounted.
       */
      try {
        var _this$props$triggerRe2;
        const doSync = callback => new Promise(resolve => {
          resolve(callback());
        });
        const execute = updateSynchronously ? doSync : _doAsync.default;
        const {
          pageGutter,
          preferredLocation,
          preferredLocationFallbacks,
          triggerGap,
          positionInViewport,
          viewportGutter
        } = this.props;
        if (!this.ref.current || !((_this$props$triggerRe2 = this.props.triggerRef) !== null && _this$props$triggerRe2 !== void 0 && _this$props$triggerRe2.current)) {
          return;
        }
        if (!triggerRect) {
          triggerRect = await execute(() => {
            var _this$props$triggerRe3;
            return (_this$props$triggerRe3 = this.props.triggerRef.current) === null || _this$props$triggerRe3 === void 0 ? void 0 : _this$props$triggerRe3.getBoundingClientRect();
          });
        }
        const contentRect = await execute(
        // This function needs to be async to ensure that errors inside `this.getContentRect` get caught.
        // https://itnext.io/error-handling-with-async-await-in-js-26c3f20bc06a
        async () => this.getContentRect(this.ref.current, triggerRect));
        if (contentRect && triggerRect) {
          const positionHelper = await execute(() => new _positioning.default(preferredLocation, contentRect, triggerRect, triggerGap, pageGutter, positionInViewport, viewportGutter, preferredLocationFallbacks));
          const location = await execute(() => positionHelper.getLocation());
          const style = await execute(() => positionHelper.getPositionStyle());
          const isFullWidth = await execute(() => positionHelper.isFullWidth());

          // This function is called often so we only call `setState` if something has changed.
          if (this._isMounted && (location !== this.state.location || !(0, _shallowCompare.default)(style, this.state.style))) {
            this.setState({
              isFullWidth,
              location,
              style
            });
          }
        }
      } catch (error) {
        if (this._isMounted) {
          throw error;
        }
      }
    });
  }
  componentDidMount() {
    var _this$props$triggerRe4;
    this._isMounted = true;
    this.updatePosition(true);
    if (this.observing === false && (_this$props$triggerRe4 = this.props.triggerRef) !== null && _this$props$triggerRe4 !== void 0 && _this$props$triggerRe4.current) {
      (0, _positionObserver.observe)(this.props.triggerRef, currentTriggerRect => {
        this.updatePosition(false, currentTriggerRect);
      });
      this.observing = true;
    }
  }
  componentDidUpdate() {
    var _this$props$triggerRe5;
    if (this.observing === false && (_this$props$triggerRe5 = this.props.triggerRef) !== null && _this$props$triggerRe5 !== void 0 && _this$props$triggerRe5.current) {
      (0, _positionObserver.observe)(this.props.triggerRef, currentTriggerRect => {
        this.updatePosition(false, currentTriggerRect);
      });
      this.observing = true;
    }
    this.updatePosition(true);
  }
  componentWillUnmount() {
    var _this$props$triggerRe6;
    this._isMounted = false;
    if ((_this$props$triggerRe6 = this.props.triggerRef) !== null && _this$props$triggerRe6 !== void 0 && _this$props$triggerRe6.current) {
      (0, _positionObserver.unobserve)(this);
    }
  }
  render() {
    const {
      children,
      isPositioningDisabled,
      portalNode
    } = this.props;
    const {
      isFullWidth,
      location,
      style
    } = this.state;
    return /*#__PURE__*/(0, _jsxRuntime.jsx)(_reactPortal.Portal, {
      node: portalNode,
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: (0, _clsx.default)(`${_xuiClassNamespace.ns}-container`, this.props.portalClassName),
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          ref: this.ref,
          style: !isPositioningDisabled ? {
            position: 'absolute',
            ...style
          } : undefined,
          children: children(location, isFullWidth)
        })
      })
    });
  }
}
exports.default = Positioning;
Positioning.propTypes = {
  /**
   * This component requires `children` to be a function. The function receives 2 arguments,
   * `location` and `isFullWidth`, and returns a React node.
   *
   * The `location` is where the content ended up being positioned, this will be the
   * `preferredLocation` or the next available location.
   *
   * The `isFullWidth` flag is `true` when the width of the content is narrower than the body when
   * taking the `pageGutter` into consideration. This is useful for switching to a full-width style
   * when there is not enough room to position the content correctly.
   */
  children: _propTypes.default.func.isRequired,
  /** Force the desktop UI, even if the viewport is narrow enough for mobile. */
  isNotResponsive: _propTypes.default.bool,
  /**
   * Disables the positioning of the content. This is useful if you only need to
   * position the content in certain situations.
   */
  isPositioningDisabled: _propTypes.default.bool,
  /**
   * Setting a number here will force the maximum size of the child to be the number
   * provided (in pixels). When the viewport is smaller than this number, it still
   * shrinks, but never grows beyond that number. Setting either to -1 will set the value to null.
   */
  maxHeight: _propTypes.default.number,
  maxWidth: _propTypes.default.number,
  /**
   * Element to render the portal into.
   */
  portalNode: _propTypes.default.object,
  /**
   * How much space should be left between the edge of the page and the content to be positioned.
   */
  pageGutter: _propTypes.default.number,
  /**
   * Classname to apply to the portal
   */
  portalClassName: _propTypes.default.string,
  /**
   * Whether or not to limit the tooltip's positioning to be within the viewport
   */
  positionInViewport: _propTypes.default.bool,
  /**
   * The preferred location for the content. If the preferred location is not available the opposite
   * side of the trigger will be checked, followed by the right and bottom sides, and finally the
   * left and top sides.
   */
  preferredLocation: _propTypes.default.oneOf(_constants.positionOptions),
  /**
   * An array of preferred locations for the content. If the preferred location
   * is not available the opposite side of the trigger will be checked, followed
   * by the list of sides provided by preferredLocations.
   *
   * Default value:
   * [
      'right', 'bottom', 'left', 'top', 'right-top', 'right-bottom',
      'bottom-right', 'bottom-left', 'left-top', 'left-bottom', 'top-right',
      'top-left',
    ]
   */
  preferredLocationFallbacks: _propTypes.default.arrayOf(_propTypes.default.string),
  /**
   * Whether or not to restrict the maxHeight
   */
  shouldRestrictMaxHeight: _propTypes.default.bool,
  /**
   * How much space should be left between the trigger and the content to be positioned.
   */
  triggerGap: _propTypes.default.number,
  /**
   * The ref for the HTMLElement the content should be positioned around.
   */
  triggerRef: _propTypes.default.object,
  /**
   * A buffer value added to measure between the edge of the viewport and the
   * component before flipping its position. Use instead of pageGutter if limiting the content
   * to being positioned in the viewport.
   *
   * */
  viewportGutter: _propTypes.default.number
};
Positioning.defaultProps = {
  isNotResponsive: false,
  maxWidth: 220,
  viewportGutter: 10
};
//# sourceMappingURL=Positioning.js.map
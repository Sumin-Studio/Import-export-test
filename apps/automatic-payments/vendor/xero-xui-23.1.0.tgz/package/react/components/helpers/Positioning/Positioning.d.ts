import * as React from 'react';

import { Location } from './helpers/positioning';

interface Props {
  /**
   * This component requires `children` to be a function. The function receives 2 arguments,
   * `location` and `isFullWidth`, and returns a React node.
   *
   * The `location` is where the content ended up being positioned, this will be the
   * `preferredLocation` or the next available location.
   *
   * The `isFullWidth` flag is `true` when the width of the content is narrower than the body when
   * taking the `pageGutter` into consideration. This is useful for switching to a full-width style
   * when there is not enough room to position the content correctly.
   */
  children: (location?: Location, isFullWidth?: boolean) => React.ReactNode;
  /** Force the desktop UI, even if the viewport is narrow enough for mobile. */
  isNotResponsive?: boolean;
  /**
   * Disables the positioning of the content. This is useful if you only need to
   * position the content in certain situations.
   */
  isPositioningDisabled?: boolean;
  /**
   * Setting a number here will force the maximum size of the child to be the number
   * provided (in pixels). When the viewport is smaller than this number, it still
   * shrinks, but never grows beyond that number. Setting either to -1 will set the value to null.
   */
  maxHeight?: number;
  maxWidth?: number;
  /**
   * Element to render the portal into.
   */
  portalNode?: object;
  /**
   * How much space should be left between the edge of the page and the content to be positioned.
   */
  pageGutter?: number;
  /**
   * Classname to apply to the portal
   */
  portalClassName?: string;
  /**
   * Whether or not to limit the tooltip's positioning to be within the viewport
   */
  positionInViewport?: boolean;
  /**
   * The preferred location for the content. If the preferred location is not available the opposite
   * side of the trigger will be checked, followed by the right and bottom sides, and finally the
   * left and top sides.
   */
  preferredLocation?: Location;
  /**
   * An array of preferred locations for the content. If the preferred location
   * is not available the opposite side of the trigger will be checked, followed
   * by the list of sides provided by preferredLocations.
   *
   * Default value:
   * [
      'right', 'bottom', 'left', 'top', 'right-top', 'right-bottom',
      'bottom-right', 'bottom-left', 'left-top', 'left-bottom', 'top-right',
      'top-left',
    ]
   */
  preferredLocationFallbacks?: string[];
  /**
   * Whether or not to restrict the maxHeight
   */
  shouldRestrictMaxHeight?: boolean;
  /**
   * How much space should be left between the trigger and the content to be positioned.
   */
  triggerGap?: number;
  /**
   * The ref for the HTMLElement the content should be positioned around.
   */
  triggerRef: React.RefObject<HTMLElement>;
  /** A buffer value added to measure between the edge of the viewport and the
   * component before flipping its position. Use instead of pageGutter if limiting the content
   * to being positioned in the viewport.
   * */
  viewportGutter?: number;
}

interface State {
  isFullWidth?: boolean;
  location?: Location;
  style?: React.CSSProperties;
}

export default class Positioning extends React.Component<Props, State> {}

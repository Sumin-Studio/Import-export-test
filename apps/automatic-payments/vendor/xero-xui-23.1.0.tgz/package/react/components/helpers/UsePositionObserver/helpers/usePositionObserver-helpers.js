"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.unobserveElement = exports.observeElement = void 0;
var _helpers = require("./helpers");
const {
  observe,
  unobserve
} = (0, _helpers.observeDocumentForMutations)(() => {
  (0, _helpers.updateTargetPositions)(targetElements);
});
let targetElements = [];
let listenersAttached = false;
let observerAttached = false;
const listenerCallback = () => {
  targetElements = (0, _helpers.updateTargetPositions)(targetElements);
};
const resizeListenerCallback = () => {
  targetElements = (0, _helpers.updateTargetPositions)(targetElements, true);
};
if (!listenersAttached && (0, _helpers.addListeners)(listenerCallback, resizeListenerCallback)) {
  listenersAttached = true;
}
if (!observerAttached && observe()) {
  observerAttached = true;
}
const observeElement = (element, previousClientRect, callback) => {
  if (targetElements.length === 0) {
    if (!listenersAttached && (0, _helpers.addListeners)(listenerCallback, resizeListenerCallback)) {
      listenersAttached = true;
    }
    if (!observerAttached && observe()) {
      observerAttached = true;
    }
  }
  if (!targetElements.find(observedElement => observedElement.element === element)) {
    targetElements.push({
      element,
      previousClientRect,
      callback
    });
    callback(previousClientRect);
  }
};
exports.observeElement = observeElement;
const unobserveElement = element => {
  targetElements = targetElements.filter(observedElement => observedElement.element !== element);
  if (targetElements.length === 0) {
    (0, _helpers.removeListeners)(listenerCallback, resizeListenerCallback);
    listenersAttached = false;
    if (observerAttached && unobserve()) {
      observerAttached = false;
    }
  }
};
exports.unobserveElement = unobserveElement;
//# sourceMappingURL=usePositionObserver-helpers.js.map
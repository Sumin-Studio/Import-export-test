"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.unobserve = exports.observe = void 0;
var _resizeObserverPolyfill = _interopRequireDefault(require("resize-observer-polyfill"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const entryComponentMap = new WeakMap();
const entryBreakpointMap = new WeakMap();
const handleEntries = entries => {
  entries.forEach(entry => {
    // Match the DOM node with its component.
    const component = entryComponentMap.get(entry.target);
    const setBreakpoints = entryBreakpointMap.get(entry.target);
    if (!component) {
      // It may be possible for an application to delete the relevant components/elements
      // without un-mounting and un-observing them. This is an edge case we can't reproduce,
      // but we can guard against. [XUI-1074]
      return;
    }
    if (typeof setBreakpoints === 'function') {
      setBreakpoints(component, entry.contentRect.width);
    }
    if (typeof component._onResize === 'function') {
      // Specifying DOMRectReadOnly to avoid using the ResizeOberver polyfill's DOMRect
      component._onResize(entry.contentRect);
    }
  });
};

// Create a single ResizeObserver instance to handle all
// container elements. The instance is created with a callback,
// which is invoked as soon as an element is observed as well
// as any time that element's size changes.
const ro = new _resizeObserverPolyfill.default(handleEntries);
const observe = (component, setBreakpoints) => {
  var _component$_area;
  const element = component === null || component === void 0 || (_component$_area = component._area) === null || _component$_area === void 0 ? void 0 : _component$_area.current;
  if (!element) {
    return;
  }
  entryComponentMap.set(element, component);
  if (setBreakpoints !== undefined) {
    entryBreakpointMap.set(element, setBreakpoints);
  }
  ro === null || ro === void 0 || ro.observe(element);
};
exports.observe = observe;
const unobserve = component => {
  var _component$_area2;
  const element = component === null || component === void 0 || (_component$_area2 = component._area) === null || _component$_area2 === void 0 ? void 0 : _component$_area2.current;
  if (!element) {
    return;
  }
  entryComponentMap.delete(element);
  ro === null || ro === void 0 || ro.unobserve(element);
};
exports.unobserve = unobserve;
//# sourceMappingURL=resizeObserver.js.map
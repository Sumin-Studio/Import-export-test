"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = isRunningInJest;
function isRunningInJest() {
  var _process;
  return Boolean(typeof process !== 'undefined' && ((_process = process) === null || _process === void 0 || (_process = _process.env) === null || _process === void 0 ? void 0 : _process.JEST_WORKER_ID));
}
//# sourceMappingURL=isRunningInJest.js.map
export default function preventDefault(event: React.SyntheticEvent<HTMLElement>): void;

"use strict";

require("./versionCheck");
//# sourceMappingURL=xuiGlobalChecks.js.map
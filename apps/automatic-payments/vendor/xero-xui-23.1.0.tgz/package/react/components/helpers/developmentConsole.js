"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.logWarning = exports.logError = void 0;
var _flagDefinitions = _interopRequireDefault(require("../../helpers/flagDefinitions"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// These functions will log a warning or an error to the browser console,
// when in a dev environment. Pass them the name of the logging component
// plus a flagType (defined in the Guide), a message string, or both.

const logWarning = ({
  componentName,
  flagType,
  message
}) => {
  if (process.env.NODE_ENV === 'development') {
    const flagDef = flagType && _flagDefinitions.default[flagType] && `${_flagDefinitions.default[flagType].label} - ${_flagDefinitions.default[flagType].desc}`;
    // eslint-disable-next-line no-console
    console.warn(`${componentName}: ${[flagDef, message].join(' ')}`);
  }
};
exports.logWarning = logWarning;
const logError = ({
  componentName,
  flagType,
  message
}) => {
  if (process.env.NODE_ENV === 'development') {
    const flagDef = flagType && _flagDefinitions.default[flagType] && `${_flagDefinitions.default[flagType].label} - ${_flagDefinitions.default[flagType].desc}`;
    // eslint-disable-next-line no-console
    console.error(`${componentName}: ${[flagDef, message].join(' ')}`);
  }
};
exports.logError = logError;
//# sourceMappingURL=developmentConsole.js.map
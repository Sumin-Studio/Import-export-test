/**
 * Element does not exist during server side rendering.
 *
 * When using Element for propTypes this isn't an issue so we can safely mock it.
 */
declare const _default: {
    new (): Element;
    prototype: Element;
} | (() => void);
export default _default;

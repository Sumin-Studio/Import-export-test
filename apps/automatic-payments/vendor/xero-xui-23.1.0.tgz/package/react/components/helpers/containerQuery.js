"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "getWidthClassesFromState", {
  enumerable: true,
  get: function () {
    return _breakpoints.getWidthClassesFromState;
  }
});
exports.unobserve = exports.observe = void 0;
var _breakpoints = _interopRequireWildcard(require("./breakpoints"));
var _resizeObserver = require("./resizeObserver");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
const setBreakpoints = (observedComponent, width) => {
  // If breakpoints are defined on the observed element's component,
  // use them. Otherwise use the defaults.
  const customBreakpoints = observedComponent._breakpoints;
  const breakpoints = customBreakpoints || _breakpoints.default;

  // Set the matching breakpoints on the observed element.
  const newState = {};
  Object.keys(breakpoints).forEach(breakpoint => {
    const minWidth = breakpoints[breakpoint];
    newState[breakpoint] = width >= minWidth;
  });
  observedComponent.setState(newState);
};
const observe = component => {
  (0, _resizeObserver.observe)(component, setBreakpoints);
};
exports.observe = observe;
const unobserve = component => {
  (0, _resizeObserver.unobserve)(component);
};
exports.unobserve = unobserve;
//# sourceMappingURL=containerQuery.js.map
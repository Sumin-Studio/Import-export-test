"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var React = _interopRequireWildcard(require("react"));
var _noop = _interopRequireDefault(require("./noop"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
const defaultOptions = {
  attributes: false,
  characterData: false,
  childList: true,
  subtree: false
};

/**
 * A `useEffect` function for creating a `MutationObserver` to monitor changes in a given element.
 * @param {React.RefObject<HTMLElement>} ref The React `ref` for the element to be observed.
 * @param {MutationCallback} callback The callback function to be passed to the `MutationObserver`
 * @param {MutationObserverInit} options The options object to be passed to the `observe` method. Defaults are: {attributes: false, characterData: false, childList: true, subtree: false}
 */
const useMutationObserver = (ref, callback, options = defaultOptions) => {
  React.useEffect(() => {
    if (ref.current) {
      const observer = new MutationObserver(callback);
      observer.observe(ref.current, options);
      return () => observer.disconnect();
    }
    return _noop.default;
  }, [callback, ref, options]);
};
var _default = exports.default = useMutationObserver;
//# sourceMappingURL=useMutationObserver.js.map
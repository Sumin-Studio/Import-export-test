"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
/**
 * Element does not exist during server side rendering.
 *
 * When using Element for propTypes this isn't an issue so we can safely mock it.
 */
var _default = exports.default = typeof Element !== 'undefined' ? Element : () => {};
//# sourceMappingURL=Element.js.map
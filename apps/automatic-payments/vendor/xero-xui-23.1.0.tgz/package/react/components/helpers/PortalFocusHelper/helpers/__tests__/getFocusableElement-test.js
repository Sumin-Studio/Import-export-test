import { render, screen } from '@testing-library/react';
import React from 'react';

import getFocusableElement from '../getFocusableElement';

const automationId = 'test';

describe('getFocusableElement', () => {
  test('returns the element if it is focusable', () => {
    // Arrange
    render(<input data-automationid={automationId} />);

    // Act
    const focusableElement = getFocusableElement(screen.getByTestId(automationId));

    // Assert
    expect(focusableElement).toBe(screen.getByTestId(automationId));
  });

  test('returns the first focusable child if the element is not focusable', () => {
    // Arrange
    const expectedId = 'expected-input';
    render(
      <div data-automationid={automationId}>
        <input id={expectedId} />
      </div>,
    );

    // Act
    const focusableElement = getFocusableElement(screen.getByTestId(automationId));

    // Assert
    expect(focusableElement).toHaveAttribute('id', expectedId);
  });

  test('returns null if the element is not focusable and has no focusable children', () => {
    // Arrange
    render(
      <div data-automationid={automationId}>
        <div />
      </div>,
    );

    // Act
    const focusableElement = getFocusableElement(screen.getByTestId(automationId));

    // Assert
    expect(focusableElement).toBe(null);
  });

  test('returns null if no element is passed in', () => {
    expect(getFocusableElement(null)).toBe(null);
  });
});

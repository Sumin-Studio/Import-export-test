export declare let ns: string;
/**
 * Sets the CSS class namespace (prefix) that should be used
 * by components. Use this if you have set the $ns variable in SCSS to
 * something other than `xui`. This should be set BEFORE any components
 * have been imported.
 * @param {String} name
 */
export declare function setXUIClassNamespace(name: string): void;

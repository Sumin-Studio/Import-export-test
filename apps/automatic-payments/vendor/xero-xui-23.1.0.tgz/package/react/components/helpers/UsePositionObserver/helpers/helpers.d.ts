export interface TargetElement {
    element: HTMLElement;
    previousClientRect: DOMRect;
    callback: (clientRect: DOMRect) => void;
}
export declare const componentHasChangedPosition: (oldRect: DOMRect, newRect: DOMRect) => boolean;
export declare const updateTargetPositions: (targets: Array<TargetElement>, updateAll?: boolean) => TargetElement[];
export declare const observeDocumentForMutations: (callback: (mutationList: MutationRecord[]) => void) => {
    observe: () => boolean;
    unobserve: () => boolean;
};
export declare const addListeners: (listenerCallback: () => void, resizeListenerCallback: () => void) => boolean;
export declare const removeListeners: (listenerCallback: () => void, resizeListenerCallback: () => void) => void;

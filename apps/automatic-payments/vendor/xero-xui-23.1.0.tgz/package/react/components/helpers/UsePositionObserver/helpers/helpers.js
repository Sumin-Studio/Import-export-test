"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.updateTargetPositions = exports.removeListeners = exports.observeDocumentForMutations = exports.componentHasChangedPosition = exports.addListeners = void 0;
const componentHasChangedPosition = (oldRect, newRect) => {
  if (oldRect.left === newRect.left && oldRect.top === newRect.top && oldRect.width === newRect.width && oldRect.height === newRect.height) {
    return false;
  }
  return true;
};
exports.componentHasChangedPosition = componentHasChangedPosition;
const updateTargetPositions = (targets, updateAll) => {
  const updatedTargets = targets;
  targets.forEach(({
    element,
    previousClientRect,
    callback
  }, index) => {
    const currentClientRect = element.getBoundingClientRect();
    if (!updateAll && !componentHasChangedPosition(previousClientRect, currentClientRect)) {
      return;
    }
    updatedTargets[index].previousClientRect = currentClientRect;
    callback(currentClientRect);
  });
  return updatedTargets;
};

// MutationObserver that observes the entire document and updates the trigger if any changes occur
exports.updateTargetPositions = updateTargetPositions;
const observeDocumentForMutations = callback => {
  if (typeof MutationObserver === 'undefined') {
    return {
      observe: () => false,
      unobserve: () => false
    };
  }
  const observer = new MutationObserver(callback);
  return {
    observe: () => {
      var _document, _document2;
      const container = ((_document = document) === null || _document === void 0 ? void 0 : _document.documentElement) || ((_document2 = document) === null || _document2 === void 0 ? void 0 : _document2.body);
      if (!container) {
        return false;
      }
      const config = {
        attributes: true,
        attributeOldValue: true,
        characterData: true,
        childList: true,
        subtree: true
      };
      observer.observe(container, config);
      return true;
    },
    unobserve: () => {
      observer.disconnect();
      return true;
    }
  };
};
exports.observeDocumentForMutations = observeDocumentForMutations;
const addListeners = (listenerCallback, resizeListenerCallback) => {
  if (typeof document === 'undefined' || typeof window === 'undefined') {
    return false;
  }
  if (document.readyState !== 'complete') {
    document.addEventListener('DOMContentLoaded', listenerCallback);
    document.addEventListener('load', listenerCallback);
  }
  window.addEventListener('resize', resizeListenerCallback);
  window.addEventListener('scroll', listenerCallback, true);
  document.addEventListener('animationend', listenerCallback);
  document.addEventListener('MSAnimationEnd', listenerCallback); // IE
  document.addEventListener('webkitAnimationEnd', listenerCallback); // Chrome + Safari

  return true;
};
exports.addListeners = addListeners;
const removeListeners = (listenerCallback, resizeListenerCallback) => {
  if (typeof document === 'undefined' || typeof window === 'undefined') {
    return;
  }
  document.removeEventListener('DOMContentLoaded', listenerCallback);
  document.removeEventListener('load', listenerCallback);
  window.removeEventListener('resize', resizeListenerCallback);
  window.removeEventListener('scroll', listenerCallback, true);
  document.removeEventListener('animationend', listenerCallback);
  document.removeEventListener('MSAnimationEnd', listenerCallback); // IE
  document.removeEventListener('webkitAnimationEnd', listenerCallback); // Chrome + Safari
};
exports.removeListeners = removeListeners;
//# sourceMappingURL=helpers.js.map
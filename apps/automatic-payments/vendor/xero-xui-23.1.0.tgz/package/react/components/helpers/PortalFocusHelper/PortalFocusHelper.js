"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/es.array.includes.js");
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react = _interopRequireDefault(require("react"));
var _getFocusableDescendants = _interopRequireWildcard(require("../getFocusableDescendants"));
var _getNextFocusableElement = _interopRequireDefault(require("../getNextFocusableElement"));
var _Element = _interopRequireDefault(require("../polyfills/Element"));
var _reactKeyHandler = require("../reactKeyHandler");
var _getFocusableElement = _interopRequireDefault(require("./helpers/getFocusableElement"));
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); } /* eslint-disable jsx-a11y/no-static-element-interactions */ /* eslint-disable jsx-a11y/no-noninteractive-tabindex */
class PortalFocusHelper extends _react.default.Component {
  constructor(...args) {
    super(...args);
    _defineProperty(this, "wrapperRef", /*#__PURE__*/_react.default.createRef());
    _defineProperty(this, "focusPortalKeyDownHandler", event => {
      const {
        focusPortalRef,
        onReturnFocus,
        triggerElementRef
      } = this.props;
      const focusableElement = triggerElementRef || (0, _getFocusableElement.default)(focusPortalRef.current);
      const nextFocusableElement = (0, _getNextFocusableElement.default)(focusableElement);
      if (!focusableElement) {
        return;
      }
      if (event.target === focusableElement) {
        if ((0, _reactKeyHandler.isKeyShiftTab)(event)) {
          onReturnFocus === null || onReturnFocus === void 0 || onReturnFocus();
          return;
        }
        if (event.key === _reactKeyHandler.eventKeyValues.tab && this.focusOnThePortalledElement()) {
          event.preventDefault();
        }
      }
      if (event.target === nextFocusableElement) {
        if ((0, _reactKeyHandler.isKeyShiftTab)(event) && this.focusOnThePortalledElement(true)) {
          event.preventDefault();
          return;
        }
        if (event.key === _reactKeyHandler.eventKeyValues.tab) {
          onReturnFocus === null || onReturnFocus === void 0 || onReturnFocus();
        }
      }
    });
    /**
     * Focuses on the portalled element.
     *
     * @param {boolean} shouldFocusOnLastElement Determines whether to focus on the last element in
     * the Portal.
     *
     * @returns {boolean} `true` if an element gets focused, `false` if there is no element to focus
     * on.
     */
    _defineProperty(this, "focusOnThePortalledElement", shouldFocusOnLastElement => {
      const {
        onReturnFocus
      } = this.props;
      if (!this.wrapperRef.current) {
        return false;
      }
      const focusableDescendants = (0, _getFocusableDescendants.default)(this.wrapperRef.current);
      if (focusableDescendants.length === 0) {
        onReturnFocus === null || onReturnFocus === void 0 || onReturnFocus();
        return false;
      }
      if (!shouldFocusOnLastElement) {
        focusableDescendants[0].focus();
      } else {
        focusableDescendants[focusableDescendants.length - 1].focus();
      }
      return true;
    });
    // eslint-disable-next-line class-methods-use-this -- This could be abstracted but it's nice to have it alongside all the other methods
    _defineProperty(this, "focusOnTheFirstElementOnThePage", () => {
      const firstElementOnThePage = document.querySelector(_getFocusableDescendants.focusableDescendantsSelector);
      firstElementOnThePage.focus();
    });
    _defineProperty(this, "focusOnTheLastElementOnThePage", () => {
      const focusableElements = document.querySelectorAll(_getFocusableDescendants.focusableDescendantsSelector);
      const focusableElementsArray = Object.values(focusableElements);
      const dropdown = this.wrapperRef.current.parentElement;
      const dropdownFocusableElements = dropdown.querySelectorAll(_getFocusableDescendants.focusableDescendantsSelector);
      const dropdownFocusableElementsArray = Object.values(dropdownFocusableElements);
      const elements = focusableElementsArray.filter(element => !dropdownFocusableElementsArray.includes(element));
      const lastElementOnThePage = elements[elements.length - 1];
      lastElementOnThePage.focus();
    });
    /**
     * Returns the focus to the page.
     *
     * @param {boolean} shouldFocusOnNextElement Determines whether to return the focus to
     * `this.props.focusPortalRef` or the focusable element that follows it.
     */
    _defineProperty(this, "returnFocus", shouldFocusOnNextElement => {
      const {
        focusPortalRef,
        onReturnFocus,
        triggerElementRef
      } = this.props;
      const focusableElement = triggerElementRef || (0, _getFocusableElement.default)(focusPortalRef.current);
      if (!focusableElement) {
        // eslint-disable-next-line no-console
        console.warn(`Unable to return focus to the page. ${focusPortalRef.current} is not focusable and does not contain any focusable children.`);
        return;
      }
      const nextFocusableElement = (0, _getNextFocusableElement.default)(focusableElement);
      if (shouldFocusOnNextElement && nextFocusableElement) {
        nextFocusableElement.focus();
      } else {
        focusableElement.focus();
      }
      onReturnFocus === null || onReturnFocus === void 0 || onReturnFocus();
    });
  }
  componentDidMount() {
    document.addEventListener('keydown', this.focusPortalKeyDownHandler);
  }
  componentWillUnmount() {
    document.removeEventListener('keydown', this.focusPortalKeyDownHandler);
  }
  render() {
    const {
      children
    } = this.props;
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        onFocus: () => {
          this.focusOnTheFirstElementOnThePage();
        },
        tabIndex: 0
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        onFocus: () => {
          this.returnFocus();
        },
        tabIndex: 0
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        ref: this.wrapperRef,
        children: children
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        onFocus: () => {
          this.returnFocus(true);
        },
        tabIndex: 0
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        onFocus: () => {
          this.focusOnTheLastElementOnThePage();
        },
        tabIndex: 0
      })]
    });
  }
}
exports.default = PortalFocusHelper;
PortalFocusHelper.propTypes = {
  children: _propTypes.default.node,
  /**
   * An element that is focusable or has focusable children. Used as an entry point into the Portal.
   * Pressing `Tab` while it is focused will send the focus to the Portal. When the focus needs to
   * return back to the page, it will use this element to figure out where the focus should return
   * to.
   */
  focusPortalRef: _propTypes.default.shape({
    current: _propTypes.default.instanceOf(_Element.default)
  }).isRequired,
  /**
   * An optional function to be called whenever the focus leaves the portal and is returned to the
   * page.
   */
  onReturnFocus: _propTypes.default.func,
  /**
   * This prop allows dropdowns with more complex triggers (e.g. `XUIAutocompleter`,
   * where the trigger component contains multiple focusable elements) to specify which
   * element should be used to calculate the correct navigtion behaviour inside `PortalFocusHelper`.
   */
  triggerElementRef: _propTypes.default.shape({
    current: _propTypes.default.instanceOf(_Element.default)
  })
};
//# sourceMappingURL=PortalFocusHelper.js.map
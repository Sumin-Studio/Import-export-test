export declare const portalClass: string;
export declare const statusPortalClass: string;
export default function portalContainer(): Element;
export declare function statusPortalContainer(): Element;

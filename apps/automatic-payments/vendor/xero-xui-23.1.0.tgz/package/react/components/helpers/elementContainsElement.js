"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
/**
 * `elementContainsElement` extends [`node.contains`](https://developer.mozilla.org/en-US/docs/Web/API/Node/contains)
 * with support for portalled elements.
 *
 * This function relies on the correct implementation of the
 * [`aria-owns`](https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Attributes/aria-owns)
 * attribute.
 *
 * @param containerElement The element to search within
 * @param elementToFind The element expected to be found within `containerElement`
 * @returns `true` if `containerElement` contains `elementToFind`, otherwise returns `false`
 */
function elementContainsElement(containerElement, elementToFind) {
  return Boolean(containerElement.contains(elementToFind) || getPortalledDescendants(containerElement).find(portalledDescendant => portalledDescendant.contains(elementToFind)));
}

/**
 * `getPortalledDescendants` scans the children of `rootElement` for descendants that have been
 * portalled to a different section of the DOM.
 *
 * This function relies on the correct implementation of the
 * [`aria-owns`](https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Attributes/aria-owns)
 * attribute.
 *
 * @param rootElement The root HTML element to start scanning from
 * @returns Array of elements referenced via `aria-owns`
 */
function getPortalledDescendants(rootElement) {
  const portalledDescendants = [];
  const portalParents = [rootElement, ...Array.from(rootElement.querySelectorAll('[aria-owns]'))];
  portalParents.forEach(portalParent => {
    const portalledDescendantId = portalParent.getAttribute('aria-owns');
    if (portalledDescendantId === null) {
      return;
    }
    const portalledDescendant = document.getElementById(portalledDescendantId);
    if (portalledDescendant === null) {
      return;
    }
    portalledDescendants.push(portalledDescendant);
    portalledDescendants.push(...getPortalledDescendants(portalledDescendant));
  });
  return portalledDescendants;
}
var _default = exports.default = elementContainsElement;
//# sourceMappingURL=elementContainsElement.js.map
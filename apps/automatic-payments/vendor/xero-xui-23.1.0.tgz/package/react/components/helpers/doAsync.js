"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = doAsync;
require("core-js/modules/es.promise.js");
/**
 * `doAsync` will call the provided callback just before the next repaint.
 *
 * Wrapping a sequence of expensive calculations in `doAsync` will allow the UI to continue
 * updating.
 *
 * e.g.
 * ```
 * await doAsync(() => expensiveCalculation());
 * await doAsync(() => expensiveCalculation2());
 * ```
 * @param {function} callback The function to call asynchronously
 */
function doAsync(callback, useAnimationFrame = true) {
  /**
   * Using requestAnimationFrame instead of setTimeout allows us to ensure only one `doAsync` is
   * called each frame.
   */
  const asyncMethod = useAnimationFrame ? requestAnimationFrame : setTimeout;
  return new Promise(resolve => {
    asyncMethod(() => {
      resolve(callback());
    });
  });
}
//# sourceMappingURL=doAsync.js.map
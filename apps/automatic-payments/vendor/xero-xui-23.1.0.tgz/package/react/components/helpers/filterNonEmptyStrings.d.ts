export default function filterNonEmptyStrings(strings: unknown[]): unknown[];

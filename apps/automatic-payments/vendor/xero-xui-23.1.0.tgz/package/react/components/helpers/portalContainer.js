"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = portalContainer;
exports.statusPortalClass = exports.portalClass = void 0;
exports.statusPortalContainer = statusPortalContainer;
var _xuiClassNamespace = require("./xuiClassNamespace");
const portalClass = exports.portalClass = `${_xuiClassNamespace.ns}-portal`;
const statusPortalClass = exports.statusPortalClass = `${_xuiClassNamespace.ns}-status-portal`;
function createPortalContainer(className) {
  const container = document.createElement('div');
  container.classList.add(className);
  document.body.appendChild(container);
  return container;
}
function portalContainer() {
  return document.querySelector(`body > .${portalClass}`) || createPortalContainer(portalClass);
}
function statusPortalContainer() {
  return document.querySelector(`body > .${statusPortalClass}`) || createPortalContainer(statusPortalClass);
}
//# sourceMappingURL=portalContainer.js.map
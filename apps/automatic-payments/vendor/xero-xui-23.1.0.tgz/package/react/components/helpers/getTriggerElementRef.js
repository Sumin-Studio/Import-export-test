"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
const resolveComponent = ref => {
  if (ref instanceof HTMLElement) {
    return ref;
  }
  if ('current' in ref && ref.current instanceof HTMLElement) {
    return ref.current;
  }
  if ('rootNode' in ref && ref.rootNode) {
    return resolveComponent(ref.rootNode);
  }
  if ('current' in ref && ref.current) {
    return resolveComponent(ref.current);
  }
  return null;
};
const getTriggerElementRef = triggerRef => ({
  _triggerRef: triggerRef,
  get current() {
    return resolveComponent(this._triggerRef);
  }
});
var _default = exports.default = getTriggerElementRef;
//# sourceMappingURL=getTriggerElementRef.js.map
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.textChildOrLabelId = exports.loadingAriaLabelOnly = exports.default = exports.ariaLabelOnly = void 0;
var _developmentConsole = require("./developmentConsole");
/**
 * Method for conditionally warning the user that some prop(s) are required from XUI 19 to be able to provide an aria label to the user
 *
 * @param {string} componentName - Name of the component
 * @param {string[]} conditions - Human readable strings for the conditions that must be met
 * @param {Array<string | boolean>} isLabelProvided - List of conditions that if true mean the label has already been provided
 */
const labelRequiredError = (componentName, conditions, isLabelProvided) => {
  if (isLabelProvided.some(condition => condition)) {
    return;
  }
  const message = `One of the following is required in order to meet WCAG accessibility guidelines: ${conditions}`;
  (0, _developmentConsole.logError)({
    componentName,
    message
  });
};

// Messages to consistently communicate how to fulfill common sets of criteria.
exports.default = labelRequiredError;
const textChildOrLabelId = exports.textChildOrLabelId = ['includes a child with text', 'labelId provided']; // For inline controls: Checkbox, Radio, Switch
const ariaLabelOnly = exports.ariaLabelOnly = ['`ariaLabel` provided']; // Various controls where only an ARIA label is required
const loadingAriaLabelOnly = exports.loadingAriaLabelOnly = ['loadingAriaLabel when isLoading'];
//# sourceMappingURL=labelRequiredError.js.map
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = NOOP;
function NOOP() {}
//# sourceMappingURL=noop.js.map
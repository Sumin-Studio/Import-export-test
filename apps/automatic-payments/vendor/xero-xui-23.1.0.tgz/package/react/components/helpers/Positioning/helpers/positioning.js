"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.oppositeLocationMap = exports.default = void 0;
var _domHelpers = require("../../../positioning/private/dom-helpers");
var _utils = require("../../../positioning/private/utils");
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); } /* eslint-disable @typescript-eslint/default-param-last -- TODO (XUI-4278): Some of the parameters in this file seem like they should have defaults. This can be removed once this has been determined and the order has been updated. */
const oppositeLocationMap = exports.oppositeLocationMap = {
  bottom: 'top',
  left: 'right',
  right: 'left',
  top: 'bottom',
  'bottom-left': 'top-left',
  'bottom-right': 'top-right',
  'left-top': 'right-top',
  'left-bottom': 'right-bottom',
  'right-top': 'left-top',
  'right-bottom': 'left-bottom',
  'top-left': 'bottom-left',
  'top-right': 'bottom-right'
};
class PositioningHelper {
  /**
   * Creates a helper for positioning content next to a trigger. Useful for elements like tooltips
   * and popovers.
   *
   * The helper needs to be instantiated with the correct information before calling `getLocation`
   * or `getPositionStyle`.
   *
   * @param preferredLocation Determines the side of the trigger that the content should be
   * displayed. If the preferred location is unavailable then a valid location will be chosen.
   * @param contentRect A [DOMRect](https://developer.mozilla.org/en-US/docs/Web/API/DOMRect)
   * representing the content to be positioned.
   * @param triggerRect A [DOMRect](https://developer.mozilla.org/en-US/docs/Web/API/DOMRect)
   * representing the trigger to position the content around.
   * @param triggerGap How much space should be left around the trigger.
   * @param pageGutter How close the content can get to the edge of the page.
   * @param positionInViewport Whether or not the item should be limited to being displayed
   * within the viewport (eg for a tooltip).
   * @param viewportGutter  A buffer value added to measure between the edge of the viewport
   * and the component before flipping its position.
   */
  constructor(preferredLocation = 'bottom', contentRect, triggerRect, triggerGap = 0, pageGutter = 0, positionInViewport, viewportGutter, preferredLocationFallbacks = ['right', 'bottom', 'left', 'top', 'right-top', 'right-bottom', 'bottom-right', 'bottom-left', 'left-top', 'left-bottom', 'top-right', 'top-left']) {
    _defineProperty(this, "preferredLocation", void 0);
    _defineProperty(this, "contentRect", void 0);
    _defineProperty(this, "triggerRect", void 0);
    _defineProperty(this, "pageGutter", void 0);
    _defineProperty(this, "triggerGap", void 0);
    _defineProperty(this, "positionInViewport", void 0);
    _defineProperty(this, "viewportGutter", void 0);
    _defineProperty(this, "preferredLocations", void 0);
    /**
     * Map of the vertical/horizontal (top/left) axis for a side.
     */
    _defineProperty(this, "axisMap", {
      bottom: 'top',
      left: 'left',
      right: 'left',
      top: 'top'
    });
    /**
     * Map of the vertical/horizontal (top/left) axis adjacent to a side.
     */
    _defineProperty(this, "adjacentAxisMap", {
      bottom: 'left',
      left: 'top',
      right: 'top',
      top: 'left'
    });
    const {
      side,
      alignment
    } = (0, _utils.getPreferredPosition)(preferredLocation);
    if (alignment === 'center') {
      this.preferredLocation = side;
    } else {
      this.preferredLocation = preferredLocation;
    }
    this.positionInViewport = positionInViewport;
    this.contentRect = contentRect;
    this.triggerRect = triggerRect;
    this.pageGutter = pageGutter;
    this.viewportGutter = viewportGutter;
    this.triggerGap = triggerGap;
    this.preferredLocationFallbacks = preferredLocationFallbacks;
  }

  /**
   * If the preferred location is not available the opposite side of the trigger will be checked,
   * followed by the right and bottom sides, and finally the left and top sides.
   *
   * @returns {string} The best available location.
   */
  getLocation() {
    const pageRect = {
      height: Math.max(document.body.clientHeight, window.innerHeight),
      width: Math.max(document.body.clientWidth, window.innerWidth)
    };
    let validLocationMap = {};

    // check that the element is in the viewport
    if (this.positionInViewport) {
      const spaces = (0, _domHelpers.getSpacesAroundTrigger)(this.triggerRect);
      validLocationMap = {
        left: this.contentRect.width <= spaces.left - this.viewportGutter - this.triggerGap,
        top: this.contentRect.height <= spaces.above - this.viewportGutter - this.triggerGap,
        bottom: this.contentRect.height <= spaces.below - this.viewportGutter - this.triggerGap,
        right: this.contentRect.width <= spaces.right - this.viewportGutter - this.triggerGap,
        'bottom-left': this.contentRect.height <= spaces.below - this.viewportGutter - this.triggerGap && this.contentRect.width <= spaces.right - this.viewportGutter - this.triggerGap + this.triggerRect.width,
        'bottom-right': this.contentRect.height <= spaces.below - this.viewportGutter - this.triggerGap && this.contentRect.width <= spaces.left - this.viewportGutter - this.triggerGap + this.triggerRect.width,
        'top-left': this.contentRect.height <= spaces.above - this.viewportGutter - this.triggerGap && this.contentRect.width <= spaces.right - this.viewportGutter - this.triggerGap + this.triggerRect.width,
        'top-right': this.contentRect.height <= spaces.above - this.viewportGutter - this.triggerGap && this.contentRect.width <= spaces.left - this.viewportGutter - this.triggerGap + this.triggerRect.width,
        'left-top': this.contentRect.width <= spaces.left - this.viewportGutter - this.triggerGap && this.contentRect.height <= spaces.below - this.triggerGap - this.viewportGutter + this.triggerRect.height,
        'left-bottom': this.contentRect.width <= spaces.left - this.viewportGutter - this.triggerGap && this.contentRect.height <= spaces.above - this.triggerGap - this.viewportGutter + this.triggerRect.height,
        'right-top': this.contentRect.width <= spaces.right - this.viewportGutter - this.triggerGap && this.contentRect.height <= spaces.below - this.triggerGap - this.viewportGutter + this.triggerRect.height,
        'right-bottom': this.contentRect.width <= spaces.right - this.viewportGutter - this.triggerGap && this.contentRect.height <= spaces.above - this.triggerGap - this.viewportGutter + this.triggerRect.height
      };
    } else {
      validLocationMap = {
        left: this.getPosition('left') >= this.pageGutter,
        top: this.getPosition('top') >= this.pageGutter,
        bottom: this.getPosition('bottom') + this.contentRect.height <= pageRect.height - this.pageGutter,
        right: this.getPosition('right') + this.contentRect.width <= pageRect.width - this.pageGutter,
        'bottom-left': this.getPosition('bottom') + this.contentRect.height <= pageRect.height - this.pageGutter && this.getPosition('left') + this.triggerGap + this.contentRect.width >= this.pageGutter,
        'bottom-right': this.getPosition('bottom') + this.contentRect.height <= pageRect.height - this.pageGutter && this.getPosition('right') - this.contentRect.width - this.triggerGap <= pageRect.width - this.pageGutter,
        'top-left': this.getPosition('top') >= this.pageGutter && this.getPosition('left') + this.triggerGap + this.contentRect.width >= this.pageGutter,
        'top-right': this.getPosition('top') >= this.pageGutter && this.getPosition('right') - this.contentRect.width - this.triggerGap <= pageRect.width - this.pageGutter,
        'left-top': this.getPosition('left') >= this.pageGutter && this.getPosition('top') + this.triggerGap + this.contentRect.height >= this.pageGutter,
        'left-bottom': this.getPosition('left') >= this.pageGutter && this.getPosition('bottom') - this.triggerGap - this.contentRect.height <= pageRect.height - this.pageGutter,
        'right-top': this.getPosition('right') + this.contentRect.width <= pageRect.width - this.pageGutter && this.getPosition('top') + this.triggerGap + this.contentRect.height >= this.pageGutter,
        'right-bottom': this.getPosition('right') + this.contentRect.width <= pageRect.width - this.pageGutter && this.getPosition('bottom') - this.triggerGap - this.contentRect.height <= pageRect.height - this.pageGutter
      };
    }
    const finalLocation = [this.preferredLocation, oppositeLocationMap[this.preferredLocation], ...this.preferredLocationFallbacks].filter(location => validLocationMap[location])[0];
    return finalLocation || this.preferredLocation;
  }

  /**
   * Calculates the absolute position for the content based on the positions and sizes of the
   * trigger, content, and page.
   *
   * @returns {{left: number, top: number}} The absolute position for the content.
   */
  getPositionStyle() {
    const location = this.getLocation();
    const {
      side
    } = (0, _utils.getPreferredPosition)(location);
    const position = this.getPosition(side);
    const alignmentStyle = this.getAlignment(location);
    return {
      [this.axisMap[side]]: position,
      [this.adjacentAxisMap[side]]: alignmentStyle
    };
  }

  /**
   * Calculates whether the content is narrower than the body. Useful for switching to a full-width
   * style.
   *
   * @returns {boolean} True if the content is as wide as or wider than the body.
   */
  isFullWidth() {
    return this.contentRect.width >= document.body.getBoundingClientRect().width;
  }
  getAlignment(location) {
    const {
      side,
      alignment: adjacentSide
    } = (0, _utils.getPreferredPosition)(location);
    const axisSizeMap = {
      left: 'width',
      top: 'height'
    };
    let offsetAlignment = this.triggerRect[axisSizeMap[this.adjacentAxisMap[side]]] / 2 - this.contentRect[axisSizeMap[this.adjacentAxisMap[side]]] / 2;
    if (adjacentSide === 'left' || adjacentSide === 'top') {
      offsetAlignment = 0;
    }
    if (adjacentSide === 'right') {
      offsetAlignment = this.triggerRect[axisSizeMap[this.adjacentAxisMap[side]]] - this.contentRect[axisSizeMap[this.adjacentAxisMap[side]]];
    }
    if (adjacentSide === 'bottom') {
      offsetAlignment = this.triggerRect[axisSizeMap[this.adjacentAxisMap[side]]] - this.contentRect[axisSizeMap[this.adjacentAxisMap[side]]];
    }
    const alignmentValue = this.triggerRect[this.adjacentAxisMap[side]] + offsetAlignment + this.getScrollOffset(this.adjacentAxisMap[side]);
    const axis = this.adjacentAxisMap[side];
    const pageRect = {
      height: Math.max(document.body.clientHeight, window.innerHeight),
      width: Math.max(document.body.clientWidth, window.innerWidth)
    };
    const clampedAlignment = Math.max(Math.min(alignmentValue, pageRect[axisSizeMap[axis]] - this.pageGutter - this.contentRect[axisSizeMap[this.adjacentAxisMap[side]]]), axis === 'top' ? this.pageGutter : Math.min(this.pageGutter, (pageRect.width - this.contentRect.width) / 2));
    return clampedAlignment;
  }
  getPosition(side) {
    const bufferMap = {
      bottom: this.triggerGap,
      left: -this.triggerGap,
      right: this.triggerGap,
      top: -this.triggerGap
    };
    const positionOffsetMap = {
      bottom: this.triggerRect.height,
      left: -this.contentRect.width,
      right: this.triggerRect.width,
      top: -this.contentRect.height
    };
    return this.triggerRect[this.axisMap[side]] + positionOffsetMap[side] + bufferMap[side] + this.getScrollOffset(this.axisMap[side]);
  }

  // eslint-disable-next-line class-methods-use-this
  getScrollOffset(axis) {
    return axis === 'left' ? window.pageXOffset : window.pageYOffset;
  }
}
exports.default = PositioningHelper;
//# sourceMappingURL=positioning.js.map
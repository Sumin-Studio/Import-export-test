"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = sortRefsByDOMOrder;
require("core-js/modules/es.array.sort.js");
function sortRefsByDOMOrder(refs) {
  return [...refs].sort((a, b) => {
    if (!a.current || !b.current) {
      return 0;
    }
    return (
      // eslint-disable-next-line no-bitwise
      a.current.compareDocumentPosition(b.current) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1
    );
  });
}
//# sourceMappingURL=sortRefsByDOMOrder.js.map
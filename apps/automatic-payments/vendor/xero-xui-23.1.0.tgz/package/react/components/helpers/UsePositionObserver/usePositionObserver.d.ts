import * as React from 'react';
import { XUIComponent } from '../../../models/XUIComponent';
/**
 * A `useEffect` function for creating a `PositionObserver` to monitor changes in position of a given element.
 * @param {Object} elementRef The ref for the HTML element to be observed.
 * @param {function} callback An optional callback function to be executed each time there is a change in position
 */
declare const usePositionObserver: (elementRef: React.MutableRefObject<XUIComponent> | React.RefObject<XUIComponent>, callback?: (currentClientRect: DOMRect) => void) => DOMRect | undefined;
export default usePositionObserver;

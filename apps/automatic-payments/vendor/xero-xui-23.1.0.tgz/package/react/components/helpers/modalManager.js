"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.registerModal = exports.openedModals = exports.deRegisterTopModal = void 0;
var _lockScroll = require("./lockScroll");
var _portalContainer = require("./portalContainer");
const openedModals = exports.openedModals = []; // modal registry

// Which modal is on the top of the stack?
const getTopModal = () => openedModals[openedModals.length - 1];

// To properly set the aria-hidden attribute, we need all the siblings of the portal.
const getModalSiblings = () => {
  // Only do this, if the portal is found where expected.
  if (document.querySelector(`body > .${_portalContainer.portalClass}`)) {
    return document.querySelectorAll(`body > :not(.${_portalContainer.portalClass})`);
  }
  // For non-portal modal implementations, aria-hidden won't be managed, as we can't reasonably
  // predict the markup structure to correctly apply the attribute. It can be done, but not
  // reasonably.
  return [];
};

// Set or unset portal siblings from being aria-hidden.
// NB: If a direct child of the body has its own aria-hidden values, these will be overridden.
const setSiblingsAriaHidden = toHide => {
  [...getModalSiblings()].forEach(node => node.setAttribute('aria-hidden', toHide));
};
const registerModal = newModal => {
  if (!openedModals.length) {
    // First modal displayed triggers changes to the main page.
    setSiblingsAriaHidden(true);
  } else {
    // Set the most recent modal's state, before adding a new one.
    getTopModal().setState({
      isTopModal: false
    });
  }
  // There are multiple possible layers of scroll locking, so let the existing helper keep track.
  (0, _lockScroll.lockScroll)();
  // Add the new modal on top.
  openedModals.push(newModal);
  newModal.setState({
    isTopModal: true
  });
};
exports.registerModal = registerModal;
const deRegisterTopModal = () => {
  // Remove the topmost modal and adjust its state.
  const removedModal = openedModals.pop();
  removedModal.setState({
    isTopModal: false
  });
  if (!openedModals.length) {
    // If it was the last modal, reset the main page.
    setSiblingsAriaHidden(false);
  } else {
    // Otherwise, set the next modal's state.
    getTopModal().setState({
      isTopModal: true
    });
  }
  // There are multiple possible layers of scroll locking, so let the existing helper keep track.
  (0, _lockScroll.unlockScroll)();
  // Closing the modal always returns the user to the prior focus context.
  if (
  // Many guards, particularly because IE is a little weird about activeElement.
  removedModal.priorFocusedEl && removedModal.priorFocusedEl.focus && typeof removedModal.priorFocusedEl.focus === 'function') {
    removedModal.priorFocusedEl.focus();
  }
};
exports.deRegisterTopModal = deRegisterTopModal;
//# sourceMappingURL=modalManager.js.map
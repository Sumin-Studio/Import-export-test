"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.widthClasses = exports.widthBaseClass = exports.userBreakpoints = exports.handleBreakpoint = exports.getWidthClassesFromWidth = exports.getWidthClassesFromState = exports.default = void 0;
var _xuiClassNamespace = require("./xuiClassNamespace");
const breakpoints = {
  xsmall: 400,
  small: 600,
  // $xui-breakpoint-small
  medium: 800,
  // $xui-breakpoint-medium
  large: 1000,
  // $xui-breakpoint-large
  xlarge: 1200,
  // $xui-breakpoint-xlarge
  '2xlarge': 1600 // $xui-breakpoint-xlarge
};
const widthBaseClass = exports.widthBaseClass = `${_xuiClassNamespace.ns}-width`;
const widthClasses = exports.widthClasses = {
  xsmall: `${widthBaseClass}-xsmall-up`,
  small: `${widthBaseClass}-small-up`,
  medium: `${widthBaseClass}-medium-up`,
  large: `${widthBaseClass}-large-up`,
  xlarge: `${widthBaseClass}-xlarge-up`,
  '2xlarge': `${widthBaseClass}-2xlarge-up`
};
const userBreakpoints = exports.userBreakpoints = {
  small: breakpoints.small,
  medium: breakpoints.medium,
  large: breakpoints.large,
  xlarge: breakpoints.xlarge
};
const handleBreakpoint = (width, breakpoint, customBreakpoints) => {
  const breakpointToUse = customBreakpoints != null ? customBreakpoints : breakpoints;
  return width >= breakpointToUse[breakpoint];
};
exports.handleBreakpoint = handleBreakpoint;
const getWidthClassesFromState = stateObj => {
  if (!stateObj) return [];
  return Object.keys(widthClasses).map(width => stateObj[width] && widthClasses[width]);
};
exports.getWidthClassesFromState = getWidthClassesFromState;
const getWidthClassesFromWidth = width => {
  if (!width) return [];
  const widthStateObj = Object.keys(breakpoints).reduce((accumulator, breakpoint) => ({
    ...accumulator,
    [breakpoint]: handleBreakpoint(width, breakpoint)
  }), {});
  return getWidthClassesFromState(widthStateObj);
};
exports.getWidthClassesFromWidth = getWidthClassesFromWidth;
var _default = exports.default = breakpoints;
//# sourceMappingURL=breakpoints.js.map
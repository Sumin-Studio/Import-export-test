"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = getFocusableElement;
var _getFocusableDescendants = _interopRequireWildcard(require("../../getFocusableDescendants"));
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
/**
 * Ponyfill for
 * [Element.prototype.matches](https://developer.mozilla.org/en-US/docs/Web/API/Element/matches)
 */
function elementMatchesSelector(element, selector) {
  if (element.msMatchesSelector) {
    return element.msMatchesSelector(selector);
  }
  if (element.webkitMatchesSelector) {
    return element.webkitMatchesSelector(selector);
  }
  return element.matches(selector);
}

/**
 * Gets the focusable part of an `HTMLElement`.
 *
 * @param {HTMLElement | null} element The element to search through. This can be focusable or have
 * focusable children.
 *
 * @returns {HTMLElement | null} The provided element if it is focusable, otherwise the first
 * focusable child of the provided element, or null if the element is not focusable and has no
 * focusable children.
 */
function getFocusableElement(element) {
  if (!element) {
    return null;
  }
  if (elementMatchesSelector(element, _getFocusableDescendants.focusableDescendantsSelector)) {
    return element;
  }
  const focusableDescendants = (0, _getFocusableDescendants.default)(element);
  if (focusableDescendants.length === 0) {
    return null;
  }
  return focusableDescendants[0];
}
//# sourceMappingURL=getFocusableElement.js.map
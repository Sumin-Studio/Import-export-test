"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
const combineRefs = (...refs) => element => {
  refs.forEach(ref => {
    if (!ref) {
      return;
    }
    if (typeof ref === 'function') {
      ref(element);
    }
    if ('current' in ref) {
      // eslint-disable-next-line no-param-reassign
      ref.current = element;
    }
  });
};
var _default = exports.default = combineRefs;
//# sourceMappingURL=combineRefs.js.map
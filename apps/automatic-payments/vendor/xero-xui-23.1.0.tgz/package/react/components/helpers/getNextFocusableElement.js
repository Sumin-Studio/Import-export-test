"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getNextFocusableElement = exports.default = void 0;
var _getFocusableDescendants = _interopRequireDefault(require("./getFocusableDescendants"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
/**
 * Finds the next focusable element after `element` in the DOM.
 *
 * *Note: This function treats positive tab-indexes as if they were 0.*
 *
 * @param {HTMLElement} element The element to use as a reference point.
 *
 * @returns {HTMLElement | undefined} The next focusable element. If `element` is the last
 * focusable element then the first focusable element on the page will be returned.
 */
const getNextFocusableElement = (element, filterPredicate = () => true) => {
  const allFocusableElements = Array.from((0, _getFocusableDescendants.default)(document.body)).filter(elementToFilter => elementToFilter === element || filterPredicate(elementToFilter));
  const indexOfElement = allFocusableElements.indexOf(element);
  if (indexOfElement === allFocusableElements.length - 1) {
    return allFocusableElements[0];
  }
  return allFocusableElements[indexOfElement + 1];
};
exports.getNextFocusableElement = getNextFocusableElement;
var _default = exports.default = getNextFocusableElement;
//# sourceMappingURL=getNextFocusableElement.js.map
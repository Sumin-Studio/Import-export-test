/**
 * Finds the previous focusable element before `element` in the DOM.
 *
 * *Note: This function treats positive tab-indexes as if they were 0.*
 *
 * @param {HTMLElement} element The element to use as a reference point.
 *
 * @returns {HTMLElement | undefined} The previous focusable element. If `element` is the first
 * focusable element then the last focusable element on the page will be returned.
 */
export declare const getPreviousFocusableElement: (element: HTMLElement) => HTMLElement | undefined;
export default getPreviousFocusableElement;

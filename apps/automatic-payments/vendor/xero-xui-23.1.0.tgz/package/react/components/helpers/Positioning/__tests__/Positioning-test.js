import { render } from '@testing-library/react';
import React from 'react';

import Positioning from '../Positioning';

describe('<Positioning />', () => {
  it('renders without crashing', () => {
    // Arrange
    const triggerRef = React.createRef();
    const { baseElement } = render(
      <Positioning triggerRef={triggerRef}>{side => <div>{side}</div>}</Positioning>,
    );

    // Assert
    expect(baseElement).toMatchSnapshot();
  });
});

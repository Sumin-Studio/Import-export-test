import { act, render, renderHook, screen } from '@testing-library/react';

import { AriaLive, useLiveRegion } from '../useLiveRegion';

describe('useLiveRegion', () => {
  const message = 'Test';

  test.each([
    ['1', undefined, 'polite'],
    ['2', true, 'assertive'],
    ['3', false, 'off'],
  ])(
    `live region is rendered with correct attributes, class %s, aria-atomic %s, aria-live %s`,
    (componentName, ariaAtomic, ariaLive) => {
      // Arrange
      const { result } = renderHook(() =>
        useLiveRegion(componentName, ariaAtomic, ariaLive as AriaLive),
      );
      const [, setLiveRegionText] = result.current as [any, (text: string) => void];

      // Act
      act(() => {
        setLiveRegionText(message);
      });

      const [liveRegion] = result.current as [React.JSX.Element];
      render(liveRegion);

      // Assert
      const messageElement = screen.getByText(message);
      expect(messageElement).toHaveAttribute('class', `xui-${componentName}-live-region`);
      expect(messageElement).toHaveAttribute('aria-atomic', ariaAtomic?.toString());
      expect(messageElement).toHaveAttribute('aria-live', ariaLive);
    },
  );

  test('live region text is set', () => {
    // Arrange
    jest.useFakeTimers();
    const { result } = renderHook(() => useLiveRegion('foo'));
    const [, setLiveRegionText] = result.current as [any, (text: string) => void];

    // Act
    act(() => {
      setLiveRegionText(message);
    });

    const [liveRegion] = result.current as [React.JSX.Element];
    render(liveRegion);

    // Assert
    expect(screen.getByText(message)).toBeDefined();
  });

  test('live region text is removed after timeout', () => {
    // Arrange
    jest.useFakeTimers();
    const { result } = renderHook(() => useLiveRegion('foo'));
    const [, setLiveRegionText] = result.current as [any, (text: string) => void];

    // Act
    act(() => {
      setLiveRegionText(message);
      jest.runAllTimers();
    });

    // Assert
    const [liveRegion] = result.current as [React.JSX.Element];
    render(liveRegion);

    expect(screen.queryByText(message)).toBeNull();
  });
});

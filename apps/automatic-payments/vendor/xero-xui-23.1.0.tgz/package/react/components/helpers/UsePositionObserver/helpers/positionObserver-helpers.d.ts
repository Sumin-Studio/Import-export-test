import { TargetElement } from './helpers';
export declare class PositionObserver {
    listenersAttached: boolean;
    observerAttached: boolean;
    targetElements: Array<TargetElement>;
    listenerCallback: () => void;
    resizeListenerCallback: () => void;
    mutationCallback: () => void;
    constructor();
    observeElement(element: HTMLElement, callback: (clientRect: DOMRect) => void): void;
    unobserveElement(element: HTMLElement): void;
}

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.checkReactVersion = checkReactVersion;
var _react = _interopRequireDefault(require("react"));
var _versions = _interopRequireDefault(require("./versions"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// global process

// This is only exported so it can be tested
function checkReactVersion(actualVersion, requiredVersion, logError) {
  const reactVersionSegments = requiredVersion.split('.');
  if (typeof _react.default.version === 'string' && reactVersionSegments[0].indexOf('^') === 0) {
    const supportedReactMajorVersion = parseInt(reactVersionSegments[0].substring(1), 10);
    const minimumSupportedReactMinorVersion = parseInt(reactVersionSegments[1], 10);
    const minimumSupportedReactPatchVersion = parseInt(reactVersionSegments[2], 10);
    const actualReactVersionSegments = actualVersion.split('.');
    const actualReactMajorVersion = parseInt(actualReactVersionSegments[0], 10);
    const actualReactMinorVersion = parseInt(actualReactVersionSegments[1], 10);
    const actualReactPatchVersion = parseInt(actualReactVersionSegments[2], 10);
    if (actualReactMajorVersion < supportedReactMajorVersion || actualReactMinorVersion < minimumSupportedReactMinorVersion || actualReactMinorVersion === minimumSupportedReactMinorVersion && actualReactPatchVersion < minimumSupportedReactPatchVersion) {
      logError(`XUI error: The version of React used (${actualVersion}) is incompatible with this version of XUI which requires ${requiredVersion}`);
    }
  }
}
if (process.env.NODE_ENV === 'development') {
  // eslint-disable-next-line no-console
  const logWarning = message => console.warn(message);
  // eslint-disable-next-line no-console
  const logError = message => console.error(message);
  const checkXUI = () => {
    const stylesheets = [...document.styleSheets];
    let foundXUI = false;
    stylesheets.forEach(({
      href
    }) => {
      if (href == null || href.indexOf('xui') === -1) {
        return;
      }
      const xuiRegex = /^(https?:)?\/\/edge\.xero\.com\/style\/xui\/([^/]*)\/xui(\.min)?\.css$/;
      const results = xuiRegex.exec(href);
      if (!results) {
        return;
      }
      const [, protocol, linkVersion] = results;
      if (protocol === 'http:') {
        logWarning("XUI warning: The XUI CSS is not being served via HTTPS. Please check the XUI <link> tag's protocol");
      }
      if (linkVersion !== _versions.default.xui) {
        logWarning(`XUI warning: The XUI CSS version (${linkVersion}) is different to that of the components your JS is consuming (${_versions.default.xui}). Please check the version used in the <link> tag on this page.`);
      }
      if (foundXUI) {
        logWarning('XUI warning: This page contains multiple XUI CSS files. Please ensure there is only one version of XUI on the page.');
      }
      foundXUI = true;
    });
    checkReactVersion(_react.default.version, _versions.default.react, logError);
  };
  if (typeof document !== 'undefined') {
    if (document.readyState === 'complete') {
      checkXUI();
    } else {
      const onLoad = () => {
        window.removeEventListener('load', onLoad);
        checkXUI();
      };
      window.addEventListener('load', onLoad);
    }
  }
}
//# sourceMappingURL=versionCheck.js.map
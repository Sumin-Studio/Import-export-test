"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var React = _interopRequireWildcard(require("react"));
var _getTriggerElementRef = _interopRequireDefault(require("../getTriggerElementRef"));
var _usePositionObserverHelpers = require("./helpers/usePositionObserver-helpers");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
/**
 * A `useEffect` function for creating a `PositionObserver` to monitor changes in position of a given element.
 * @param {Object} elementRef The ref for the HTML element to be observed.
 * @param {function} callback An optional callback function to be executed each time there is a change in position
 */
const usePositionObserver = (elementRef, callback) => {
  const [clientRect, setClientRect] = React.useState();
  React.useEffect(() => {
    const element = (0, _getTriggerElementRef.default)(elementRef).current;
    if (element) {
      const currentClientRect = element.getBoundingClientRect();
      (0, _usePositionObserverHelpers.observeElement)(element, currentClientRect, rect => {
        setClientRect(rect);
        callback === null || callback === void 0 || callback(rect);
      });
    }
    return () => {
      if (element) {
        (0, _usePositionObserverHelpers.unobserveElement)(element);
      }
    };
  }, [elementRef, callback]);
  return clientRect;
};
var _default = exports.default = usePositionObserver;
//# sourceMappingURL=usePositionObserver.js.map
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import React from 'react';

import PortalFocusHelper from '../PortalFocusHelper';

describe('<PortalFocusHelper />', () => {
  test('renders without crashing', () => {
    // Arrange
    const focusPortalRef = React.createRef();
    const { container } = render(<PortalFocusHelper focusPortalRef={focusPortalRef} />);

    // Assert
    expect(container).toMatchSnapshot();
  });

  describe('focus elements', () => {
    test('sends the focus to the first element on the page if the focus comes from the end of the page', async () => {
      // Setup
      document.body.innerHTML = '<div></div>';

      // Arrange
      const focusPortalRef = React.createRef();
      render(
        <>
          <button type="button">First</button>
          <button ref={focusPortalRef} type="button">
            Trigger
          </button>
          <button type="button">Last</button>
          <PortalFocusHelper focusPortalRef={focusPortalRef} />
        </>,
        // eslint-disable-next-line testing-library/no-node-access
        { attachTo: document.body.querySelector('div') },
      );

      // Act
      await userEvent.click(screen.getByText('Last'));
      await userEvent.tab();

      // Assert
      expect(screen.getByText('First')).toHaveFocus();

      // Cleanup
      document.body.innerHTML = '';
    });

    test('returns the focus to the page when shift+tabbing out of the popover', async () => {
      // Setup
      document.body.innerHTML = '<div></div>';

      // Arrange
      const focusPortalRef = React.createRef();
      render(
        <>
          <button type="button">First</button>
          <button ref={focusPortalRef} type="button">
            Trigger
          </button>
          <button type="button">Last</button>
          <PortalFocusHelper focusPortalRef={focusPortalRef}>
            <button type="button">Portalled</button>
          </PortalFocusHelper>
        </>,
        // eslint-disable-next-line testing-library/no-node-access
        { attachTo: document.body.querySelector('div') },
      );

      // Act
      await userEvent.click(screen.getByText('Portalled'));
      await userEvent.tab({ shift: true });

      // Assert
      expect(screen.getByText('Trigger')).toHaveFocus();

      // Cleanup
      document.body.innerHTML = '';
    });

    test('returns the focus to the page when tabbing out of the popover', async () => {
      // Setup
      document.body.innerHTML = '<div></div>';

      // Arrange
      const focusPortalRef = React.createRef();
      render(
        <>
          <button type="button">First</button>
          <button ref={focusPortalRef} type="button">
            Trigger
          </button>
          <button type="button">Last</button>
          <PortalFocusHelper focusPortalRef={focusPortalRef}>
            <button type="button">Portalled</button>
          </PortalFocusHelper>
        </>,
        // eslint-disable-next-line testing-library/no-node-access
        { attachTo: document.body.querySelector('div') },
      );

      // Act
      await userEvent.click(screen.getByText('Portalled'));
      await userEvent.tab();

      // Assert
      expect(screen.getByText('Last')).toHaveFocus();

      // Cleanup
      document.body.innerHTML = '';
    });
  });

  describe('event listeners on focusPortal', () => {
    test('pressing tab focuses on the portal if possible', () => {
      // Arrange
      const eventListeners = {};
      document.addEventListener = jest.fn((event, cb) => {
        eventListeners[event] = cb;
      });
      const expectedAutomationId = 'expected-element';
      const focusPortalRef = React.createRef();
      const onReturnFocus = jest.fn();
      render(
        <>
          <button ref={focusPortalRef} type="button">
            Trigger
          </button>
          <PortalFocusHelper focusPortalRef={focusPortalRef} onReturnFocus={onReturnFocus}>
            <input data-automationid={expectedAutomationId} />
          </PortalFocusHelper>
        </>,
      );

      // Act
      eventListeners.keydown({
        key: 'Tab',
        preventDefault: () => {},
        target: focusPortalRef.current,
      });

      // Assert
      // eslint-disable-next-line testing-library/no-node-access
      expect(document.activeElement).toBe(screen.getByTestId(expectedAutomationId));
    });

    test('pressing tab calls onReturnFocus() if there is nothing in the portal that is focusable', () => {
      // Arrange
      const eventListeners = {};
      document.addEventListener = jest.fn((event, cb) => {
        eventListeners[event] = cb;
      });
      const focusPortal = document.createElement('button');
      const focusPortalRef = { current: focusPortal };
      const onReturnFocus = jest.fn();
      render(<PortalFocusHelper focusPortalRef={focusPortalRef} onReturnFocus={onReturnFocus} />);

      // Act
      eventListeners.keydown({ key: 'Tab', target: focusPortal });

      // Assert
      expect(onReturnFocus).toHaveBeenCalled();
    });

    test('pressing shift+tab calls onReturnFocus()', () => {
      // Arrange
      const eventListeners = {};
      document.addEventListener = jest.fn((event, cb) => {
        eventListeners[event] = cb;
      });
      const focusPortal = document.createElement('button');
      const focusPortalRef = { current: focusPortal };
      const onReturnFocus = jest.fn();
      render(<PortalFocusHelper focusPortalRef={focusPortalRef} onReturnFocus={onReturnFocus} />);

      // Act
      eventListeners.keydown({
        key: 'Tab',
        shiftKey: true,
        target: focusPortal,
      });

      // Assert
      expect(onReturnFocus).toHaveBeenCalled();
    });
  });

  describe('event listeners on the element after focusPortal', () => {
    test('pressing shift+tab focuses on the portal if possible', () => {
      // Arrange
      const eventListeners = {};
      document.addEventListener = jest.fn((event, cb) => {
        eventListeners[event] = cb;
      });

      const expectedAutomationId = 'expected-element';
      const focusPortalRef = React.createRef();
      const onReturnFocus = jest.fn();
      const nextElementAutomationId = 'next-focusable-element';

      render(
        <>
          <button ref={focusPortalRef} type="button">
            Trigger
          </button>
          <button data-automationid={nextElementAutomationId} type="button">
            Element after trigger
          </button>
          <PortalFocusHelper focusPortalRef={focusPortalRef} onReturnFocus={onReturnFocus}>
            <input data-automationid={expectedAutomationId} />
          </PortalFocusHelper>
        </>,
      );

      // Act
      eventListeners.keydown({
        key: 'Tab',
        preventDefault: () => {},
        shiftKey: true,
        target: screen.getByTestId(nextElementAutomationId),
      });

      // Assert
      // eslint-disable-next-line testing-library/no-node-access
      expect(document.activeElement).toEqual(screen.getByTestId(expectedAutomationId));
    });
  });
});

import { getWidthClassesFromState } from './breakpoints';
import { Component } from './resizeObserver';
export declare const observe: (component: Component) => void;
export declare const unobserve: (component: Component) => void;
export { getWidthClassesFromState };

export declare const observeElement: (element: HTMLElement, previousClientRect: DOMRect, callback: (rect: DOMRect) => void) => void;
export declare const unobserveElement: (element: HTMLElement) => void;

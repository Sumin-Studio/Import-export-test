/**
 * Finds the next focusable element after `element` in the DOM.
 *
 * *Note: This function treats positive tab-indexes as if they were 0.*
 *
 * @param {HTMLElement} element The element to use as a reference point.
 *
 * @returns {HTMLElement | undefined} The next focusable element. If `element` is the last
 * focusable element then the first focusable element on the page will be returned.
 */
export declare const getNextFocusableElement: (element: HTMLElement, filterPredicate?: (elementToFilter: HTMLElement) => boolean) => HTMLElement | undefined;
export default getNextFocusableElement;

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = filterNonEmptyStrings;
function filterNonEmptyStrings(strings) {
  return strings.filter(string => typeof string === 'string' && string.length > 0);
}
//# sourceMappingURL=filterNonEmptyStrings.js.map
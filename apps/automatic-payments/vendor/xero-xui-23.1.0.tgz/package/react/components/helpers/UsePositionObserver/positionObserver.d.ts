import * as React from 'react';
import { XUIComponent } from '../../../models/XUIComponent';
export declare const observe: (elementRef: React.MutableRefObject<XUIComponent>, callback: (clientRect: DOMRect) => void) => void;
export declare const unobserve: (elementRef: React.MutableRefObject<XUIComponent>) => void;

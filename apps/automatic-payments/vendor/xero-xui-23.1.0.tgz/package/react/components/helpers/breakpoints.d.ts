export type Breakpoints = {
    [key: string]: number;
};
declare const breakpoints: Breakpoints;
export declare const widthBaseClass: string;
export declare const widthClasses: {
    [key: string]: string;
};
export declare const userBreakpoints: {
    small: number;
    medium: number;
    large: number;
    xlarge: number;
};
export declare const handleBreakpoint: (width: number, breakpoint: string, customBreakpoints?: Breakpoints) => boolean;
export declare const getWidthClassesFromState: (stateObj: {
    [key: string]: boolean;
}) => (string | false)[];
export declare const getWidthClassesFromWidth: (width?: number) => (string | false)[];
export default breakpoints;

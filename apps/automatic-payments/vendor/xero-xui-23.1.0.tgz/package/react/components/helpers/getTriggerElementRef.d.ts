import { RefObject } from 'react';
import { XUIComponent } from '../../models/XUIComponent';
type TriggerRef = XUIComponent | RefObject<XUIComponent>;
declare const getTriggerElementRef: (triggerRef: TriggerRef) => {
    _triggerRef: TriggerRef;
    readonly current: HTMLElement | null;
};
export default getTriggerElementRef;

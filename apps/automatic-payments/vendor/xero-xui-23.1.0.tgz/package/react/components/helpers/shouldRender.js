"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = shouldRender;
// When element is undefined or null or empty string, it shouldn't be rendered.
function shouldRender(element) {
  return element != null && element !== '';
}
//# sourceMappingURL=shouldRender.js.map
import * as React from 'react';
/**
 * `useResizeObserver` will observe an `HTMLElement` with a `ResizeObserver` and provide a
 * `contentRect` detailing the size of the element.
 *
 * Start by attaching the provided `observedElementRef` to an `HTMLElement`.
 *
 * To re-render a component on resize you can use the properties of the provided `contentRect` as
 * the dependencies of a `React.useLayoutEffect`.
 */
export default function useResizeObserver<T extends HTMLElement = HTMLElement>(): {
    observedElementRef: React.RefObject<T>;
    contentRect: Partial<DOMRectReadOnly>;
};

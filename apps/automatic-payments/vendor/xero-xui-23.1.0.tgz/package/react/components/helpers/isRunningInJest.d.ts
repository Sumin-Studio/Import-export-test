export default function isRunningInJest(): boolean;

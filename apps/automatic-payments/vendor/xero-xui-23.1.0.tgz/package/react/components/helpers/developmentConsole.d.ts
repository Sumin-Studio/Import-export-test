import flagDefinitions from '../../helpers/flagDefinitions';
type FlagType = keyof typeof flagDefinitions;
export declare const logWarning: ({ componentName, flagType, message, }: {
    componentName: string;
    flagType?: FlagType;
    message: string;
}) => void;
export declare const logError: ({ componentName, flagType, message, }: {
    componentName: string;
    flagType?: FlagType;
    message: string;
}) => void;
export {};

/**
 * Test to see if the body scroll is currently locked
 *
 * @export
 */
export declare const isScrollLocked: () => boolean;
/**
 * Will set the scroll on the browser to be locked and visibly hidden so the content
 * underneath cannot be scrolled. Returns a boolean indicating whether this function
 * call was responsible for locking the scroll.
 *
 * @export
 */
export declare const lockScroll: () => boolean;
/**
 * Will reset the body to have postition: static and overflow: auto instead of hidden.
 *
 * @export
 */
export declare const unlockScroll: () => void;

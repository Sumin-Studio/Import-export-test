"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ns = void 0;
exports.setXUIClassNamespace = setXUIClassNamespace;
// Intentionally using let since we want the ns to be overridable
let ns = exports.ns = 'xui'; // eslint-disable-line

/**
 * Sets the CSS class namespace (prefix) that should be used
 * by components. Use this if you have set the $ns variable in SCSS to
 * something other than `xui`. This should be set BEFORE any components
 * have been imported.
 * @param {String} name
 */
function setXUIClassNamespace(name) {
  if (typeof name !== 'string' || name.trim() === '') {
    throw new Error('XUI error: argument provided to setXUIClassNamespace must be a non-empty string');
  } else {
    exports.ns = ns = name;
  }
}
//# sourceMappingURL=xuiClassNamespace.js.map
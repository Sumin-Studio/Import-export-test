import * as React from 'react';
/**
 * A `useEffect` function for creating a `MutationObserver` to monitor changes in a given element.
 * @param {React.RefObject<HTMLElement>} ref The React `ref` for the element to be observed.
 * @param {MutationCallback} callback The callback function to be passed to the `MutationObserver`
 * @param {MutationObserverInit} options The options object to be passed to the `observe` method. Defaults are: {attributes: false, characterData: false, childList: true, subtree: false}
 */
declare const useMutationObserver: (ref: React.MutableRefObject<HTMLElement | null>, callback: MutationCallback, options?: MutationObserverInit) => void;
export default useMutationObserver;

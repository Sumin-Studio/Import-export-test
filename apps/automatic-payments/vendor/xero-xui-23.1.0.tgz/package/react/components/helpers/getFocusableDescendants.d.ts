export declare const focusableElements: string[];
export declare const focusableDescendantsSelector: string;
export default function getFocusableDescendants(element: HTMLElement): NodeListOf<HTMLElement>;

import { render, screen } from '@testing-library/react';
import React from 'react';

import NOOP from '../../../noop';
import {
  addListeners,
  componentHasChangedPosition,
  removeListeners,
  updateTargetPositions,
} from '../helpers';

const mockOldRect = { left: 0, top: 0, width: 10, height: 10 } as DOMRect;
const mockNewRect = { left: 10, top: 10, width: 10, height: 10 } as DOMRect;

const mockCallback = jest.fn();

const mockListenerCallback = () => NOOP;

describe('componentHasChangedPosition', () => {
  test('returns true if the component has changed position', () => {
    // Assert
    expect(componentHasChangedPosition(mockOldRect, mockNewRect)).toBeTruthy();
  });

  test('returns false if the component has not changed position', () => {
    // Assert
    expect(componentHasChangedPosition(mockOldRect, mockOldRect)).toBeFalsy();
  });
});

describe('updateTargetPositions', () => {
  const createTestDOM = () => (
    <>
      <div id="test-one" data-automationid="test-one" />
      <div id="test-two" data-automationid="test-two" />
    </>
  );

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('always calls callback and updates all targets if updateAll is true', () => {
    render(createTestDOM());

    const observedElOne = {
      element: screen.getByTestId('test-one'),
      previousClientRect: mockOldRect,
      callback: mockCallback,
    };
    const observedElTwo = {
      element: screen.getByTestId('test-two'),
      previousClientRect: mockOldRect,
      callback: mockCallback,
    };

    jest
      .spyOn(observedElOne.element, 'getBoundingClientRect')
      .mockImplementation(() => mockNewRect);

    jest
      .spyOn(observedElTwo.element, 'getBoundingClientRect')
      .mockImplementation(() => mockNewRect);

    const updatedElements = updateTargetPositions([observedElOne, observedElTwo], true);

    expect(mockCallback).toHaveBeenCalledTimes(2);

    updatedElements.forEach(updatedElement => {
      expect(updatedElement.previousClientRect).toEqual(mockNewRect);
    });
  });

  test('does not call callback if element positions have not changed', () => {
    render(createTestDOM());

    const observedElOne = {
      element: screen.getByTestId('test-one'),
      previousClientRect: mockOldRect,
      callback: mockCallback,
    };

    jest
      .spyOn(observedElOne.element, 'getBoundingClientRect')
      .mockImplementation(() => mockOldRect);

    updateTargetPositions([observedElOne]);

    expect(mockCallback).not.toHaveBeenCalled();
  });
});

describe('addListeners', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('adds listeners', () => {
    const documentSpy = jest.spyOn(document, 'addEventListener');
    const windowSpy = jest.spyOn(window, 'addEventListener');

    addListeners(mockListenerCallback, mockListenerCallback);

    expect(documentSpy).toHaveBeenCalledTimes(3);
    expect(windowSpy).toHaveBeenCalledTimes(2);
  });
});

describe('removeListeners', () => {
  test('removes listeners', () => {
    const documentSpy = jest.spyOn(document, 'removeEventListener');
    const windowSpy = jest.spyOn(window, 'removeEventListener');

    removeListeners(mockListenerCallback, mockListenerCallback);

    expect(documentSpy).toHaveBeenCalledTimes(5);
    expect(windowSpy).toHaveBeenCalledTimes(2);
  });
});

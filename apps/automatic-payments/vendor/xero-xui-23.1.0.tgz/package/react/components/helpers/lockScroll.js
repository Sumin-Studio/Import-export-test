"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.unlockScroll = exports.lockScroll = exports.isScrollLocked = void 0;
var _scrollbarWidth = _interopRequireDefault(require("scrollbar-width"));
var _getComputedStyle = _interopRequireDefault(require("./getComputedStyle"));
var _xuiClassNamespace = require("./xuiClassNamespace");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
let scrollState = null;
let scrollLockCount = 0;
const lockScrollClassName = `${_xuiClassNamespace.ns}-lockscroll`;

/**
 * Test to see if the body scroll is currently locked
 *
 * @export
 */
const isScrollLocked = () => document.documentElement.classList.contains(lockScrollClassName);

/**
 * Will set the scroll on the browser to be locked and visibly hidden so the content
 * underneath cannot be scrolled. Returns a boolean indicating whether this function
 * call was responsible for locking the scroll.
 *
 * @export
 */
exports.isScrollLocked = isScrollLocked;
const lockScroll = () => {
  scrollLockCount += 1;
  if (!isScrollLocked()) {
    const {
      body
    } = document;
    const html = document.documentElement;
    const existingPadding = parseInt((0, _getComputedStyle.default)(body, 'paddingRight'), 10);
    const scrollbarSize = (0, _scrollbarWidth.default)();
    const newPadding = typeof existingPadding === 'number' && Number.isNaN(existingPadding) || !Number.isFinite(existingPadding) ? scrollbarSize : (scrollbarSize !== null && scrollbarSize !== void 0 ? scrollbarSize : 0) + existingPadding;

    // FF scrolls the HTML element.  Chrome scrolls the body.  Handle either.
    const scrollElement = body.scrollTop > 0 || html.scrollTop === 0 ? body : html;
    scrollState = {
      top: scrollElement.scrollTop,
      left: scrollElement.scrollLeft
    };
    html.classList.add(lockScrollClassName);
    body.style.paddingRight = `${newPadding}px`;
    return true;
  }
  return false;
};

/**
 * Will reset the body to have postition: static and overflow: auto instead of hidden.
 *
 * @export
 */
exports.lockScroll = lockScroll;
const unlockScroll = () => {
  if (scrollLockCount <= 1 && isScrollLocked()) {
    const {
      body,
      documentElement: html
    } = document;
    body.style.paddingRight = '';
    html.classList.remove(lockScrollClassName);

    /*
    iOS still scrolls behind, so make sure the scroll position gets reset back to
    what it was when we locked scrolling.
    @author dev-johnsanders
    */
    if (scrollState) {
      window.scrollTo(scrollState.left, scrollState.top);
    }
  }
  if (scrollLockCount) {
    scrollLockCount -= 1;
  }
};
exports.unlockScroll = unlockScroll;
//# sourceMappingURL=lockScroll.js.map
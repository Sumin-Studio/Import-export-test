import * as React from 'react';
/**
 * @public
 * Build the control, label, and message ids from user-provided id(s), or from scratch
 * This should first be triggered by initialising the control component. The output is
 * then passed to getAriaAttributes.
 * @param {{labelId: string, id: string}} - Optional, consumer-provided string or strings to use as IDs
 * @returns {{label: string, message: string, control: string}}
 */
export default function generateIds({ labelId, id }?: {
    id?: string;
    labelId?: string;
}): {
    label: string;
    control: string;
    message: string;
};
export declare function getHintOrValidationMessageId(hintMessage?: React.ReactNode, isInvalid?: boolean, messageId?: string, validationMessage?: React.ReactNode): string | undefined;
/**
 * @public
 * Get the collection of aria attributes to be applied to the control.
 * Independent of the component, for timing purposes.
 * @param {Object} ids - generated ids from ./helpers, including label and message ids
 * @param {Object} props - props of the parent control component
 * @returns {{aria-invalid: boolean, aria-label: string, aria-labelledby: string, aria-describedby: string}}
 */
export declare const getAriaAttributesInline: (ids: ReturnType<typeof generateIds>, props: {
    children?: React.ReactNode;
    hintMessage?: React.ReactNode;
    isInvalid?: boolean;
    labelId?: string;
    validationMessage?: React.ReactNode;
}) => {
    'aria-invalid': boolean | undefined;
    'aria-labelledby': string | undefined;
    'aria-describedby': string | undefined;
};
/**
 * @public
 * Get the collection of aria attributes to be applied to the control.
 * Independent of the component, for timing purposes.
 * @param {Object} ids - generated ids from ./helpers, including label and message ids
 * @param {Object} props - props of the parent control component
 * @param {Boolean} isGroup - Whether or not this label is for a group of controls
 * @returns {{aria-invalid: boolean, aria-label: string, aria-labelledby: string, aria-describedby: string, id: string}}
 */
export declare const getAriaAttributes: (ids: ReturnType<typeof generateIds>, props: {
    buttonContent?: React.ReactNode;
    children?: React.ReactNode;
    hintMessage?: React.ReactNode;
    isInvalid?: boolean;
    label?: React.ReactNode;
    labelId?: string;
    placeholder?: string;
    validationMessage?: React.ReactNode;
}, groupedSetting?: {
    isGroup?: boolean;
}, isLabelledExternally?: boolean) => {
    'aria-invalid': boolean | undefined;
    'aria-label': string | undefined;
    'aria-labelledby': string | undefined;
    'aria-describedby': string | undefined;
    id: string | undefined;
};

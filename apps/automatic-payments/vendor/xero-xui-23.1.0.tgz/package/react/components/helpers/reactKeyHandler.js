"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.matchOneOfKeys = exports.isKeySpacebar = exports.isKeyShiftTab = exports.isKeyPrintableCharacter = exports.isKeyFunctional = exports.isKeyClick = exports.isKeyArrow = exports.eventKeyValues = void 0;
const eventKeyValues = exports.eventKeyValues = {
  left: 'ArrowLeft',
  right: 'ArrowRight',
  up: 'ArrowUp',
  down: 'ArrowDown',
  space: ' ',
  enter: 'Enter',
  escape: 'Escape',
  tab: 'Tab',
  backspace: 'Backspace',
  shift: 'Shift',
  meta: 'Meta',
  control: 'Control',
  alt: 'Alt',
  pageUp: 'PageUp',
  pageDown: 'PageDown',
  home: 'Home',
  end: 'End'
};
const arrowKeys = [eventKeyValues.left, eventKeyValues.right, eventKeyValues.up, eventKeyValues.down];
const clickKeys = [eventKeyValues.space, eventKeyValues.enter];

/**
 * Based on the React SyntheticEvent's standard properties, determine whether a keyboard event matches any of a set of keys, as described in keyMap.
 *
 * @private
 * @param {SyntheticEvent} event
 * @param {Array} keysToCheck
 * @returns {boolean}
 */
const matchOneOfKeys = (event, keysToCheck) => keysToCheck.indexOf(event.key) > -1;
/**
 * Is the keyboard event triggered by a directional arrow key
 *
 * @export
 * @param {SyntheticEvent} event
 * @returns {boolean}
 */
exports.matchOneOfKeys = matchOneOfKeys;
const isKeyArrow = event => matchOneOfKeys(event, arrowKeys);

/**
 * Is the keyboard event from a spacebar or enter press
 *
 * @export
 * @param {SyntheticEvent} event
 * @returns {boolean}
 */
exports.isKeyArrow = isKeyArrow;
const isKeyClick = event => matchOneOfKeys(event, clickKeys);

/**
 * Is the keyboard event from a spacebar
 *
 * @export
 * @param {SyntheticEvent} event
 * @returns {boolean}
 */
exports.isKeyClick = isKeyClick;
const isKeySpacebar = event => event.key === eventKeyValues.space;

/**
 * Is the keyboard event a press of the Tab with shift held.
 *
 * @export
 * @param {SyntheticEvent} event
 * @returns {boolean}
 */
exports.isKeySpacebar = isKeySpacebar;
const isKeyShiftTab = event => event.key === eventKeyValues.tab && event.shiftKey;

/**
 * Is the keyboard event from a functional key (tab, enter, escape, backspace, shift, control, alt or meta).
 *
 * @export
 * @param {SyntheticEvent} event
 * @returns {boolean}
 */
exports.isKeyShiftTab = isKeyShiftTab;
const isKeyFunctional = event => matchOneOfKeys(event, [eventKeyValues.tab, eventKeyValues.enter, eventKeyValues.escape, eventKeyValues.backspace, eventKeyValues.shift, eventKeyValues.control, eventKeyValues.alt, eventKeyValues.meta]);
exports.isKeyFunctional = isKeyFunctional;
const isKeyPrintableCharacter = event => event.key.length === 1 && !event.altKey && !event.ctrlKey && !event.metaKey;
exports.isKeyPrintableCharacter = isKeyPrintableCharacter;
//# sourceMappingURL=reactKeyHandler.js.map
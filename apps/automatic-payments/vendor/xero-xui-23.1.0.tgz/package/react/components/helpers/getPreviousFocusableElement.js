"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getPreviousFocusableElement = exports.default = void 0;
var _getFocusableDescendants = _interopRequireDefault(require("./getFocusableDescendants"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
/**
 * Finds the previous focusable element before `element` in the DOM.
 *
 * *Note: This function treats positive tab-indexes as if they were 0.*
 *
 * @param {HTMLElement} element The element to use as a reference point.
 *
 * @returns {HTMLElement | undefined} The previous focusable element. If `element` is the first
 * focusable element then the last focusable element on the page will be returned.
 */
const getPreviousFocusableElement = element => {
  const allFocusableElements = Array.from((0, _getFocusableDescendants.default)(document.body));
  const indexOfElement = allFocusableElements.indexOf(element);
  if (indexOfElement === 0) {
    return allFocusableElements[allFocusableElements.length - 1];
  }
  return allFocusableElements[indexOfElement - 1];
};
exports.getPreviousFocusableElement = getPreviousFocusableElement;
var _default = exports.default = getPreviousFocusableElement;
//# sourceMappingURL=getPreviousFocusableElement.js.map
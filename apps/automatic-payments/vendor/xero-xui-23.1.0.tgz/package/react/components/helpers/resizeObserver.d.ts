import * as React from 'react';
import { Prettify } from '../../helpers/helperTypes';
import { Breakpoints } from './breakpoints';
export type Component = Prettify<{
    _area: React.RefObject<HTMLElement>;
    _breakpoints?: Breakpoints;
    _onResize: (contentRect: DOMRectReadOnly) => void;
} & React.Component>;
type SetBreakpoints = (component: Component, width: number) => void;
export declare const observe: (component: Component, setBreakpoints?: SetBreakpoints) => void;
export declare const unobserve: (component: Component) => void;
export {};

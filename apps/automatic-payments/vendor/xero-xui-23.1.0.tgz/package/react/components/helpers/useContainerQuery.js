"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = useContainerQuery;
var _breakpoints = require("./breakpoints");
var _useResizeObserver = _interopRequireDefault(require("./useResizeObserver"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function useContainerQuery(customBreakpoints, useBorderBox) {
  var _observedElementRef$c;
  const {
    observedElementRef,
    contentRect
  } = (0, _useResizeObserver.default)();

  // `contentRect.width` uses the content box which excludes padding and borders.
  // `getBoundingClientRect().width` uses the border box which includes padding and borders.
  const width = useBorderBox ? (_observedElementRef$c = observedElementRef.current) === null || _observedElementRef$c === void 0 ? void 0 : _observedElementRef$c.getBoundingClientRect().width : contentRect.width;
  const isWidthAboveBreakpoint = breakpoint => {
    if (typeof width !== 'number') {
      // In many testing frameworks, a width will not be available.
      // Return `true` in order to default to full-width behaviour.
      return true;
    }
    return (0, _breakpoints.handleBreakpoint)(width, breakpoint, customBreakpoints);
  };
  const getWidthClasses = () => (0, _breakpoints.getWidthClassesFromWidth)(width);
  return {
    getWidthClasses,
    isWidthAboveBreakpoint,
    observedElementRef
  };
}
//# sourceMappingURL=useContainerQuery.js.map
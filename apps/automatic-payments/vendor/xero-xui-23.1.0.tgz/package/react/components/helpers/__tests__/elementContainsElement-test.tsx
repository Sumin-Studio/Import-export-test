import { render, screen } from '@testing-library/react';
import * as React from 'react';

import elementContainsElement from '../elementContainsElement';

test('elementContainsElement returns true if elementToFind is contained by containerElement', () => {
  render(
    <div data-automationid="containerElement">
      <div data-automationid="elementToFind" />
    </div>,
  );

  const containerElement = screen.getByTestId('containerElement');
  const elementToFind = screen.getByTestId('elementToFind');

  expect(elementContainsElement(containerElement, elementToFind)).toBeTruthy();
});

test('elementContainsElement can find nested elements', () => {
  render(
    <div data-automationid="containerElement">
      <div>
        <div data-automationid="elementToFind" />
      </div>
    </div>,
  );

  const containerElement = screen.getByTestId('containerElement');
  const elementToFind = screen.getByTestId('elementToFind');

  expect(elementContainsElement(containerElement, elementToFind)).toBeTruthy();
});

test('elementContainsElement returns false if elementToFind is not contained by containerElement', () => {
  render(
    <div>
      <div data-automationid="containerElement" />
      <div data-automationid="elementToFind" />
    </div>,
  );

  const containerElement = screen.getByTestId('containerElement');
  const elementToFind = screen.getByTestId('elementToFind');

  expect(elementContainsElement(containerElement, elementToFind)).toBeFalsy();
});

test('elementContainsElement works with `aria-owns`', () => {
  render(
    <div>
      <div aria-owns="elementToFind" data-automationid="containerElement" />
      <div data-automationid="elementToFind" id="elementToFind" />
    </div>,
  );

  const containerElement = screen.getByTestId('containerElement');
  const elementToFind = screen.getByTestId('elementToFind');

  expect(elementContainsElement(containerElement, elementToFind)).toBeTruthy();
});

test('elementContainsElement can find elements nested under an element referenced with `aria-owns', () => {
  render(
    <div>
      <div aria-owns="portalledElement" data-automationid="containerElement" />
      <div id="portalledElement">
        <div data-automationid="elementToFind" id="elementToFind" />
      </div>
    </div>,
  );

  const containerElement = screen.getByTestId('containerElement');
  const elementToFind = screen.getByTestId('elementToFind');

  expect(elementContainsElement(containerElement, elementToFind)).toBeTruthy();
});

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useLiveRegion = void 0;
var _react = _interopRequireWildcard(require("react"));
var React = _react;
var _reactPortal = require("react-portal");
var _portalContainer = require("./portalContainer");
var _xuiClassNamespace = require("./xuiClassNamespace");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
const DEFAULT_TIMEOUT_MS = 10000;

/**
 * A hook to provide a portalled `aria-live` region to make an announcement to a screen reader. Default behaviour is as a `status` live region.
 * @param {string} componentName The message to be read by the screen reader.
 * @param {AriaLive} ariaAtomic The `aria-atomic` attribute, `true` by default.
 * @param {AriaLive} ariaLive The `aria-live` attribute, `polite` by default.
 * @param {number} messageTimeout The timeout after which the message is removed, in milliseconds. Default is 10000ms (10s).
 */
const useLiveRegion = (componentName, ariaAtomic = true, ariaLive = 'polite', messageTimeout = DEFAULT_TIMEOUT_MS) => {
  const [message, setMessage] = (0, _react.useState)('');
  const setLiveRegionText = (0, _react.useCallback)(text => {
    if (text == null) setMessage('');
    setMessage(text);
    setTimeout(() => {
      setMessage('');
    }, messageTimeout);
  }, [messageTimeout]);
  const liveRegion = /*#__PURE__*/(0, _jsxRuntime.jsx)(_reactPortal.Portal, {
    node: (0, _portalContainer.statusPortalContainer)(),
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: `${_xuiClassNamespace.ns}-${componentName}-live-region`,
      "aria-atomic": ariaAtomic,
      "aria-live": ariaLive,
      children: message
    })
  });
  return [liveRegion, setLiveRegionText];
};
exports.useLiveRegion = useLiveRegion;
//# sourceMappingURL=useLiveRegion.js.map
/**
 * Method for conditionally warning the user that some prop(s) are required from XUI 19 to be able to provide an aria label to the user
 *
 * @param {string} componentName - Name of the component
 * @param {string[]} conditions - Human readable strings for the conditions that must be met
 * @param {Array<string | boolean>} isLabelProvided - List of conditions that if true mean the label has already been provided
 */
declare const labelRequiredError: (componentName: string, conditions: string[], isLabelProvided: Array<string | boolean>) => void;
declare const textChildOrLabelId: string[];
declare const ariaLabelOnly: string[];
declare const loadingAriaLabelOnly: string[];
export { ariaLabelOnly, labelRequiredError as default, loadingAriaLabelOnly, textChildOrLabelId };

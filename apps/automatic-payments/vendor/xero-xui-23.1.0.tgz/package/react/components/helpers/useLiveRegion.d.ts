import * as React from 'react';
export type AriaLive = 'polite' | 'assertive' | 'off';
/**
 * A hook to provide a portalled `aria-live` region to make an announcement to a screen reader. Default behaviour is as a `status` live region.
 * @param {string} componentName The message to be read by the screen reader.
 * @param {AriaLive} ariaAtomic The `aria-atomic` attribute, `true` by default.
 * @param {AriaLive} ariaLive The `aria-live` attribute, `polite` by default.
 * @param {number} messageTimeout The timeout after which the message is removed, in milliseconds. Default is 10000ms (10s).
 */
export declare const useLiveRegion: (componentName: string, ariaAtomic?: boolean | undefined, ariaLive?: AriaLive, messageTimeout?: number) => [React.ReactElement, (text: string) => void];

import { Breakpoints } from './breakpoints';
export default function useContainerQuery<T extends HTMLElement>(customBreakpoints?: Breakpoints, useBorderBox?: boolean): {
    getWidthClasses: () => (string | false)[];
    isWidthAboveBreakpoint: (breakpoint: string) => boolean;
    observedElementRef: import("react").RefObject<T>;
};

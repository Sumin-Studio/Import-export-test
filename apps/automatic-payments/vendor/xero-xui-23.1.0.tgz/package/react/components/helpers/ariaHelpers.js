"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = generateIds;
exports.getAriaAttributesInline = exports.getAriaAttributes = void 0;
exports.getHintOrValidationMessageId = getHintOrValidationMessageId;
var _nanoid = require("nanoid");
/**
 * @public
 * Build the control, label, and message ids from user-provided id(s), or from scratch
 * This should first be triggered by initialising the control component. The output is
 * then passed to getAriaAttributes.
 * @param {{labelId: string, id: string}} - Optional, consumer-provided string or strings to use as IDs
 * @returns {{label: string, message: string, control: string}}
 */
function generateIds({
  labelId,
  id
} = {}) {
  const wasIdPassed = Boolean(id || labelId);
  // Use the id as the root, if both IDs are passed.
  const rootId = id || labelId || `xui-${(0, _nanoid.nanoid)(10)}`;
  return {
    // If both IDs are passed, we want to return the supplied value for each.
    // If no IDs were passed, label ID defaults to no-suffix.
    label: labelId || !wasIdPassed && rootId || `${rootId}-label`,
    control: id || `${rootId}-control`,
    message: `${rootId}-message`
  };
}
function getHintOrValidationMessageId(hintMessage, isInvalid, messageId, validationMessage) {
  return (hintMessage || validationMessage && isInvalid) && messageId || undefined;
}

/**
 * @public
 * Get the collection of aria attributes to be applied to the control.
 * Independent of the component, for timing purposes.
 * @param {Object} ids - generated ids from ./helpers, including label and message ids
 * @param {Object} props - props of the parent control component
 * @returns {{aria-invalid: boolean, aria-label: string, aria-labelledby: string, aria-describedby: string}}
 */
const getAriaAttributesInline = (ids, props) => {
  const {
    children,
    // This refers to children of the parent control component. Often plain text.
    validationMessage,
    hintMessage,
    labelId,
    isInvalid
  } = props;

  // Create a "labelledby" attribute if there is child content, or if the user has provided an id.
  const ariaLabelledBy = children != null && ids.label || !children && labelId || undefined;

  // Create a "describedby" attribute if there is a hint or validation message to display.
  const ariaDescribedBy = getHintOrValidationMessageId(hintMessage, isInvalid, ids.message, validationMessage);
  return {
    'aria-invalid': isInvalid,
    'aria-labelledby': ariaLabelledBy,
    'aria-describedby': ariaDescribedBy
  };
};

/**
 * @public
 * Get the collection of aria attributes to be applied to the control.
 * Independent of the component, for timing purposes.
 * @param {Object} ids - generated ids from ./helpers, including label and message ids
 * @param {Object} props - props of the parent control component
 * @param {Boolean} isGroup - Whether or not this label is for a group of controls
 * @returns {{aria-invalid: boolean, aria-label: string, aria-labelledby: string, aria-describedby: string, id: string}}
 */
exports.getAriaAttributesInline = getAriaAttributesInline;
const getAriaAttributes = (ids, props, groupedSetting = {}, isLabelledExternally) => {
  const {
    isGroup
  } = groupedSetting;
  const {
    label,
    validationMessage,
    hintMessage,
    labelId,
    isInvalid
  } = props;

  // props.placeholder pulls possible backup label from a textInput.
  // props.buttonContent pulls possible backup label from a selectBox.
  const fallBackLabel = props.placeholder || props.buttonContent && String(props.buttonContent);

  // Create a "labelledby" attribute if there is no label content and the user has
  // provided an id, or if this is a visible label for a group.
  const ariaLabelledBy = !label && labelId || label && isGroup && ids.label || undefined;

  // Add hidden label if specified by the user, and provided content is a string
  // (or fallBackLabel as label if that's all we've got)
  const ariaLabel = !label && !ariaLabelledBy && !isLabelledExternally && fallBackLabel || undefined;

  // Create a "describedby" attribute if there is a hint or validation message to display.
  const ariaDescribedBy = getHintOrValidationMessageId(hintMessage, isInvalid, ids.message, validationMessage);

  // Only provide a control ID if the label will be using htmlFor to target it.
  const controlId = !isGroup && ids.control || undefined;
  return {
    'aria-invalid': isInvalid,
    'aria-label': ariaLabel,
    'aria-labelledby': ariaLabelledBy,
    'aria-describedby': ariaDescribedBy,
    id: controlId
  };
};
exports.getAriaAttributes = getAriaAttributes;
//# sourceMappingURL=ariaHelpers.js.map
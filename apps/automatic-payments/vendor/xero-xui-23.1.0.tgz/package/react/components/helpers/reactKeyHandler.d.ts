export declare const eventKeyValues: {
    left: string;
    right: string;
    up: string;
    down: string;
    space: string;
    enter: string;
    escape: string;
    tab: string;
    backspace: string;
    shift: string;
    meta: string;
    control: string;
    alt: string;
    pageUp: string;
    pageDown: string;
    home: string;
    end: string;
};
/**
 * Based on the React SyntheticEvent's standard properties, determine whether a keyboard event matches any of a set of keys, as described in keyMap.
 *
 * @private
 * @param {SyntheticEvent} event
 * @param {Array} keysToCheck
 * @returns {boolean}
 */
export declare const matchOneOfKeys: (event: React.KeyboardEvent, keysToCheck: string[]) => boolean;
/**
 * Is the keyboard event triggered by a directional arrow key
 *
 * @export
 * @param {SyntheticEvent} event
 * @returns {boolean}
 */
export declare const isKeyArrow: (event: React.KeyboardEvent) => boolean;
/**
 * Is the keyboard event from a spacebar or enter press
 *
 * @export
 * @param {SyntheticEvent} event
 * @returns {boolean}
 */
export declare const isKeyClick: (event: React.KeyboardEvent) => boolean;
/**
 * Is the keyboard event from a spacebar
 *
 * @export
 * @param {SyntheticEvent} event
 * @returns {boolean}
 */
export declare const isKeySpacebar: (event: React.KeyboardEvent) => boolean;
/**
 * Is the keyboard event a press of the Tab with shift held.
 *
 * @export
 * @param {SyntheticEvent} event
 * @returns {boolean}
 */
export declare const isKeyShiftTab: (event: React.KeyboardEvent) => boolean;
/**
 * Is the keyboard event from a functional key (tab, enter, escape, backspace, shift, control, alt or meta).
 *
 * @export
 * @param {SyntheticEvent} event
 * @returns {boolean}
 */
export declare const isKeyFunctional: (event: React.KeyboardEvent) => boolean;
export declare const isKeyPrintableCharacter: (event: React.KeyboardEvent) => boolean;

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _react = _interopRequireDefault(require("react"));
var _xuiClassNamespace = require("../helpers/xuiClassNamespace");
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const baseClass = `${_xuiClassNamespace.ns}-touchtarget`;
function XUITouchTarget() {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: baseClass
  });
}
var _default = exports.default = XUITouchTarget;
//# sourceMappingURL=XUITouchTarget.js.map
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.variants = exports.sizes = exports.baseClass = void 0;
var _xuiClassNamespace = require("../../helpers/xuiClassNamespace");
const baseClass = exports.baseClass = `${_xuiClassNamespace.ns}-tag`;
const variants = exports.variants = {
  neutral: `${baseClass}-neutral`,
  positive: `${baseClass}-positive`,
  negative: `${baseClass}-negative`,
  warning: `${baseClass}-warning`,
  standard: ''
};
const sizes = exports.sizes = {
  medium: `${baseClass}-medium`,
  small: `${baseClass}-small`,
  xsmall: `${baseClass}-xsmall`
};
//# sourceMappingURL=constants.js.map
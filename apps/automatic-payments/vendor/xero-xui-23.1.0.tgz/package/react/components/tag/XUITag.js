"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = XUITag;
Object.defineProperty(exports, "sizes", {
  enumerable: true,
  get: function () {
    return _constants.sizes;
  }
});
Object.defineProperty(exports, "variants", {
  enumerable: true,
  get: function () {
    return _constants.variants;
  }
});
require("../helpers/xuiGlobalChecks");
var _clsx = _interopRequireDefault(require("clsx"));
var PropTypes = _interopRequireWildcard(require("prop-types"));
var React = _interopRequireWildcard(require("react"));
var _XUITooltip = _interopRequireDefault(require("../tooltip/XUITooltip"));
var _constants = require("./private/constants");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function tagTextOverflows(domElement) {
  return domElement && domElement.clientWidth < domElement.scrollWidth;
}
function XUITag({
  children,
  className,
  debugShowToolTip,
  id,
  qaHook,
  size = 'medium',
  variant = 'standard'
}) {
  const [tooltipIsAttached, setTooltipIsAttached] = React.useState(false);
  const _tooltip = React.useRef(null);
  const _tag = React.useRef(null);
  React.useEffect(() => {
    if (tooltipIsAttached === false && tagTextOverflows(_tag.current)) {
      setTooltipIsAttached(true);
    }
  }, [tooltipIsAttached]);
  const tagNode = /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
    className: (0, _clsx.default)(`${_constants.baseClass}content`, tooltipIsAttached && `${_constants.baseClass}-is-block`),
    "data-automationid": qaHook,
    ref: _tag,
    children: children
  });
  let componentNode;
  if (tooltipIsAttached || debugShowToolTip) {
    componentNode = /*#__PURE__*/(0, _jsxRuntime.jsx)(_XUITooltip.default, {
      hasLimitedWidth: true,
      id: id,
      isHidden: !debugShowToolTip,
      ref: _tooltip,
      trigger: tagNode,
      children: children
    });
  } else {
    componentNode = tagNode;
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
    className: (0, _clsx.default)(_constants.baseClass, className, variant && _constants.variants[variant], size && _constants.sizes[size]),
    children: componentNode
  });
}
XUITag.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  /**
   * @ignore
   * Dev / debug prop to show the tooltip initially on mount instead of based on a user event */
  debugShowToolTip: PropTypes.bool,
  /** Id for tooltip */
  id: PropTypes.string,
  qaHook: PropTypes.string,
  /** Size of tag to render */
  size: PropTypes.oneOf(Object.keys(_constants.sizes)),
  /** Variant of tag to render */
  variant: PropTypes.oneOf(Object.keys(_constants.variants))
};
//# sourceMappingURL=XUITag.js.map
import '../helpers/xuiGlobalChecks';
import * as PropTypes from 'prop-types';
import * as React from 'react';
import { sizes, variants } from './private/constants';
export interface XUITagProps {
    children?: React.ReactNode;
    className?: string;
    /**
     * @ignore
     * Dev / debug prop to show the tooltip initially on mount instead of based on a user event.
     */
    debugShowToolTip?: boolean;
    /**
     * Id for tooltip.
     */
    id?: string;
    qaHook?: string;
    /**
     * Size of tag to render.
     */
    size?: keyof typeof sizes;
    /**
     * Type of tag to render.
     */
    variant?: keyof typeof variants;
}
declare function XUITag({ children, className, debugShowToolTip, id, qaHook, size, variant, }: XUITagProps): React.JSX.Element;
declare namespace XUITag {
    var propTypes: {
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        className: PropTypes.Requireable<string>;
        /**
         * @ignore
         * Dev / debug prop to show the tooltip initially on mount instead of based on a user event */
        debugShowToolTip: PropTypes.Requireable<boolean>;
        /** Id for tooltip */
        id: PropTypes.Requireable<string>;
        qaHook: PropTypes.Requireable<string>;
        /** Size of tag to render */
        size: PropTypes.Requireable<string>;
        /** Variant of tag to render */
        variant: PropTypes.Requireable<string>;
    };
}
export { XUITag as default, sizes, variants };

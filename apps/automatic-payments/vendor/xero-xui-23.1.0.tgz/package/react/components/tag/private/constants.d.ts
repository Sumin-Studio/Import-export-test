export declare const baseClass: string;
export declare const variants: {
    neutral: string;
    positive: string;
    negative: string;
    warning: string;
    standard: string;
};
export declare const sizes: {
    medium: string;
    small: string;
    xsmall: string;
};

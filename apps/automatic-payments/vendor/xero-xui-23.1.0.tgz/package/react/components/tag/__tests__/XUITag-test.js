import React from 'react';
import XUITag from '../XUITag';
import { render } from '@testing-library/react';
import { axe, toHaveNoViolations } from 'jest-axe';

expect.extend(toHaveNoViolations);

describe('<XUITag/>', () => {
  test('renders expected markup', () => {
    const { container } = render(
      <XUITag className="testClass" qaHook="schwifty">
        Testing 💩
      </XUITag>,
    );
    expect(container).toMatchSnapshot();
  });

  test('should pass accessibility testing', async () => {
    const { container } = render(<XUITag>Testing</XUITag>);
    const results = await axe(container);
    expect(results).toHaveNoViolations();
  });
});

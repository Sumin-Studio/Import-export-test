"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _clsx = _interopRequireDefault(require("clsx"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react = _interopRequireDefault(require("react"));
var _xuiClassNamespace = require("../helpers/xuiClassNamespace");
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const baseClass = `${_xuiClassNamespace.ns}-filepreviewfooter`;
const XUIFilePreviewFooter = /*#__PURE__*/_react.default.forwardRef(({
  children,
  className,
  footerTag = 'footer',
  pagination,
  qaHook,
  ...spreadProps
}, ref) => {
  const classes = (0, _clsx.default)(className, baseClass);
  const FooterElem = footerTag;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(FooterElem, {
    className: classes,
    "data-automationid": qaHook,
    ref: ref,
    ...spreadProps,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: `${baseClass}--controls`,
      children: children
    }), pagination && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: `${baseClass}--pagination`,
      children: pagination
    })]
  });
});
XUIFilePreviewFooter.propTypes = {
  /**
   * Content to go in the footer. Typically this will be a set of controls.
   */
  children: _propTypes.default.node,
  /**
   * Classes to be applied to the filepreviewfooter element
   */
  className: _propTypes.default.string,
  /**
   * Tag type for the filepreviewfooter element. Defaults to 'footer'
   */
  footerTag: _propTypes.default.string,
  /**
   * Pagination component to be passed to the file preview footer.
   */
  pagination: _propTypes.default.node,
  qaHook: _propTypes.default.string
};
XUIFilePreviewFooter.displayName = 'XUIFilePreviewFooter';
var _default = exports.default = XUIFilePreviewFooter;
//# sourceMappingURL=XUIFilePreviewFooter.js.map
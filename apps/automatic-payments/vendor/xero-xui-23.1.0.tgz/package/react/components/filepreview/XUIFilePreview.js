"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _clsx = _interopRequireDefault(require("clsx"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react = _interopRequireWildcard(require("react"));
var _useResizeObserver = _interopRequireDefault(require("../helpers/useResizeObserver"));
var _xuiClassNamespace = require("../helpers/xuiClassNamespace");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const baseClass = `${_xuiClassNamespace.ns}-filepreview`;
const FOOTER_HEIGHT = '60';
function XUIFilePreview({
  children,
  className,
  footer,
  header,
  qaHook,
  ...spreadProps
}) {
  const {
    contentRect: {
      height: headerHeight
    },
    observedElementRef
  } = (0, _useResizeObserver.default)();
  const [styles, setStyles] = (0, _react.useState)();
  (0, _react.useEffect)(() => {
    // Set the height of the file preview body component, based on the height of the header and footer
    setStyles({
      height: `calc(100% - (${headerHeight}px + ${FOOTER_HEIGHT}px))`
    });
  }, [headerHeight]);
  const classes = (0, _clsx.default)(baseClass, className);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    ...spreadProps,
    className: classes,
    "data-automationid": qaHook,
    children: [header && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      ref: observedElementRef,
      children: header
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: `${baseClass}--body`,
      "data-automationid": qaHook && `${qaHook}-body}`,
      style: styles,
      children: children
    }), footer]
  });
}
var _default = exports.default = XUIFilePreview;
XUIFilePreview.propTypes = {
  /**
   * Content to go in the grey body area
   */
  children: _propTypes.default.node,
  /**
   * Classes to be applied to the filepreview wrapping element
   */
  className: _propTypes.default.string,
  /**
   * Footer component
   */
  footer: _propTypes.default.node,
  /**
   * Header component
   */
  header: _propTypes.default.node,
  qaHook: _propTypes.default.string
};
//# sourceMappingURL=XUIFilePreview.js.map
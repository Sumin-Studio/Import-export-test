// Libs
import React from 'react';
import cross from '@xero/xui-icon/icons/cross';
import importIcon from '@xero/xui-icon/icons/import';

// Story book things
import { storiesOf } from '@storybook/react';
import { boolean, text, number, object } from '@storybook/addon-knobs';

// Components we need to test with
import FullPageStoryWrapper from '../../../stories/helpers/FullPageStoryWrapper';
import { storiesWithKnobsKindName, storiesWithVariationsKindName, variations } from './variations';

import XUIFilePreview from '../XUIFilePreview';
import XUIFilePreviewHeader from '../XUIFilePreviewHeader';
import XUIButton, { XUIIconButton } from '../../../button';
import XUIIcon from '../../../icon';
import XUITag from '../../tag/XUITag';
import ExampleFooter from './helpers/ExampleFooter';

const storiesWithKnobs = storiesOf(storiesWithKnobsKindName, module);
function getComponent({
  hasAction,
  hasNavBtn,
  hasTags,
  isNavBtnRightAligned,
  previewContainer,
  secondary,
  title,
}) {
  const tags = hasTags
    ? [
        <XUITag size="small" key="tag1">
          {'Sent'}
        </XUITag>,
      ]
    : undefined;

  const navigationButton =
    (hasNavBtn && <XUIIconButton ariaLabel="close" icon={cross} onClick={() => {}} />) || undefined;
  const downloadAction =
    (hasAction && (
      <>
        <XUIButton className="xui-text-truncated" size="small" variant="borderless-main">
          <XUIIcon className="xui-margin-right-xsmall" icon={importIcon} />
          Download
        </XUIButton>
        <XUIButton size="small" variant="create">
          New
        </XUIButton>
      </>
    )) ||
    undefined;
  const header = (
    <XUIFilePreviewHeader
      actions={downloadAction}
      isNavigationButtonRightAligned={isNavBtnRightAligned}
      navigationButton={navigationButton}
      secondary={secondary}
      title={title}
      tags={tags}
    />
  );

  const wrapperStyles =
    previewContainer === 'full'
      ? { height: '100vh' }
      : {
          width: '50%',
          maxHeight: '70vh',
          overflow: 'auto',
          position: 'absolute',
          bottom: '0',
        };
  const imgSettings =
    previewContainer === 'full'
      ? {
          alt: 'Conversation at table',
          src: 'https://edge.xero.com/illustration/casual-meeting-01/casual-meeting-01.svg',
          style: { maxHeight: '100%', maxWidth: '100%' },
        }
      : {
          alt: 'Person running',
          src: 'https://edge.xero.com/illustration/person-running-01/person-running-01.svg',
          style: { maxWidth: '100%' },
        };

  return (
    <FullPageStoryWrapper>
      <div style={wrapperStyles}>
        <XUIFilePreview footer={<ExampleFooter />} header={header}>
          <img alt="" {...imgSettings} />
        </XUIFilePreview>
      </div>
    </FullPageStoryWrapper>
  );
}

storiesWithKnobs.add('Playground', () =>
  getComponent({
    hasAction: boolean('actions?', true),
    hasNavBtn: boolean('navigationButton?', true),
    hasTags: boolean('tags', true),
    isNavBtnRightAligned: boolean('isNavigationButtonRightAligned?', false),
    previewContainer: 'full',
    secondary: text('secondary', 'from Hornblower Enterprises'),
    title: text('title', 'illustration_casual-meeting-01_casual-meeting-01.svg'),
  }),
);

const storiesWithVariations = storiesOf(storiesWithVariationsKindName, module);
variations.forEach(variation => {
  storiesWithVariations.add(variation.storyTitle, () => {
    const variationMinusStoryDetails = { ...variation };
    delete variationMinusStoryDetails.storyKind;
    delete variationMinusStoryDetails.storyTitle;

    const defaultProps = {
      hasAction: true,
      hasNavBtn: true,
      isNavBtnRightAligned: false,
      secondary: 'from Hornblower Enterprises',
      title: 'illustration_casual-meeting-01_casual-meeting-01.svg',
    };

    return getComponent({ ...defaultProps, ...variationMinusStoryDetails });
  });
});

import * as React from 'react';

import { Prettify } from '../../helpers/helperTypes';

interface BaseProps {
  /**
   * Components or html to be right-aligned in the filepreviewheader
   */
  actions?: React.ReactNode;
  /**
   * Content to go in the header. It's unlikely that you will need to use this.
   */
  children?: React.ReactNode;
  /**
   * Classes to be applied to the filepreviewheader element
   */
  className?: string;
  /**
   * Tag type for the filepreviewheader element. Defaults to 'header'
   */
  headerTag?: string;
  /**
   * The level of heading that should be assigned to the title. Defaults to 2 (<h2>).
   */
  headingLevel?: number;
  /**
   * Whether the navigation button appears to the right of the heading.
   */
  isNavigationButtonRightAligned?: boolean;
  /**
   * Navigation button to appear to the left of the heading by default. Used to close/minimise the preview.
   */
  navigationButton?: React.ReactNode;
  qaHook?: string;
  /**
   * Secondary title
   */
  secondary?: React.ReactNode;
  /**
   * Array of `XUITag`s.
   */
  tags?: React.ReactElement[];
  /**
   * Title text or node. Required.
   */
  title: React.ReactNode;
}

// If SpreadProps is a union the Omit must be applied to all types in the union individually.
// Using an Omit over an entire union will not work as expected.
// See XUIButton.d.ts for an example & XUI-3079 for an explanation.
type SpreadProps = Omit<React.HTMLAttributes<HTMLElement>, keyof BaseProps>;

type Props = BaseProps & SpreadProps;

export type XUIFilePreviewHeaderProps = Prettify<Props>;

declare const XUIFilePreviewHeader: React.FunctionComponent<XUIFilePreviewHeaderProps>;
export default XUIFilePreviewHeader;

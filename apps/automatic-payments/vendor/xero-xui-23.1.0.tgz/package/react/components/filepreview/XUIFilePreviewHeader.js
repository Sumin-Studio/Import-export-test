"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _clsx = _interopRequireDefault(require("clsx"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react = _interopRequireDefault(require("react"));
var _useContainerQuery = _interopRequireDefault(require("../../helpers/useContainerQuery"));
var _shouldRender = _interopRequireDefault(require("../helpers/shouldRender"));
var _xuiClassNamespace = require("../helpers/xuiClassNamespace");
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const baseClass = `${_xuiClassNamespace.ns}-filepreviewheader`;
function XUIFilePreviewHeader({
  actions,
  children,
  className,
  headerTag = 'header',
  headingLevel = 2,
  isNavigationButtonRightAligned,
  navigationButton,
  qaHook,
  secondary,
  tags,
  title,
  ...spreadProps
}) {
  const {
    isWidthAboveBreakpoint,
    observedElementRef
  } = (0, _useContainerQuery.default)();
  const classes = (0, _clsx.default)(className, baseClass, isWidthAboveBreakpoint('small') && `${baseClass}-medium-up`, tags && `${baseClass}-has-tags`);
  const HeaderElem = headerTag;
  const HeadingTag = `h${headingLevel}`;
  const controlContent = (0, _shouldRender.default)(navigationButton) && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: `${baseClass}--controlcontent`,
    children: navigationButton
  });
  const titleTags = /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: `${baseClass}--titlewrapper`,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingTag, {
      className: `${baseClass}--title`,
      "data-automationid": qaHook && `${qaHook}--title`,
      children: title
    }), (0, _shouldRender.default)(secondary) && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: `${baseClass}--secondarytitle`,
      "data-automationid": qaHook && `${qaHook}--secondarytitle`,
      children: secondary
    }), tags && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: `${baseClass}--tags`,
      children: tags
    })]
  });
  const leftContent = /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: `${baseClass}--leftcontent`,
    children: [!isNavigationButtonRightAligned && controlContent, titleTags]
  });
  const rightContent = (0, _shouldRender.default)(actions) && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: `${baseClass}--rightcontent`,
    children: [actions && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: `${baseClass}--actions`,
      children: actions
    }), isNavigationButtonRightAligned && controlContent]
  });
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(HeaderElem, {
    ...spreadProps,
    className: classes,
    "data-automationid": qaHook,
    ref: observedElementRef,
    children: [leftContent, children, rightContent]
  });
}
var _default = exports.default = XUIFilePreviewHeader;
XUIFilePreviewHeader.propTypes = {
  /**
   * Components or html to be right-aligned in the filepreviewheader
   */
  actions: _propTypes.default.node,
  /**
   * Content to go in the header. It's unlikely that you will need to use this.
   */
  children: _propTypes.default.node,
  /**
   * Classes to be applied to the filepreviewheader element
   */
  className: _propTypes.default.string,
  /**
   * Tag type for the filepreviewheader element. Defaults to 'header'
   */
  headerTag: _propTypes.default.string,
  /**
   * The level of heading that should be assigned to the title. Defaults to 2.
   */
  headingLevel: _propTypes.default.number,
  /**
   * Whether the navigation button appears to the right of the heading.
   */
  isNavigationButtonRightAligned: _propTypes.default.bool,
  /**
   * Navigation button to appear to the left of the heading. Used to close/minimise the preview.
   */
  navigationButton: _propTypes.default.node,
  qaHook: _propTypes.default.string,
  /**
   * Secondary title
   */
  secondary: _propTypes.default.node,
  /**
   * Array of XUITags
   */
  tags: _propTypes.default.arrayOf(_propTypes.default.element),
  /**
   * Title text or node. Required.
   */
  title: _propTypes.default.node.isRequired
};
//# sourceMappingURL=XUIFilePreviewHeader.js.map
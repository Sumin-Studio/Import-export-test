import { desktopPlus320 } from '../../../stories/helpers/viewports';

const storiesWithKnobsKindName = 'Components/XUIFilePreview';
const storiesWithVariationsKindName = `${storiesWithKnobsKindName}/Tests`;

const variations = [
  {
    storyKind: storiesWithVariationsKindName,
    storyTitle: 'default',
    viewports: desktopPlus320,
    previewContainer: 'full',
  },
  {
    storyKind: storiesWithVariationsKindName,
    storyTitle: 'in a side container',
    previewContainer: 'side container',
  },
  {
    storyKind: storiesWithVariationsKindName,
    storyTitle: 'with a tag',
    previewContainer: 'full',
    hasTags: 'true',
    listOfTags: 'Sent',
  },
];

export { storiesWithVariationsKindName, storiesWithKnobsKindName, variations };

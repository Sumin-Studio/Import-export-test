import * as React from 'react';

export interface XUIFixedFooterProps {
  children?: React.ReactNode;
  className?: string;
  /**
   * Breakpoint at which to un-fix the footer. Defaults to undefined.
   * Supported breakpoints are `xsmall` (400px), `small` (600px), `medium` (800px), `large` (1000px), `xlarge` (1200px), and `2xlarge` (1600px) or a custom number that represents the size of the breakpoint in pixels.
   */
  unfixAtBreakpoint?: keyof typeof breakpoints | number;
  qaHook?: string;
}

export default class XUIFixedFooterWIP extends React.PureComponent<XUIFixedFooterProps> {}

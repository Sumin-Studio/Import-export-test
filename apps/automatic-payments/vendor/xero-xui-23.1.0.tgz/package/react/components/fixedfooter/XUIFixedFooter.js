"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = XUIFixedFooter;
var _clsx = _interopRequireDefault(require("clsx"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react = _interopRequireWildcard(require("react"));
var _reactPortal = require("react-portal");
var _breakpoints = _interopRequireDefault(require("../helpers/breakpoints"));
var _developmentConsole = require("../helpers/developmentConsole");
var _portalContainer = _interopRequireDefault(require("../helpers/portalContainer"));
var _useWindowResize = _interopRequireDefault(require("../helpers/useWindowResize"));
var _xuiClassNamespace = require("../helpers/xuiClassNamespace");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const baseClass = `${_xuiClassNamespace.ns}-fixedfooter`;
function XUIFixedFooter({
  children,
  className,
  unfixAtBreakpoint,
  qaHook,
  ...spreadProps
}) {
  const [logged, setLogged] = (0, _react.useState)(false);
  if (!logged) {
    setLogged(true);
    (0, _developmentConsole.logWarning)({
      componentName: 'XUIFixedFooter',
      flagType: 'wip'
    });
  }
  const windowDimensions = (0, _useWindowResize.default)();
  let unfixFooter = false;
  if (unfixAtBreakpoint) {
    if (typeof unfixAtBreakpoint === 'number' && windowDimensions.width <= unfixAtBreakpoint || _breakpoints.default[unfixAtBreakpoint] && windowDimensions.width <= _breakpoints.default[unfixAtBreakpoint]) {
      unfixFooter = true;
    }
  }

  // Because we never know how tall a fixed footer is going to be or what its nearest siblings will be,
  // we can't set the proper spacing to prevent content from being hidden. Even the newer CSS
  // "position: sticky" would not quite work as desired, for content shorter than the viewport.
  // This is perhaps inelegant, but gets the job done. Watch out for cloned content with ids on
  // child elements, as they will also be duplicated.
  const cloneFooter = /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    ...spreadProps,
    "aria-hidden": true,
    className: (0, _clsx.default)(baseClass, className, `${baseClass}-clone`),
    id: undefined // Ensures that if an id is passed as a prop, we strip it from the clone.
    ,
    role: "presentation",
    children: children
  });
  const visibleFooter = /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    ...spreadProps,
    className: (0, _clsx.default)(baseClass, className, unfixFooter && `${baseClass}-unfix`),
    "data-automationid": qaHook,
    children: children
  });
  const fixedFooter = /*#__PURE__*/(0, _jsxRuntime.jsx)(_reactPortal.Portal, {
    node: (0, _portalContainer.default)(),
    children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: `${baseClass}--wrapper ${_xuiClassNamespace.ns}-container`,
      children: [visibleFooter, cloneFooter]
    })
  });
  const unfixedFooter = /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: `${baseClass}--wrapper ${_xuiClassNamespace.ns}-container`,
    children: visibleFooter
  });
  return unfixFooter ? unfixedFooter : fixedFooter;
}
XUIFixedFooter.propTypes = {
  children: _propTypes.default.node,
  className: _propTypes.default.string,
  qaHook: _propTypes.default.string,
  /**
   * Breakpoint at which to un-fix the footer. Defaults to undefined.
   * Supported breakpoints are `xsmall` (400px), `small` (600px), `medium` (800px), `large` (1000px), `xlarge` (1200px), and `2xlarge` (1600px) or a custom number that represents the size of the breakpoint in pixels.
   */
  unfixAtBreakpoint: _propTypes.default.oneOfType([_propTypes.default.oneOf(Object.keys(_breakpoints.default)), _propTypes.default.number])
};
//# sourceMappingURL=XUIFixedFooter.js.map
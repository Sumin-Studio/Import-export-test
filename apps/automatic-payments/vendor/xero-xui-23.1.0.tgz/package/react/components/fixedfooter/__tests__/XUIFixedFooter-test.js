import { render, screen } from '@testing-library/react';
import { axe, toHaveNoViolations } from 'jest-axe';
import React from 'react';

import XUIFixedFooter from '../XUIFixedFooter';

expect.extend(toHaveNoViolations);

// throwing this in to ignore the _intentional_ console warnings and allow tests to run.
jest.mock('console');

describe('<XUIFixedFooter/>', () => {
  test('renders expected markup', () => {
    const testHook = 'testHook';
    render(
      <>
        <XUIFixedFooter className="testClass" qaHook={testHook}>
          Testing bar content
        </XUIFixedFooter>
        <div />
      </>,
    );

    expect(screen.getByTestId(testHook)).toMatchSnapshot();
  });

  test('should pass accessibility testing', async () => {
    const { container } = render(<XUIFixedFooter>Testing</XUIFixedFooter>);
    const results = await axe(container);
    expect(results).toHaveNoViolations();
  });

  test('does not portal footer if unfixAtBreakpoint is specified', () => {
    const testId = 'fixedfooter-test';

    Object.defineProperty(window, 'innerWidth', {
      writable: true,
      configurable: true,
      value: 500,
    });

    window.dispatchEvent(new Event('resize'));

    expect(window.innerWidth).toBe(500);

    render(
      <XUIFixedFooter unfixAtBreakpoint="medium" qaHook={testId}>
        Testing
      </XUIFixedFooter>,
    );

    expect(screen.getByTestId(testId).parentNode).not.toHaveClass('xui-portal');
  });
});

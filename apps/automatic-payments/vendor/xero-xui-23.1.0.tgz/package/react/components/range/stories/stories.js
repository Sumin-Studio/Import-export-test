// Libs
import React from 'react';

// Story book things
import { storiesOf } from '@storybook/react';
import { boolean, text, number, select } from '@storybook/addon-knobs';

// Components we need to test with
import XUIAvatar from '../../avatar/XUIAvatar';
import XUIRange from '../XUIRange';

import { storiesWithKnobsKindName, storiesWithVariationsKindName, variations } from './variations';

const storiesWithKnobs = storiesOf(storiesWithKnobsKindName, module);
storiesWithKnobs.add('Playground', () => {
  const showLeftElement = boolean('Show left element', true);
  const showRightElement = boolean('Show right element', true);

  return (
    <XUIRange
      hintMessage={text('hintMessage', '')}
      id={text('id', '')}
      isDisabled={boolean('isDisabled', false)}
      isInvalid={boolean('isInvalid', false)}
      label={text('label', 'Label for the range input')}
      labelId={text('labelId', '')}
      leftElement={
        showLeftElement && (
          <XUIAvatar
            className="xui-margin-small"
            imageUrl="https://upload.wikimedia.org/wikipedia/commons/2/29/Solid_green.svg"
            value="left"
          />
        )
      }
      max={number('max', 100)}
      min={number('min', 0)}
      rightElement={
        showRightElement && (
          <XUIAvatar
            className="xui-margin-small"
            imageUrl="https://upload.wikimedia.org/wikipedia/commons/2/29/Solid_green.svg"
            value="right"
          />
        )
      }
      size={select('size', ['medium', 'small', 'xsmall'], 'medium')}
      step={number('step', 0)}
      validationMessage={text('validationMessage', 'validation text')}
    />
  );
});

const storiesWithVariations = storiesOf(storiesWithVariationsKindName, module);

variations.forEach(variation => {
  storiesWithVariations.add(variation.storyTitle, () => {
    const variationMinusStoryDetails = {
      ...variation,
    };

    return <XUIRange {...variationMinusStoryDetails} label={variation.storyTitle} />;
  });
});

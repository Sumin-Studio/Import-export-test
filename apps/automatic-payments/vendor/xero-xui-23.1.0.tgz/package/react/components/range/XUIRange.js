"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _clsx = _interopRequireDefault(require("clsx"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react = _interopRequireWildcard(require("react"));
var _XUIControlWrapper = _interopRequireDefault(require("../controlwrapper/XUIControlWrapper"));
var _ariaHelpers = _interopRequireWildcard(require("../helpers/ariaHelpers"));
var _labelRequiredError = _interopRequireDefault(require("../helpers/labelRequiredError"));
var _xuiClassNamespace = require("../helpers/xuiClassNamespace");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const baseClass = `${_xuiClassNamespace.ns}-rangeslider`;
function XUIRange(props) {
  const {
    containerClassName,
    defaultValue,
    hintMessage,
    id,
    inputClassName,
    isDisabled,
    isInvalid,
    isLabelHidden,
    label,
    labelId,
    leftElement,
    max,
    min,
    name,
    onClick,
    onInput,
    qaHook,
    rightElement,
    size = 'medium',
    step,
    validationMessage
  } = props;
  const wrapperIds = (0, _ariaHelpers.default)({
    labelId,
    id
  });
  const labelRef = /*#__PURE__*/_react.default.createRef();
  (0, _react.useEffect)(() => {
    var _labelRef$current;
    (0, _labelRequiredError.default)(XUIRange.name, ['includes a label with text', 'labelId provided'], [((_labelRef$current = labelRef.current) === null || _labelRef$current === void 0 ? void 0 : _labelRef$current.textContent) && !isLabelHidden, typeof (label === null || label === void 0 ? void 0 : label[0]) === 'string', labelId]);
  }, [isLabelHidden, label, labelId, labelRef]);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_XUIControlWrapper.default, {
    hintMessage: hintMessage,
    isInvalid: isInvalid,
    isLabelHidden: isLabelHidden,
    label: label,
    labelRef: labelRef,
    qaHook: qaHook,
    validationMessage: validationMessage,
    wrapperIds: wrapperIds,
    children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: (0, _clsx.default)(`${baseClass}-container`, containerClassName),
      children: [leftElement, /*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
        className: (0, _clsx.default)(`${baseClass}`, size && `${baseClass}-thumb-${size}`, isInvalid && `${baseClass}-is-invalid`, inputClassName),
        defaultValue: defaultValue,
        disabled: isDisabled,
        id: id,
        max: max,
        min: min,
        name: name,
        onClick: onClick,
        onInput: onInput,
        step: step,
        type: "range",
        ...(0, _ariaHelpers.getAriaAttributes)(wrapperIds, props)
      }), rightElement]
    })
  });
}
var _default = exports.default = XUIRange;
XUIRange.propTypes = {
  /** Additional classes to be applied to the container */
  containerClassName: _propTypes.default.string,
  /** Default value of the XUIRange component */
  defaultValue: _propTypes.default.oneOfType([_propTypes.default.number, _propTypes.default.string]),
  /** Hint message to be passed into the XUIControlWrapper */
  hintMessage: _propTypes.default.node,
  /** Id of Range Component */
  id: _propTypes.default.string,
  /** Additional classes to be applied to the input */
  inputClassName: _propTypes.default.string,
  /** Disables the XUIRange component */
  isDisabled: _propTypes.default.bool,
  /** Displays that the XUIRange component is invalid */
  isInvalid: _propTypes.default.bool,
  /** Boolean to hide/show Input label */
  isLabelHidden: _propTypes.default.bool,
  /** Input label */
  label: _propTypes.default.node,
  /** Provide a specific label ID which will be used as the "labelleby" aria property */
  labelId: _propTypes.default.string,
  /** Element on the left of the XUIRange component */
  leftElement: _propTypes.default.node,
  /** Maximum value of the XUIRange component */
  max: _propTypes.default.oneOfType([_propTypes.default.number, _propTypes.default.string]),
  /** Minimum value of the XUIRange component */
  min: _propTypes.default.oneOfType([_propTypes.default.number, _propTypes.default.string]),
  /** Name to be consumed by form objects etc */
  name: _propTypes.default.string,
  /** Define a function for the onClick event of the slider being clicked */
  onClick: _propTypes.default.func,
  /** Define a function for the onInput event of when the value of the slider is set/changed */
  onInput: _propTypes.default.func,
  qaHook: _propTypes.default.string,
  /** Element on the right of the XUIRange component */
  rightElement: _propTypes.default.node,
  /** Sizing of the circle touch object */
  size: _propTypes.default.oneOf(['medium', 'small', 'xsmall']),
  /** The incremement of the XUIRange slider value */
  step: _propTypes.default.oneOfType([_propTypes.default.number, _propTypes.default.string]),
  /** The message to show in validation */
  validationMessage: _propTypes.default.node
};
//# sourceMappingURL=XUIRange.js.map
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import plus from '@xero/xui-icon/icons/plus';
import { axe, toHaveNoViolations } from 'jest-axe';
import { nanoid } from 'nanoid';
import React from 'react';

import XUIIcon from '../../../icon';
import XUIRange from '../XUIRange';

expect.extend(toHaveNoViolations);

jest.mock('nanoid');
nanoid.mockImplementation(() => 'testRangeId');

describe('Range', () => {
  test('should pass accessibility testing', async () => {
    const { container } = render(<XUIRange label="Range" />);
    const results = await axe(container);
    expect(results).toHaveNoViolations();
  });

  test('label ID provided', () => {
    render(<XUIRange labelId="myTestLabel" />);

    expect(screen.getByRole('slider')).toHaveAttribute('aria-labelledby', 'myTestLabel');
  });

  test('should call the onClick callback on the range component', async () => {
    const onClick = jest.fn();
    render(<XUIRange id="rangeComponent" label="Range" onClick={onClick} />);

    await userEvent.click(screen.getByRole('slider'));

    expect(onClick).toHaveBeenCalledTimes(1);
  });

  test('All options selected', () => {
    const { container } = render(
      <XUIRange
        containerClassName="containerClassName"
        defaultValue="20"
        hintMessage="hintMessage"
        id="range1"
        inputClassName="inputClassName"
        isDisabled
        isInvalid
        label={<>All options selected</>}
        leftElement={<XUIIcon icon={plus} size="large" />}
        max="80"
        min="16"
        qaHook="qaHook"
        rightElement={<XUIIcon icon={plus} size="large" />}
        size="xsmall"
        step="4"
        validationMessage="validationMessage"
      />,
    );

    expect(container).toMatchSnapshot();
  });
});

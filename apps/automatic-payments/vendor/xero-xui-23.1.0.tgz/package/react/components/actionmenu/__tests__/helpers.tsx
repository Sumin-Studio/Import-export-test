import overflowIcon from '@xero/xui-icon/icons/overflow';
import React from 'react';

import XUIActionMenu from '../XUIActionMenu';
import XUIActionMenuButtonTrigger from '../XUIActionMenuButtonTrigger';
import XUIActionMenuIconButtonTrigger from '../XUIActionMenuIconButtonTrigger';
import XUIActionMenuItem from '../XUIActionMenuItem';
import XUIActionMenuItems from '../XUIActionMenuItems';

const generateMenuItems = (numMenuItems: number) => {
  const menuItems: React.JSX.Element[] = [];
  for (let i = 0; i < numMenuItems; i += 1) {
    menuItems.push(
      <XUIActionMenuItem key={i} qaHook={`menuitem-${i + 1}`}>
        {`Menuitem ${i + 1}`}
      </XUIActionMenuItem>,
    );
  }
  return menuItems;
};

export const createBasicMenu = (
  {
    numMenuItems = 3,
    triggerType = 'icon',
  }: {
    numMenuItems?: number;
    triggerType?: string;
  } = { numMenuItems: 3 },
) => (
  <XUIActionMenu>
    {triggerType === 'icon' ? (
      <XUIActionMenuIconButtonTrigger ariaLabel="More options" icon={overflowIcon} />
    ) : (
      <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
    )}
    <XUIActionMenuItems>{generateMenuItems(numMenuItems)}</XUIActionMenuItems>
  </XUIActionMenu>
);

export function configureTestEnvironment(innerWidth = 200) {
  Object.defineProperty(window, 'innerWidth', {
    writable: true,
    configurable: true,
    value: innerWidth,
  });
}

export function cleanupTestEnvironment() {
  Object.defineProperty(window, 'innerWidth', {
    writable: true,
    configurable: true,
    value: 1024,
  });
}

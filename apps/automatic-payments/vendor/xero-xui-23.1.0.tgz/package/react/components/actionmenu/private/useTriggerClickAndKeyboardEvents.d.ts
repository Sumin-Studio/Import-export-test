import * as React from 'react';
interface Props {
    isDisabled?: boolean;
    onClick?: React.MouseEventHandler<HTMLElement>;
    onKeyDown?: React.KeyboardEventHandler<HTMLElement>;
    isSubmenuTrigger?: boolean;
}
export default function useTriggerClickAndKeyboardEvents({ onClick, onKeyDown, isDisabled, isSubmenuTrigger, }: Props): {
    composedHandleTriggerClick: (event: React.MouseEvent<HTMLButtonElement>) => void;
    composedHandleTriggerKeyDown: (event: React.KeyboardEvent<HTMLButtonElement>) => void;
};
export {};

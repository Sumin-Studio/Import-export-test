import { desktopPlus320 } from '../../../stories/helpers/viewports';

const storiesWithKnobsKindName = 'Components/XUIActionMenu';
const storiesWithVariationsKindName = `${storiesWithKnobsKindName}/Tests`;

// Bottom left is the default position and so is already accounted for
const locationsToTest = [
  'bottom-right',
  'top-left',
  'top-right',
  'right-top',
  'right-bottom',
  'left-top',
  'left-bottom',
];

const positionVariations = [...locationsToTest].map(preferredFlyoutPosition => ({
  storyKind: storiesWithVariationsKindName,
  storyTitle: `flyout located to the ${preferredFlyoutPosition}`,
  preferredFlyoutPosition,
}));

const variations = [
  {
    storyKind: storiesWithVariationsKindName,
    storyTitle: 'with icon button trigger',
    viewports: desktopPlus320,
    menuContent: ['menuitem'],
  },
  {
    storyKind: storiesWithVariationsKindName,
    storyTitle: 'with button trigger',
    viewports: desktopPlus320,
    buttonVariant: 'standard',
    buttonSize: 'medium',
    buttonLabel: 'More options',
    menuContent: ['menuitem'],
  },
  {
    storyKind: storiesWithVariationsKindName,
    storyTitle: 'with icons',
    viewports: desktopPlus320,
    withMenuitemIcons: true,
    menuContent: ['menuitem'],
  },
  {
    storyKind: storiesWithVariationsKindName,
    storyTitle: 'with checkbox',
    viewports: desktopPlus320,
    buttonVariant: 'standard',
    buttonSize: 'medium',
    buttonLabel: 'Filter',
    menuContent: ['checkbox'],
  },
  {
    storyKind: storiesWithVariationsKindName,
    storyTitle: 'with radio',
    viewports: desktopPlus320,
    buttonVariant: 'standard',
    buttonSize: 'medium',
    buttonLabel: 'Sort',
    menuContent: ['radio'],
  },
  {
    storyKind: storiesWithVariationsKindName,
    storyTitle: 'with group and heading',
    viewports: desktopPlus320,
    menuContent: ['heading'],
  },
  {
    storyKind: storiesWithVariationsKindName,
    storyTitle: 'with submenu',
    viewports: desktopPlus320,
    menuContent: ['menuitem', 'submenu'],
  },
  {
    storyKind: storiesWithVariationsKindName,
    storyTitle: 'with menu group',
    viewports: desktopPlus320,
    menuContent: ['group'],
  },
  {
    storyKind: storiesWithVariationsKindName,
    storyTitle: 'with separator',
    viewports: desktopPlus320,
    menuContent: ['menuitem', 'separator', 'group'],
  },
  {
    storyKind: storiesWithVariationsKindName,
    storyTitle: 'with all types of menuitem',
    viewports: desktopPlus320,
    menuContent: ['separator', 'submenu', 'radio', 'heading'],
    withMenuitemIcons: true,
  },
  {
    storyKind: storiesWithVariationsKindName,
    storyTitle: 'with set width',
    viewports: desktopPlus320,
    menuContent: ['menuitem', 'separator', 'heading'],
    withMenuitemIcons: true,
    hasCustomWidth: true,
  },
  ...positionVariations,
];

export { storiesWithVariationsKindName, storiesWithKnobsKindName, variations };

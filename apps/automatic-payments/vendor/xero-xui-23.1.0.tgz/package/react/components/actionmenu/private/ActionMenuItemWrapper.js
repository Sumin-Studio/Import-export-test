"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ActionMenuItemWrapper = ActionMenuItemWrapper;
var _clsx = _interopRequireDefault(require("clsx"));
var _nanoid = require("nanoid");
var React = _interopRequireWildcard(require("react"));
var _constants = require("./constants");
var _useActionMenuContext = require("./useActionMenuContext");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function MenuItem({
  className,
  children,
  hasSubmenu,
  id,
  isLink,
  onSelect,
  qaHook,
  role,
  ...props
}) {
  const {
    anchorElementAttributes,
    flyoutId,
    isFlyoutOpen,
    menuRefsRef,
    focusedMenuItemId,
    isFocusVisible
  } = (0, _useActionMenuContext.useActionMenuContext)();
  const itemRef = React.useRef(null);
  const buttonRef = hasSubmenu ? menuRefsRef.current.triggerRef : itemRef;
  const generatedMenuItemId = React.useRef((0, _nanoid.nanoid)());
  const calculatedMenuItemId = id || generatedMenuItemId.current || undefined;
  React.useEffect(() => {
    const currentMenu = menuRefsRef.current;

    // Submenu trigger shouldn't get added to the list of menuitems as it's assigned to the triggerRef property
    if (hasSubmenu) {
      return undefined;
    }
    currentMenu.menuitems.push(itemRef);
    return () => {
      currentMenu.menuitems = currentMenu.menuitems.filter(menuItemRef => menuItemRef !== itemRef);
    };
  }, [hasSubmenu, menuRefsRef]);
  const memoisedTabIndex = React.useMemo(() => focusedMenuItemId === calculatedMenuItemId ? 0 : -1, [calculatedMenuItemId, focusedMenuItemId]);
  const submenuProps = hasSubmenu ? {
    'aria-controls': flyoutId,
    'aria-expanded': isFlyoutOpen,
    'aria-haspopup': 'true',
    ...anchorElementAttributes,
    style: {
      ...(anchorElementAttributes === null || anchorElementAttributes === void 0 ? void 0 : anchorElementAttributes.style)
    }
  } : {};
  const sharedProps = {
    className: (0, _clsx.default)(className, `${_constants.baseClassName}__menuitem`, calculatedMenuItemId === focusedMenuItemId && `${_constants.baseClassName}__menuitem--is-focused`, isFocusVisible && `${_constants.baseClassName}__menuitem--focus-is-visible`),
    'data-automationid': qaHook,
    id: calculatedMenuItemId,
    tabIndex: memoisedTabIndex
  };
  return isLink ? /*#__PURE__*/(0, _jsxRuntime.jsx)("a", {
    ...props,
    ...sharedProps,
    ref: itemRef,
    role: "menuitem",
    children: children
  }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
    ...props,
    ...submenuProps,
    ...sharedProps,
    ref: buttonRef,
    role: role,
    type: "button",
    children: children
  });
}
function ActionMenuItemWrapper(props) {
  const {
    className,
    qaHook
  } = props;
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
    className: (0, _clsx.default)(`${_constants.baseClassName}__menuitem-wrapper`, className && `${className}__wrapper`),
    "data-automationid": qaHook && `${qaHook}__menuitem-wrapper`,
    role: "none",
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(MenuItem, {
      ...props
    })
  });
}
//# sourceMappingURL=ActionMenuItemWrapper.js.map
import * as React from 'react';
export interface BaseActionMenuItemProps {
    /**
     * The text content of the menu item
     */
    children: React.ReactNode;
    /**
     * Additional classes to apply to the menu item
     */
    className?: string;
    /**
     * The ID for the menu item
     */
    id?: string;
    /**
     * Click event for the menu item.
     * Note: `onSelect` should be used instead in most cases
     */
    onClick?: React.MouseEventHandler<HTMLButtonElement>;
    /**
     * Key down event for the menu item.
     * Note: `onSelect` should be used instead in most cases
     */
    onKeyDown?: React.KeyboardEventHandler<HTMLButtonElement>;
    /**
     * Callback for when the user makes a selection.
     * Called when the user clicks or activates the menu item with space or enter.
     * Provide `id`s for the menu items if `menuItemId` needs to be predictable
     */
    onSelect?: (menuItemId?: string) => void;
    /**
     * Adds a data-automationid attribute to the element
     */
    qaHook?: string;
}

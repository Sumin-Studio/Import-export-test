"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _clsx = _interopRequireDefault(require("clsx"));
var _nanoid = require("nanoid");
var React = _interopRequireWildcard(require("react"));
var _XUIIconButton = _interopRequireDefault(require("../button/XUIIconButton"));
var _constants = require("./private/constants");
var _useActionMenuContext = require("./private/useActionMenuContext");
var _useTriggerClickAndKeyboardEvents = _interopRequireDefault(require("./private/useTriggerClickAndKeyboardEvents"));
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function XUIActionMenuIconButtonTrigger({
  className,
  onClick,
  onKeyDown,
  id,
  style,
  ...props
}) {
  const {
    anchorElementAttributes,
    isFlyoutOpen,
    isFocusVisible,
    flyoutId,
    menuRefsRef
  } = (0, _useActionMenuContext.useActionMenuContext)();
  const {
    composedHandleTriggerClick,
    composedHandleTriggerKeyDown
  } = (0, _useTriggerClickAndKeyboardEvents.default)({
    onClick,
    onKeyDown
  });
  const generatedTriggerId = React.useRef((0, _nanoid.nanoid)());
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_XUIIconButton.default, {
    ...props,
    "aria-controls": flyoutId,
    "aria-expanded": isFlyoutOpen,
    "aria-haspopup": "true",
    className: (0, _clsx.default)(className, isFocusVisible && `${_constants.baseClassName}__trigger--focus-is-visible`),
    id: id || generatedTriggerId.current,
    onClick: composedHandleTriggerClick,
    onKeyDown: composedHandleTriggerKeyDown,
    role: "button",
    ref: menuRefsRef.current.triggerRef,
    ...anchorElementAttributes,
    style: {
      ...style,
      ...(anchorElementAttributes === null || anchorElementAttributes === void 0 ? void 0 : anchorElementAttributes.style)
    }
  });
}
var _default = exports.default = XUIActionMenuIconButtonTrigger;
//# sourceMappingURL=XUIActionMenuIconButtonTrigger.js.map
#### Action Menu Button Trigger

For use in `XUIActionMenu`. Has a subset of the props from [XUIButton](#button).
Note: prop descriptions below are directly from `XUIButton`.

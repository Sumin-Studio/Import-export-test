import { Location as Position } from '../../helpers/Positioning/helpers/positioning';
export declare const baseClassName: string;
export declare const focusVisibleKeys: string[];
export declare const preferredSubmenuPositionFallbacks: Position[];
export declare const preferredFlyoutPositionFallbacks: Position[];
export declare const submenuFlyoutGap = -3;
export declare const triggerFlyoutGap = 4;

import { XUIActionMenuContextValue } from './ActionMenuContext';
export declare const useActionMenuContext: () => XUIActionMenuContextValue;

import * as React from 'react';
import { Prettify } from '../../helpers/helperTypes';
import { BaseActionMenuItemProps } from './private/BaseActionMenuItemProps';
interface ActionMenuItemCheckboxProps extends BaseActionMenuItemProps {
    /**
     * Whether the menu item checkbox is checked or not. Use for the controlled implementation
     */
    isChecked?: boolean;
}
export type XUIActionMenuItemCheckboxProps = Prettify<ActionMenuItemCheckboxProps>;
export declare function XUIActionMenuItemCheckbox({ className, id, isChecked: providedIsChecked, onClick, onKeyDown, onSelect, children, ...props }: ActionMenuItemCheckboxProps): React.JSX.Element;
export default XUIActionMenuItemCheckbox;

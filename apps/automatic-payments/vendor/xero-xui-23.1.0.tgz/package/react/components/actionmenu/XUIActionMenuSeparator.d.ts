import * as React from 'react';
import { Prettify } from '../../helpers/helperTypes';
interface ActionMenuSeparatorProps {
    /**
     * Additional classes to apply to the separator
     */
    className?: string;
}
export type XUIActionMenuSeparatorProps = Prettify<ActionMenuSeparatorProps>;
declare function XUIActionMenuSeparator({ className }: ActionMenuSeparatorProps): React.JSX.Element;
export default XUIActionMenuSeparator;

import { RadioGroupContext } from './ActionMenuRadioGroupContext';
export declare const useActionMenuRadioGroupContext: () => RadioGroupContext;

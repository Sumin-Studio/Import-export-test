"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.triggerFlyoutGap = exports.submenuFlyoutGap = exports.preferredSubmenuPositionFallbacks = exports.preferredFlyoutPositionFallbacks = exports.focusVisibleKeys = exports.baseClassName = void 0;
var _reactKeyHandler = require("../../helpers/reactKeyHandler");
var _xuiClassNamespace = require("../../helpers/xuiClassNamespace");
const baseClassName = exports.baseClassName = `${_xuiClassNamespace.ns}-action-menu`;
const focusVisibleKeys = exports.focusVisibleKeys = [_reactKeyHandler.eventKeyValues.down, _reactKeyHandler.eventKeyValues.up, _reactKeyHandler.eventKeyValues.enter, _reactKeyHandler.eventKeyValues.space, _reactKeyHandler.eventKeyValues.right, _reactKeyHandler.eventKeyValues.left, _reactKeyHandler.eventKeyValues.home, _reactKeyHandler.eventKeyValues.end];
const preferredSubmenuPositionFallbacks = exports.preferredSubmenuPositionFallbacks = ['right-top', 'right-bottom', 'left-top', 'left-bottom'];
const preferredFlyoutPositionFallbacks = exports.preferredFlyoutPositionFallbacks = ['bottom-left', 'bottom-right', 'top-left', 'top-right', 'right-top', 'right-bottom', 'left-top', 'left-bottom'];
const submenuFlyoutGap = exports.submenuFlyoutGap = -3;
const triggerFlyoutGap = exports.triggerFlyoutGap = 4;
//# sourceMappingURL=constants.js.map
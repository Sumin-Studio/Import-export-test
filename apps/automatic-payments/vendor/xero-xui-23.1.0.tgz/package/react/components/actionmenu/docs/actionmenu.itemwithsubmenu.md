#### Action Menu Item With Submenu

A menu item which opens a submenu.

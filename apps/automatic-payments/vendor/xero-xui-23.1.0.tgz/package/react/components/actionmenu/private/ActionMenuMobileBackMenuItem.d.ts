import * as React from 'react';
import { BaseActionMenuItemProps } from './BaseActionMenuItemProps';
interface ActionMenuBackButtonProps extends BaseActionMenuItemProps {
    isBelowSmallBreakpoint: boolean;
    tabIndex: number;
}
export default function ActionMenuMobileBackMenuItem({ isBelowSmallBreakpoint, id, children, onSelect, qaHook, ...props }: ActionMenuBackButtonProps): React.JSX.Element;
export {};

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.XUIActionMenuItem = XUIActionMenuItem;
exports.default = void 0;
require("core-js/modules/es.array.includes.js");
var _nanoid = require("nanoid");
var React = _interopRequireWildcard(require("react"));
var _reactKeyHandler = require("../helpers/reactKeyHandler");
var _XUIIcon = _interopRequireDefault(require("../icon/XUIIcon"));
var _ActionMenuItemWrapper = require("./private/ActionMenuItemWrapper");
var _constants = require("./private/constants");
var _useActionMenuContext = require("./private/useActionMenuContext");
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function XUIActionMenuItem({
  id,
  onClick,
  onKeyDown,
  onSelect,
  leftIcon,
  children,
  ...props
}) {
  const {
    handleMenuItemKeyDown,
    setIsMainFlyoutOpen
  } = (0, _useActionMenuContext.useActionMenuContext)();
  const {
    isLink,
    href,
    to
  } = props;
  const generatedMenuItemId = React.useRef((0, _nanoid.nanoid)());
  const calculatedMenuItemId = id || generatedMenuItemId.current || undefined;
  const handleClick = React.useCallback(e => {
    setIsMainFlyoutOpen(false);
    onSelect === null || onSelect === void 0 || onSelect(calculatedMenuItemId);
    onClick === null || onClick === void 0 || onClick(e);
  }, [calculatedMenuItemId, onClick, onSelect, setIsMainFlyoutOpen]);
  const composedHandleKeyDown = React.useCallback(event => {
    const activationKeys = [_reactKeyHandler.eventKeyValues.space, _reactKeyHandler.eventKeyValues.enter];
    const key = event.key;
    if (activationKeys.includes(key)) {
      setIsMainFlyoutOpen(false);
      onSelect === null || onSelect === void 0 || onSelect(calculatedMenuItemId);
    }
    if (!isLink || isLink && !activationKeys.includes(key)) {
      handleMenuItemKeyDown(event);
    }
    onKeyDown === null || onKeyDown === void 0 || onKeyDown(event);
    if (isLink && key === _reactKeyHandler.eventKeyValues.space) {
      event.preventDefault();
      if (href) {
        window.location.href = href;
      }
    }
  }, [calculatedMenuItemId, handleMenuItemKeyDown, href, isLink, onKeyDown, onSelect, setIsMainFlyoutOpen]);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_ActionMenuItemWrapper.ActionMenuItemWrapper, {
    href: href || to,
    id: calculatedMenuItemId,
    onClick: handleClick,
    onKeyDown: composedHandleKeyDown,
    role: "menuitem",
    ...props,
    children: [leftIcon && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      "aria-hidden": "true",
      className: `${_constants.baseClassName}__menuitem-left-icon`,
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_XUIIcon.default, {
        icon: leftIcon,
        color: "black-faint"
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: `${_constants.baseClassName}__menuitem-text`,
      children: children
    })]
  });
}
var _default = exports.default = XUIActionMenuItem;
//# sourceMappingURL=XUIActionMenuItem.js.map
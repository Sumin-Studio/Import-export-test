#### Action Menu Radio Group

Required when using `XUIActionMenuItemRadio`s, use as a wrapper to group them.

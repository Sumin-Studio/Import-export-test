import * as React from 'react';
import { Prettify } from '../../helpers/helperTypes';
import { XUIIconData } from '../icon/XUIIcon';
import { BaseActionMenuItemProps } from './private/BaseActionMenuItemProps';
interface ActionMenuItemProps extends BaseActionMenuItemProps {
    onClick?: React.MouseEventHandler<HTMLButtonElement | HTMLAnchorElement>;
    onKeyDown?: React.KeyboardEventHandler<HTMLButtonElement | HTMLAnchorElement>;
    /**
     * Icon to appear to the left of the menu item label text
     */
    leftIcon?: XUIIconData;
}
type ConditionalProps = {
    isLink: true;
    href?: string;
    to?: never;
} | {
    isLink: true;
    href?: never;
    to?: string;
} | {
    isLink?: false;
    href?: never;
    to?: never;
};
export type XUIActionMenuItemProps = Prettify<ActionMenuItemProps>;
export declare function XUIActionMenuItem({ id, onClick, onKeyDown, onSelect, leftIcon, children, ...props }: ActionMenuItemProps & ConditionalProps): React.JSX.Element;
export default XUIActionMenuItem;

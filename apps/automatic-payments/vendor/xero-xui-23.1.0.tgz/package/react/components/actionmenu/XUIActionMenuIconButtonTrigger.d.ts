import * as React from 'react';
import { Prettify } from '../../helpers/helperTypes';
import XUIIconButton from '../button/XUIIconButton';
type IconButtonProps = Pick<React.ComponentProps<typeof XUIIconButton>, 'ariaLabel' | 'className' | 'icon' | 'iconColor' | 'iconSize' | 'isDisabled' | 'isInverted' | 'onClick' | 'onKeyDown' | 'qaHook' | 'rotation' | 'size'>;
type Props = IconButtonProps & React.ButtonHTMLAttributes<HTMLButtonElement>;
export type XUIActionMenuIconButtonTriggerProps = Prettify<Props>;
declare function XUIActionMenuIconButtonTrigger({ className, onClick, onKeyDown, id, style, ...props }: Props): React.JSX.Element;
export default XUIActionMenuIconButtonTrigger;

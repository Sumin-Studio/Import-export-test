import * as React from 'react';
import XUIButton from '../../button/XUIButton';
import XUIIconButton from '../../button/XUIIconButton';
import { MenuRefs } from './ActionMenuContext';
interface Props {
    currentMenuRef: React.MutableRefObject<MenuRefs>;
    focusedMenuItemId?: string;
    flyoutRef?: React.RefObject<HTMLUListElement>;
    mainTriggerRef?: React.RefObject<XUIIconButton | XUIButton>;
    setContainingMenuOpen?: React.Dispatch<React.SetStateAction<boolean>>;
    setIsFocusVisible: React.Dispatch<React.SetStateAction<boolean>>;
    setIsFlyoutOpen: React.Dispatch<React.SetStateAction<boolean>>;
    setIsMainFlyoutOpen: React.Dispatch<React.SetStateAction<boolean>>;
    setFocusedMenuItemId: React.Dispatch<React.SetStateAction<string | undefined>>;
    parentMenuRefsObject: React.MutableRefObject<MenuRefs>;
}
export default function useActionMenuItemKeyboardEvents({ currentMenuRef, focusedMenuItemId, flyoutRef, mainTriggerRef, setContainingMenuOpen, setFocusedMenuItemId, setIsFocusVisible, setIsFlyoutOpen, setIsMainFlyoutOpen, parentMenuRefsObject, }: Props): {
    handleMenuItemKeyDown: React.KeyboardEventHandler<HTMLButtonElement>;
};
export {};

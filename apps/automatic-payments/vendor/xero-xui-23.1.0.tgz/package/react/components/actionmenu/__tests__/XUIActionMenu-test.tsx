import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import overflowIcon from '@xero/xui-icon/icons/overflow';
import { axe, toHaveNoViolations } from 'jest-axe';
import { nanoid } from 'nanoid';
import React from 'react';

import XUIActionMenu from '../XUIActionMenu';
import XUIActionMenuButtonTrigger from '../XUIActionMenuButtonTrigger';
import XUIActionMenuGroup from '../XUIActionMenuGroup';
import XUIActionMenuIconButtonTrigger from '../XUIActionMenuIconButtonTrigger';
import XUIActionMenuItem from '../XUIActionMenuItem';
import XUIActionMenuItemCheckbox from '../XUIActionMenuItemCheckbox';
import XUIActionMenuItemRadio from '../XUIActionMenuItemRadio';
import XUIActionMenuItems from '../XUIActionMenuItems';
import XUIActionMenuItemWithSubmenu from '../XUIActionMenuItemWithSubmenu';
import XUIActionMenuRadioGroup from '../XUIActionMenuRadioGroup';
import { cleanupTestEnvironment, configureTestEnvironment, createBasicMenu } from './helpers';

jest.mock(
  '../../helpers/Positioning/Positioning',
  () =>
    // eslint-disable-next-line func-names
    function ({ children }: { children: () => React.ReactNode }) {
      return <div data-testid="mocked-positioning">{children()}</div>;
    },
);

expect.extend(toHaveNoViolations);

jest.mock('nanoid');

const mockedNanoId = nanoid as jest.Mock<ReturnType<typeof nanoid>>;
let idIndex = 0;
mockedNanoId.mockImplementation(() => {
  idIndex += 1;
  return `id-${idIndex}`;
});

describe('<XUIActionMenu />', () => {
  test('markup is accessible', async () => {
    const { container } = render(createBasicMenu());
    const results = await axe(container, { elementRef: true });
    expect(results).toHaveNoViolations();
  });

  test('renders expected HTML with an IconButtonTrigger', async () => {
    // Arrange
    const { baseElement } = render(
      <XUIActionMenu>
        <XUIActionMenuIconButtonTrigger ariaLabel="More options" icon={overflowIcon} />
        <XUIActionMenuItems>
          <XUIActionMenuGroup ariaLabel="Options">
            <XUIActionMenuItem>Option one</XUIActionMenuItem>
            <XUIActionMenuItem>Option two</XUIActionMenuItem>
            <XUIActionMenuItem isLink href="https://xui.xero.com">
              Link
            </XUIActionMenuItem>
            <XUIActionMenuItem isLink to="/test">
              Link with to
            </XUIActionMenuItem>
          </XUIActionMenuGroup>
          <XUIActionMenuItemCheckbox>Checkbox one</XUIActionMenuItemCheckbox>
          <XUIActionMenuRadioGroup ariaLabel="Radio options">
            <XUIActionMenuItemRadio isDefaultChecked>Radio one</XUIActionMenuItemRadio>
            <XUIActionMenuItemRadio>Radio two</XUIActionMenuItemRadio>
          </XUIActionMenuRadioGroup>
          <XUIActionMenu>
            <XUIActionMenuItemWithSubmenu>Submenu trigger</XUIActionMenuItemWithSubmenu>
            <XUIActionMenuItems backButtonLabel="Back">
              <XUIActionMenuItem>Submenu option one</XUIActionMenuItem>
              <XUIActionMenuItem>Submenu option two</XUIActionMenuItem>
            </XUIActionMenuItems>
          </XUIActionMenu>
        </XUIActionMenuItems>
      </XUIActionMenu>,
    );

    // Act
    await userEvent.click(screen.getByRole('button', { name: 'More options' }));
    await userEvent.click(screen.getByRole('menuitem', { name: 'Submenu trigger' }));

    // Assert
    expect(baseElement).toMatchSnapshot();
  });

  test('renders expected HTML with a ButtonTrigger', async () => {
    // Arrange
    const { baseElement } = render(
      <XUIActionMenu>
        <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
        <XUIActionMenuItems>
          <XUIActionMenuItem>Option one</XUIActionMenuItem>
          <XUIActionMenuItem>Option two</XUIActionMenuItem>
        </XUIActionMenuItems>
      </XUIActionMenu>,
    );

    // Act
    await userEvent.click(screen.getByRole('button', { name: 'More options' }));

    // Assert
    expect(baseElement).toMatchSnapshot();
  });

  test('on small viewports, renders a back button', async () => {
    configureTestEnvironment();

    // Arrange
    render(
      <XUIActionMenu>
        <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
        <XUIActionMenuItems>
          <XUIActionMenuItem>Option one</XUIActionMenuItem>
          <XUIActionMenu>
            <XUIActionMenuItemWithSubmenu>Submenu trigger</XUIActionMenuItemWithSubmenu>
            <XUIActionMenuItems backButtonLabel="Back">
              <XUIActionMenuItem>Option one</XUIActionMenuItem>
              <XUIActionMenuItem>Option two</XUIActionMenuItem>
            </XUIActionMenuItems>
          </XUIActionMenu>
        </XUIActionMenuItems>
      </XUIActionMenu>,
    );

    // Act
    await userEvent.click(screen.getByRole('button', { name: 'More options' }));
    await userEvent.click(screen.getByRole('menuitem', { name: 'Submenu trigger' }));

    // Assert
    expect(screen.getByRole('menuitem', { name: 'Back' })).toBeInTheDocument();

    cleanupTestEnvironment();
  });

  test('throws an error if a backButtonLabel is not provided when using a submenu', async () => {
    process.env.NODE_ENV = 'development';

    const consoleErrorMock = jest.spyOn(console, 'error').mockImplementation();

    // Arrange
    render(
      <XUIActionMenu>
        <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
        <XUIActionMenuItems>
          <XUIActionMenuItem>Option one</XUIActionMenuItem>
          <XUIActionMenu>
            <XUIActionMenuItemWithSubmenu>Submenu trigger</XUIActionMenuItemWithSubmenu>
            <XUIActionMenuItems>
              <XUIActionMenuItem>Option one</XUIActionMenuItem>
              <XUIActionMenuItem>Option two</XUIActionMenuItem>
            </XUIActionMenuItems>
          </XUIActionMenu>
        </XUIActionMenuItems>
      </XUIActionMenu>,
    );

    expect(consoleErrorMock).toHaveBeenCalledWith(
      'XUIActionMenuItems:  One of the following is required in order to meet WCAG accessibility guidelines: `backButtonLabel` provided',
    );
    consoleErrorMock.mockRestore();
  });

  test('menu is labelled by an aria-label', () => {
    // Arrange
    render(createBasicMenu());

    // Assert
    expect(screen.getByRole('menu')).toHaveAccessibleName('More options');
  });

  describe('<XUIActionMenuIconButtonTrigger />', () => {
    test('trigger has aria-controls corresponding to the menu', () => {
      // Arrange
      render(createBasicMenu());

      // Assert
      expect(screen.getByRole('button', { name: 'More options' })).toHaveAttribute(
        'aria-controls',
        screen.getByRole('menu', { name: 'More options' }).getAttribute('id'),
      );
    });
  });

  describe('<XUIActionMenuButtonTrigger />', () => {
    test('trigger has aria-controls corresponding to the menu', () => {
      // Arrange
      render(createBasicMenu({ triggerType: 'button' }));

      // Assert
      expect(screen.getByRole('button', { name: 'More options' })).toHaveAttribute(
        'aria-controls',
        screen.getByRole('menu', { name: 'More options' }).getAttribute('id'),
      );
    });
  });

  describe('<XUIActionMenuItemRadio />', () => {
    test('Given isDefaultChecked is set then aria-checked is set to true', () => {
      // Arrange
      render(
        <XUIActionMenu>
          <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
          <XUIActionMenuItems>
            <XUIActionMenuRadioGroup ariaLabel="Radio options">
              <XUIActionMenuItemRadio>Option one</XUIActionMenuItemRadio>
              <XUIActionMenuItemRadio isDefaultChecked>Option two</XUIActionMenuItemRadio>
            </XUIActionMenuRadioGroup>
          </XUIActionMenuItems>
        </XUIActionMenu>,
      );

      // Assert
      expect(screen.getByRole('menuitemradio', { name: 'Option one' })).toHaveAttribute(
        'aria-checked',
        'false',
      );
      expect(screen.getByRole('menuitemradio', { name: 'Option two' })).toHaveAttribute(
        'aria-checked',
        'true',
      );
    });

    test('Given controlled radio group and isDefaultChecked is set then it is ignored', () => {
      // Arrange
      const radioOneId = 'radio-1';
      render(
        <XUIActionMenu>
          <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
          <XUIActionMenuItems>
            <XUIActionMenuRadioGroup ariaLabel="Radio options" selectedId={radioOneId}>
              <XUIActionMenuItemRadio id={radioOneId}>Option one</XUIActionMenuItemRadio>
              <XUIActionMenuItemRadio id="radio-2" isDefaultChecked>
                Option two
              </XUIActionMenuItemRadio>
            </XUIActionMenuRadioGroup>
          </XUIActionMenuItems>
        </XUIActionMenu>,
      );

      // Assert
      expect(screen.getByRole('menuitemradio', { name: 'Option one' })).toHaveAttribute(
        'aria-checked',
        'true',
      );
      expect(screen.getByRole('menuitemradio', { name: 'Option two' })).toHaveAttribute(
        'aria-checked',
        'false',
      );
    });
  });
});

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.XUIActionMenuItemWithSubmenu = XUIActionMenuItemWithSubmenu;
exports.default = void 0;
var _arrow = _interopRequireDefault(require("@xero/xui-icon/icons/arrow"));
var _clsx = _interopRequireDefault(require("clsx"));
var _nanoid = require("nanoid");
var React = _interopRequireWildcard(require("react"));
var _reactKeyHandler = require("../helpers/reactKeyHandler");
var _XUIIcon = _interopRequireDefault(require("../icon/XUIIcon"));
var _ActionMenuItemWrapper = require("./private/ActionMenuItemWrapper");
var _constants = require("./private/constants");
var _useActionMenuContext = require("./private/useActionMenuContext");
var _useTriggerClickAndKeyboardEvents = _interopRequireDefault(require("./private/useTriggerClickAndKeyboardEvents"));
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function XUIActionMenuItemWithSubmenu({
  children,
  className,
  id,
  onClick,
  onSelect,
  onKeyDown,
  ...props
}) {
  const {
    isFlyoutOpen,
    handleMenuItemKeyDown
  } = (0, _useActionMenuContext.useActionMenuContext)();
  const {
    composedHandleTriggerClick,
    composedHandleTriggerKeyDown
  } = (0, _useTriggerClickAndKeyboardEvents.default)({
    onClick,
    onKeyDown,
    isSubmenuTrigger: true
  });
  const generatedTriggerId = React.useRef((0, _nanoid.nanoid)());
  const calculatedTriggerId = id || generatedTriggerId.current;
  const composedHandleClick = React.useCallback(event => {
    composedHandleTriggerClick(event);
    onSelect === null || onSelect === void 0 || onSelect(calculatedTriggerId);
  }, [calculatedTriggerId, composedHandleTriggerClick, onSelect]);
  const composedHandleKeyDown = React.useCallback(event => {
    if (event.key === _reactKeyHandler.eventKeyValues.right || event.key === _reactKeyHandler.eventKeyValues.space || event.key === _reactKeyHandler.eventKeyValues.enter) {
      composedHandleTriggerKeyDown(event);
    } else {
      handleMenuItemKeyDown(event);
    }
    onSelect === null || onSelect === void 0 || onSelect(calculatedTriggerId);
  }, [calculatedTriggerId, composedHandleTriggerKeyDown, handleMenuItemKeyDown, onSelect]);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_ActionMenuItemWrapper.ActionMenuItemWrapper, {
    ...props,
    className: (0, _clsx.default)(className, isFlyoutOpen && `${_constants.baseClassName}__menuitem--has-open-flyout`),
    id: calculatedTriggerId,
    onClick: composedHandleClick,
    hasSubmenu: true,
    onKeyDown: composedHandleKeyDown,
    role: "menuitem",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: `${_constants.baseClassName}__menuitem-text`,
      children: children
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: `${_constants.baseClassName}__menuitem-right-caret`,
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_XUIIcon.default, {
        "aria-hidden": "true",
        icon: _arrow.default,
        color: "black-faint",
        rotation: 270
      })
    })]
  });
}
var _default = exports.default = XUIActionMenuItemWithSubmenu;
//# sourceMappingURL=XUIActionMenuItemWithSubmenu.js.map
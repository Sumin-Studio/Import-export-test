"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.XUIActionMenuGroup = XUIActionMenuGroup;
exports.default = void 0;
var _clsx = _interopRequireDefault(require("clsx"));
var React = _interopRequireWildcard(require("react"));
var _labelRequiredError = _interopRequireDefault(require("../helpers/labelRequiredError"));
var _constants = require("./private/constants");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function XUIActionMenuGroup({
  ariaLabel,
  ariaLabelledBy,
  children,
  className,
  ...props
}) {
  const ariaAttributes = ariaLabelledBy ? {
    'aria-labelledby': ariaLabelledBy
  } : {
    'aria-label': ariaLabel
  };
  React.useEffect(() => {
    (0, _labelRequiredError.default)(XUIActionMenuGroup.name, ['`ariaLabel` or `ariaLabelledBy` provided'], [Boolean(ariaLabel || ariaLabelledBy)]);
  }, [ariaLabel, ariaLabelledBy]);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
    role: "none",
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
      ...props,
      role: "group",
      className: (0, _clsx.default)(`${_constants.baseClassName}__group`, className),
      ...ariaAttributes,
      children: children
    })
  });
}
var _default = exports.default = XUIActionMenuGroup;
//# sourceMappingURL=XUIActionMenuGroup.js.map
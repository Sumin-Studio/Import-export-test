"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _clsx = _interopRequireDefault(require("clsx"));
var _nanoid = require("nanoid");
var React = _interopRequireWildcard(require("react"));
var _breakpoints = _interopRequireDefault(require("../helpers/breakpoints"));
var _combineRefs = _interopRequireDefault(require("../helpers/combineRefs"));
var _getTriggerElementRef = _interopRequireDefault(require("../helpers/getTriggerElementRef"));
var _labelRequiredError = _interopRequireDefault(require("../helpers/labelRequiredError"));
var _lockScroll = require("../helpers/lockScroll");
var _portalContainer = _interopRequireDefault(require("../helpers/portalContainer"));
var _Positioning = _interopRequireDefault(require("../helpers/Positioning/Positioning"));
var _useResizeObserver = _interopRequireDefault(require("../helpers/useResizeObserver"));
var _xuiClassNamespace = require("../helpers/xuiClassNamespace");
var _ActionMenuMobileBackMenuItem = _interopRequireDefault(require("./private/ActionMenuMobileBackMenuItem"));
var _constants = require("./private/constants");
var _useActionMenuContext = require("./private/useActionMenuContext");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function XUIActionMenuItems({
  backButtonLabel,
  children,
  className,
  onBackButtonSelect,
  qaHook,
  ...spreadProps
}) {
  const {
    setFlyoutId,
    isFlyoutOpen,
    flyoutRef,
    focusedMenuItemId,
    isFocusVisible,
    isMainFlyoutOpen,
    isParentMenu,
    menuRefsRef,
    positionedElementAttributes,
    preferredFlyoutPosition
  } = (0, _useActionMenuContext.useActionMenuContext)();
  const {
    style,
    id
  } = spreadProps;
  const {
    observedElementRef
  } = (0, _useResizeObserver.default)();
  const combinedRef = (0, _combineRefs.default)(flyoutRef, observedElementRef);
  const generatedMenuId = React.useRef((0, _nanoid.nanoid)());
  const triggerId = React.useRef();
  const flyoutId = id || generatedMenuId.current;
  const backButtonId = `${flyoutId}--back-button`;
  const [isBelowSmallBreakpoint, setIsBelowSmallBreakpoint] = React.useState(window.innerWidth < _breakpoints.default.small);
  const menuClasses = (0, _clsx.default)(className, `${_constants.baseClassName}__flyout`, `${_constants.baseClassName}__flyout--large`, isFlyoutOpen && `${_constants.baseClassName}__flyout--is-open`);
  React.useEffect(() => {
    setFlyoutId(flyoutId);
  }, [setFlyoutId, flyoutId]);
  React.useEffect(function watchWindowBreakpoints() {
    function trackBreakpoint() {
      if (window.innerWidth < _breakpoints.default.small) {
        setIsBelowSmallBreakpoint(true);
      } else {
        setIsBelowSmallBreakpoint(false);
      }
    }
    window.addEventListener('resize', trackBreakpoint);
    return function cleanup() {
      window.removeEventListener('resize', trackBreakpoint);
    };
  }, [menuRefsRef]);
  React.useEffect(() => {
    if (isParentMenu) return;
    (0, _labelRequiredError.default)(XUIActionMenuItems.name, ['`backButtonLabel` provided'], [Boolean(!isParentMenu && backButtonLabel)]);
  }, [isParentMenu, backButtonLabel]);
  React.useEffect(function lockScrollIfBelowSmallBreakpoint() {
    if (!isParentMenu) return undefined;
    if (isBelowSmallBreakpoint && isMainFlyoutOpen) {
      (0, _lockScroll.lockScroll)();
    } else {
      (0, _lockScroll.unlockScroll)();
    }
    return () => (0, _lockScroll.unlockScroll)();
  }, [isBelowSmallBreakpoint, isMainFlyoutOpen, isParentMenu]);
  React.useEffect(() => {
    var _menuRefsRef$current$;
    if ((_menuRefsRef$current$ = menuRefsRef.current.triggerRef) !== null && _menuRefsRef$current$ !== void 0 && _menuRefsRef$current$.current) {
      var _menuRefsRef$current$2;
      const triggerNode = (0, _getTriggerElementRef.default)((_menuRefsRef$current$2 = menuRefsRef.current.triggerRef) === null || _menuRefsRef$current$2 === void 0 ? void 0 : _menuRefsRef$current$2.current).current;
      triggerId.current = (triggerNode === null || triggerNode === void 0 ? void 0 : triggerNode.getAttribute('id')) || undefined;
    }
  }, [menuRefsRef]);
  const memoisedBackButtonTabIndex = React.useMemo(() => focusedMenuItemId === backButtonId ? 0 : -1, [backButtonId, focusedMenuItemId]);
  const componentToRender = /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: (0, _clsx.default)(`${_xuiClassNamespace.ns}-action-menu-overlay`, !isFlyoutOpen && `${_xuiClassNamespace.ns}-action-menu-overlay--hidden`)
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("ul", {
      "aria-labelledby": triggerId.current,
      "aria-orientation": "vertical",
      className: menuClasses,
      "data-automationid": qaHook,
      role: "menu",
      ref: combinedRef,
      ...spreadProps,
      id: flyoutId,
      ...positionedElementAttributes,
      style: isBelowSmallBreakpoint ? {} : {
        ...(positionedElementAttributes === null || positionedElementAttributes === void 0 ? void 0 : positionedElementAttributes.style),
        '--trigger-gap': !isParentMenu ? _constants.submenuFlyoutGap : _constants.triggerFlyoutGap,
        ...style
      },
      children: [!isParentMenu && isBelowSmallBreakpoint && /*#__PURE__*/(0, _jsxRuntime.jsx)(_ActionMenuMobileBackMenuItem.default, {
        className: (0, _clsx.default)(`${_constants.baseClassName}__menuitem`, backButtonId === focusedMenuItemId && `${_constants.baseClassName}__menuitem--is-focused`, isFocusVisible && `${_constants.baseClassName}__menuitem--focus-is-visible`),
        id: backButtonId,
        isBelowSmallBreakpoint: isBelowSmallBreakpoint,
        onSelect: onBackButtonSelect,
        qaHook: qaHook && `${qaHook}--back-button`,
        tabIndex: memoisedBackButtonTabIndex,
        children: backButtonLabel
      }), children]
    })]
  });
  if (isParentMenu || !isBelowSmallBreakpoint) {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)(_Positioning.default, {
      isPositioningDisabled: isBelowSmallBreakpoint,
      maxWidth: -1,
      pageGutter: _constants.triggerFlyoutGap,
      portalNode: (0, _portalContainer.default)(),
      positionInViewport: true,
      preferredLocation: preferredFlyoutPosition,
      preferredLocationFallbacks: isParentMenu ? _constants.preferredFlyoutPositionFallbacks : _constants.preferredSubmenuPositionFallbacks,
      shouldRestrictMaxHeight: true,
      triggerGap: isParentMenu ? _constants.triggerFlyoutGap : _constants.submenuFlyoutGap,
      triggerRef: (0, _getTriggerElementRef.default)(menuRefsRef.current.triggerRef),
      children: () => /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        children: componentToRender
      })
    });
  }
  return componentToRender;
}
var _default = exports.default = XUIActionMenuItems;
//# sourceMappingURL=XUIActionMenuItems.js.map
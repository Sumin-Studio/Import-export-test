"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.XUIActionMenuRadioGroup = XUIActionMenuRadioGroup;
exports.default = void 0;
var React = _interopRequireWildcard(require("react"));
var _ActionMenuRadioGroupContext = _interopRequireDefault(require("./private/ActionMenuRadioGroupContext"));
var _XUIActionMenuGroup = _interopRequireDefault(require("./XUIActionMenuGroup"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function XUIActionMenuRadioGroup({
  children,
  selectedId: providedSelectedId,
  ...props
}) {
  const [selectedId, setSelectedId] = React.useState();
  const contextValue = React.useMemo(() => ({
    selectedId: providedSelectedId || selectedId,
    setSelectedId
  }), [providedSelectedId, selectedId, setSelectedId]);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_ActionMenuRadioGroupContext.default.Provider, {
    value: contextValue,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_XUIActionMenuGroup.default, {
      ...props,
      children: children
    })
  });
}
var _default = exports.default = XUIActionMenuRadioGroup;
//# sourceMappingURL=XUIActionMenuRadioGroup.js.map
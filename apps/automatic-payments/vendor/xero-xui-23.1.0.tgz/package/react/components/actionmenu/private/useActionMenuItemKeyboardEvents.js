"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = useActionMenuItemKeyboardEvents;
require("core-js/modules/es.array.includes.js");
var React = _interopRequireWildcard(require("react"));
var _getNextFocusableElement = _interopRequireDefault(require("../../helpers/getNextFocusableElement"));
var _getPreviousFocusableElement = _interopRequireDefault(require("../../helpers/getPreviousFocusableElement"));
var _getTriggerElementRef = _interopRequireDefault(require("../../helpers/getTriggerElementRef"));
var _reactKeyHandler = require("../../helpers/reactKeyHandler");
var _constants = require("./constants");
var _helpers = require("./helpers");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function useActionMenuItemKeyboardEvents({
  currentMenuRef,
  focusedMenuItemId,
  flyoutRef,
  mainTriggerRef,
  setContainingMenuOpen,
  setFocusedMenuItemId,
  setIsFocusVisible,
  setIsFlyoutOpen,
  setIsMainFlyoutOpen,
  parentMenuRefsObject
}) {
  const getNodeToFocus = React.useCallback(function findNode(menuObject, keyValue) {
    if (!focusedMenuItemId) {
      return null;
    }
    const menuRefInfo = (0, _helpers.getMenuItemRefIndexFromId)(menuObject, focusedMenuItemId);
    if (!menuRefInfo) {
      return null;
    }
    const {
      idx,
      currentMenu
    } = menuRefInfo;
    let nodeToReturn;
    switch (keyValue) {
      case _reactKeyHandler.eventKeyValues.up:
        nodeToReturn = (0, _helpers.getNodeFromRef)(currentMenu.menuitems[Math.max(idx - 1, 0)]);
        break;
      case _reactKeyHandler.eventKeyValues.down:
        nodeToReturn = (0, _helpers.getNodeFromRef)(currentMenu.menuitems[Math.min(idx + 1, currentMenu.menuitems.length - 1)]);
        break;
      case _reactKeyHandler.eventKeyValues.left:
        if (currentMenu.isSubmenu) {
          nodeToReturn = (0, _helpers.getNodeFromRef)(currentMenu.triggerRef);
        }
        break;
      case _reactKeyHandler.eventKeyValues.escape:
        nodeToReturn = (0, _helpers.getNodeFromRef)(currentMenu.triggerRef);
        break;
      case _reactKeyHandler.eventKeyValues.end:
        nodeToReturn = (0, _helpers.getNodeFromRef)(currentMenu.menuitems[currentMenu.menuitems.length - 1]);
        break;
      case _reactKeyHandler.eventKeyValues.home:
        nodeToReturn = (0, _helpers.getNodeFromRef)(currentMenu.menuitems[0]);
        break;
      case _reactKeyHandler.eventKeyValues.space:
      case _reactKeyHandler.eventKeyValues.enter:
        nodeToReturn = (0, _helpers.getNodeFromRef)(mainTriggerRef);
        break;
      default:
        break;
    }
    return nodeToReturn;
  }, [focusedMenuItemId, mainTriggerRef]);
  const handleMenuItemKeyDown = React.useCallback(event => {
    event.preventDefault();
    if (event.key === _reactKeyHandler.eventKeyValues.tab) {
      setIsMainFlyoutOpen(false);
      setFocusedMenuItemId(prevId => {
        if (prevId) {
          const currentMenuNode = (0, _helpers.findMenuItemNodeFromId)(currentMenuRef.current, prevId);
          currentMenuNode === null || currentMenuNode === void 0 || currentMenuNode.setAttribute('tabindex', '-1');
          currentMenuNode === null || currentMenuNode === void 0 || currentMenuNode.blur();
        }
        return undefined;
      });
      setIsFocusVisible(false);
      if (!mainTriggerRef) return;
      const parentTriggerElement = (0, _getTriggerElementRef.default)(mainTriggerRef).current;
      if (!parentTriggerElement) return;
      if (event.shiftKey) {
        var _getPreviousFocusable;
        (_getPreviousFocusable = (0, _getPreviousFocusableElement.default)(parentTriggerElement)) === null || _getPreviousFocusable === void 0 || _getPreviousFocusable.focus();
      } else {
        const nextElement = (0, _getNextFocusableElement.default)(parentTriggerElement, element => {
          var _flyoutRef$current;
          return !parentTriggerElement.contains(element) && !(flyoutRef !== null && flyoutRef !== void 0 && (_flyoutRef$current = flyoutRef.current) !== null && _flyoutRef$current !== void 0 && _flyoutRef$current.contains(element));
        });
        nextElement === null || nextElement === void 0 || nextElement.focus();
      }
      return;
    }
    const nodeToFocus = getNodeToFocus(parentMenuRefsObject.current, event.key);
    if (event.key === _reactKeyHandler.eventKeyValues.left && nodeToFocus || event.key === _reactKeyHandler.eventKeyValues.escape) {
      event.nativeEvent.stopImmediatePropagation();
      if (event.target.getAttribute('aria-haspopup') && setContainingMenuOpen) {
        setContainingMenuOpen(false);
      } else {
        setIsFlyoutOpen(false);
      }
    }
    if (_constants.focusVisibleKeys.includes(event.key)) {
      setIsFocusVisible(true);
    }
    if (nodeToFocus) {
      setFocusedMenuItemId(nodeToFocus.getAttribute('id'));
      nodeToFocus.focus();
    }
  }, [getNodeToFocus, flyoutRef, parentMenuRefsObject, mainTriggerRef, setIsMainFlyoutOpen, setFocusedMenuItemId, setIsFocusVisible, currentMenuRef, setContainingMenuOpen, setIsFlyoutOpen]);
  return {
    handleMenuItemKeyDown
  };
}
//# sourceMappingURL=useActionMenuItemKeyboardEvents.js.map
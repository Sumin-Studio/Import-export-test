import * as React from 'react';
import { Prettify } from '../../helpers/helperTypes';
interface Props {
    /**
     * The `aria-label` for the group. This must be set if not using `XUIActionMenuHeading` for a visible label.
     * Use concise wording which describes the group
     */
    ariaLabel?: string;
    /**
     * If there is a `XUIActionMenuHeading` for the group, then this must be set to the `id` of that heading
     * to associate them
     */
    ariaLabelledBy?: string;
    /**
     * Valid children are `XUIActionMenuItemCheckbox` and `XUIActionMenuItem`
     */
    children: React.ReactNode;
    /**
     * Additional classes to apply to the group
     */
    className?: string;
}
type SpreadProps = React.HTMLAttributes<HTMLUListElement>;
type ActionMenuGroupProps = Props & SpreadProps;
export type XUIActionMenuGroupProps = Prettify<ActionMenuGroupProps>;
export declare function XUIActionMenuGroup({ ariaLabel, ariaLabelledBy, children, className, ...props }: ActionMenuGroupProps): React.JSX.Element;
export default XUIActionMenuGroup;

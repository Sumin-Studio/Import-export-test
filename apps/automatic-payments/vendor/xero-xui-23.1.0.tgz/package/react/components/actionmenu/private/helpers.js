"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findMenuItemNodeFromId = findMenuItemNodeFromId;
exports.getMenuItemRefIndexFromId = getMenuItemRefIndexFromId;
exports.getNodeFromRef = getNodeFromRef;
exports.isSubmenuRef = isSubmenuRef;
var _XUIButton = _interopRequireDefault(require("../../button/XUIButton"));
var _XUIIconButton = _interopRequireDefault(require("../../button/XUIIconButton"));
var _getTriggerElementRef = _interopRequireDefault(require("../../helpers/getTriggerElementRef"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Returns the DOM node given a ref to either a trigger or a menuitem
function getNodeFromRef(menuItemRef) {
  if (!menuItemRef || !menuItemRef.current) {
    return undefined;
  }
  const menuItem = menuItemRef.current;
  if (menuItem instanceof HTMLButtonElement || menuItem instanceof HTMLAnchorElement) return menuItem;
  let currentElement;
  if (menuItem instanceof _XUIButton.default || menuItem instanceof _XUIIconButton.default) {
    currentElement = (0, _getTriggerElementRef.default)(menuItem).current;
  } else if (menuItem.triggerRef) {
    currentElement = (0, _getTriggerElementRef.default)(menuItem.triggerRef).current;
  }
  return currentElement;
}
function findMenuItemNodeFromId(menuObject, id) {
  for (let i = 0; i < menuObject.menuitems.length; i += 1) {
    const currentElement = getNodeFromRef(menuObject.menuitems[i]);
    if ((currentElement === null || currentElement === void 0 ? void 0 : currentElement.getAttribute('id')) === id) {
      return currentElement;
    }
  }
  return undefined;
}
function getMenuItemRefIndexFromId(menuObject, id) {
  for (let i = 0; i < menuObject.menuitems.length; i += 1) {
    const currentMenuItemRef = menuObject.menuitems[i];
    const currentElement = getNodeFromRef(currentMenuItemRef);
    if ((currentElement === null || currentElement === void 0 ? void 0 : currentElement.getAttribute('id')) === id) {
      return {
        idx: i,
        currentMenu: menuObject
      };
    }
    if (isSubmenuRef(currentMenuItemRef.current)) {
      const result = getMenuItemRefIndexFromId(currentMenuItemRef.current, id);
      if (result !== undefined) return result;
    }
  }
  return undefined;
}
function isSubmenuRef(obj) {
  return obj && Array.isArray(obj.menuitems);
}
//# sourceMappingURL=helpers.js.map
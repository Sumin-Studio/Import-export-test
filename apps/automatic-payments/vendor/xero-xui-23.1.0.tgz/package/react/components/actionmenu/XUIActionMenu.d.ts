import * as React from 'react';
import { Prettify } from '../../helpers/helperTypes';
import { AnchorSide } from '../helpers/Positioning/helpers/positioning';
interface ActionMenuProps {
    /**
     * At minimum, a `XUIActionMenuButtonTrigger` or `XUIActionMenuIconButtonTrigger`
     * and `XUIActionMenuItems` are expected
     */
    children: React.ReactNode;
    /**
     * Can be used to control the flyout’s open state
     */
    isOpen?: boolean;
    /**
     * Callback executed when the user clicks outside the action menu
     */
    onClickOutside?: () => void;
    /**
     * Callback for when the flyout closes
     */
    onClose?: () => void;
    /**
     * The position of the flyout in relation to the trigger.
     * By default, the main flyout will try to align itself to the bottom left of the trigger.
     * By default, a submenu flyout will try to align itself to the right top of the trigger
     */
    preferredFlyoutPosition?: AnchorSide;
}
export type XUIActionMenuProps = Prettify<ActionMenuProps>;
export declare function XUIActionMenu({ children, isOpen: providedIsOpen, onClickOutside, onClose, preferredFlyoutPosition, }: ActionMenuProps): React.JSX.Element;
export default XUIActionMenu;

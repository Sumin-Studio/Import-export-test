import * as React from 'react';
import { Prettify } from '../../helpers/helperTypes';
import { XUIActionMenuItemProps } from './XUIActionMenuItem';
export type XUIActionMenuItemWithSubmenuProps = Prettify<XUIActionMenuItemProps>;
export declare function XUIActionMenuItemWithSubmenu({ children, className, id, onClick, onSelect, onKeyDown, ...props }: XUIActionMenuItemProps): React.JSX.Element;
export default XUIActionMenuItemWithSubmenu;

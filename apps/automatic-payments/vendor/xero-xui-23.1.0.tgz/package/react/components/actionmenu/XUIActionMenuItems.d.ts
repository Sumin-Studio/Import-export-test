import * as React from 'react';
import { Prettify } from '../../helpers/helperTypes';
interface BaseProps {
    /**
     * The label text shown alongside the back button in submenus on narrow viewports.
     * Must be set when using submenus
     */
    backButtonLabel?: string;
    /**
     * Valid children are: `XUIActionMenu`, `XUIActionMenuItem`, `XUIActionMenuGroup`, `XUIActionMenuItemCheckbox`,
     * `XUIActionMenuRadioGroup`, `XUIActionMenuSeparator`, `XUIActionMenuHeading`
     */
    children: React.ReactNode;
    /**
     * Additional classes to apply to the menu items
     */
    className?: string;
    /**
     * Callback for when the user selects the back button shown in submenus on narrow viewports
     */
    onBackButtonSelect?: () => void;
    /**
     * Adds a `data-automationid` attribute to the element.
     * The `data-automationid` attribute of the back button shown in submenus on narrow viewports
     * will be set to this value, suffixed with `--back-button`
     */
    qaHook?: string;
}
type SpreadProps = React.HTMLAttributes<HTMLUListElement>;
type Props = BaseProps & SpreadProps;
export type XUIActionMenuItemsProps = Prettify<Props>;
declare function XUIActionMenuItems({ backButtonLabel, children, className, onBackButtonSelect, qaHook, ...spreadProps }: Props): React.JSX.Element;
export default XUIActionMenuItems;

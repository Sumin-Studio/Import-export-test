<div class="xui-margin-vertical">
    <a href="../section-components-controls-actionmenu.html"  isDocLink>Action menu in the XUI documentation</a>
</div>

## Anatomy

- **Trigger**: The trigger is a button that either contains an icon, text label, or both. The button label is static and must describe the content in the flyout. When the trigger is selected, it shows the flyout
- **Flyout**: The flyout contains a list of items which may be grouped. When an item is selected it performs an action on the page. There are three main types of items:
  - Menu item: A menu item can have one of two functions:
    1. Performs an action and does not hold state
    1. To open a **submenu**
  - **Menu item checkbox**: Works the same as a standard checkbox. It is a selection with a toggle and holds state
  - **Menu item radio**: Like a traditional radio button group, menu item radios are used to choose a single item from a group of related items
- **Submenu**: A submenu is a nested menu that is part of a parent action menu

## When to use

- To perform an action on the current page
- To provide users with options for initiating actions to interact with the page content. For example: “Edit“ or “Export as PDF”
- When there are space constraints in the layout

## How to use

There are several components provided to build out your action menu with flexibility and ease. The outermost component is `XUIActionMenu`, which must wrap the other components.

For the trigger, a `XUIActionMenuIconButtonTrigger` or `XUIActionMenuButtonTrigger` is required.

For the flyout, a `XUIMenuItems` component is required. This should contain a `XUIMenuItem` for each action a user can perform, a `XUIMenuItemCheckbox` for each action a user can toggle, or a `XUIMenuItemRadioGroup` containing `XUIActionMenuItemRadio`s.

The flyout can also contain `XUIMenuItemGroup`s to group related sets of menu items.

## Examples

### With icon button trigger

Uses `XUIActionMenuIconButtonTrigger` as the first child of `XUIActionMenu` for the trigger. `XUIActionMenuItems` wraps the list of `XUIActionMenuItem`s to form the flyout with items.

```jsx harmony
import {
  XUIActionMenuIconButtonTrigger,
  XUIActionMenuItems,
  XUIActionMenu,
  XUIActionMenuItem
} from '@xero/xui/react/actionmenu';

import overflowIcon from '@xero/xui-icon/icons/overflow';

const onSelect = () => console.log('onSelect');

const Example = () => (
  <XUIActionMenu>
    <XUIActionMenuIconButtonTrigger ariaLabel="More options" icon={overflowIcon} />
    <XUIActionMenuItems>
      <XUIActionMenuItem onSelect={onSelect}>Edit transactions</XUIActionMenuItem>
      <XUIActionMenuItem onSelect={onSelect}>Approve all</XUIActionMenuItem>
      <XUIActionMenuItem onSelect={onSelect}>Decline all</XUIActionMenuItem>
      <XUIActionMenuItem onSelect={onSelect}>Delete all</XUIActionMenuItem>
    </XUIActionMenuItems>
  </XUIActionMenu>
);

<Example />;
```

### With button trigger

Uses `XUIActionMenuButtonTrigger` as the first child of `XUIActionMenu` for the trigger. `XUIActionMenuButtonTrigger` accepts some of the same props as [XUIButton](#button), so can support different variants and include left or right aligned icons.
`XUIActionMenuItems` wraps the `XUIActionMenuItem`s to form the flyout with items.

```jsx harmony
import {
  XUIActionMenuButtonTrigger,
  XUIActionMenuItems,
  XUIActionMenu,
  XUIActionMenuItem
} from '@xero/xui/react/actionmenu';

const onSelect = () => console.log('onSelect');

const Example = () => (
  <XUIActionMenu>
    <XUIActionMenuButtonTrigger>Actions</XUIActionMenuButtonTrigger>
    <XUIActionMenuItems>
      <XUIActionMenuItem onSelect={onSelect}>Edit transactions</XUIActionMenuItem>
      <XUIActionMenuItem onSelect={onSelect}>Approve all</XUIActionMenuItem>
      <XUIActionMenuItem onSelect={onSelect}>Decline all</XUIActionMenuItem>
      <XUIActionMenuItem onSelect={onSelect}>Delete all</XUIActionMenuItem>
    </XUIActionMenuItems>
  </XUIActionMenu>
);

<Example />;
```

### Menu item checkbox (uncontrolled)

Uses `XUIActionMenuItemCheckbox` components as the children of the `XUIActionMenuItems`. Menu item checkboxes can be used on their own, grouped, or with other item types.

```jsx harmony
import {
  XUIActionMenuIconButtonTrigger,
  XUIActionMenuItems,
  XUIActionMenu,
  XUIActionMenuItemCheckbox
} from '@xero/xui/react/actionmenu';

import filterIcon from '@xero/xui-icon/icons/filter';

const onSelect = () => console.log('onSelect');

const Example = () => (
  <XUIActionMenu>
    <XUIActionMenuIconButtonTrigger ariaLabel="Filter" icon={filterIcon} />
    <XUIActionMenuItems>
      <XUIActionMenuItemCheckbox onSelect={onSelect}>View archived</XUIActionMenuItemCheckbox>
      <XUIActionMenuItemCheckbox onSelect={onSelect}>View new</XUIActionMenuItemCheckbox>
    </XUIActionMenuItems>
  </XUIActionMenu>
);

<Example />;
```

### Menu item checkbox (controlled)

Uses `XUIActionMenuItemCheckbox` as a child of `XUIActionMenuItems` and controls the checked state. Menu item checkboxes can be used on their own, grouped, or with other item types.

```jsx harmony
import {
  XUIActionMenuIconButtonTrigger,
  XUIActionMenuItem,
  XUIActionMenuItems,
  XUIActionMenu,
  XUIActionMenuItemCheckbox
} from '@xero/xui/react/actionmenu';

import filterIcon from '@xero/xui-icon/icons/filter';

const ControlledCheckbox = () => {
  const [isChecked, setIsChecked] = React.useState(false);

  const handleOnSelect = React.useCallback(
    event => {
      setIsChecked(checked => !checked);
    },
    [setIsChecked]
  );

  return (
    <XUIActionMenuItemCheckbox isChecked={isChecked} onSelect={handleOnSelect}>
      View new
    </XUIActionMenuItemCheckbox>
  );
};

const Example = () => (
  <XUIActionMenu>
    <XUIActionMenuIconButtonTrigger ariaLabel="More options" icon={filterIcon} />
    <XUIActionMenuItems>
      <XUIActionMenuItemCheckbox>View archived</XUIActionMenuItemCheckbox>
      <ControlledCheckbox />
    </XUIActionMenuItems>
  </XUIActionMenu>
);

<Example />;
```

### Menu item radio (uncontrolled)

Uses `XUIActionMenuRadioGroup` to wrap all `XUIActionMenuItemRadio`s in the `XUIActionMenuItems`. To set which `XUIActionMenuItemRadio` is checked by default use `isDefaultChecked`.

```jsx harmony
import {
  XUIActionMenu,
  XUIActionMenuButtonTrigger,
  XUIActionMenuItemRadio,
  XUIActionMenuItems,
  XUIActionMenuRadioGroup
} from '@xero/xui/react/actionmenu';

const onSelect = () => console.log('onSelect');

const Example = () => (
  <XUIActionMenu>
    <XUIActionMenuButtonTrigger>Sort</XUIActionMenuButtonTrigger>
    <XUIActionMenuItems>
      <XUIActionMenuRadioGroup ariaLabel="Order">
        <XUIActionMenuItemRadio isDefaultChecked onSelect={onSelect}>
          Ascending
        </XUIActionMenuItemRadio>
        <XUIActionMenuItemRadio onSelect={onSelect}>Descending</XUIActionMenuItemRadio>
      </XUIActionMenuRadioGroup>
    </XUIActionMenuItems>
  </XUIActionMenu>
);

<Example />;
```

### Menu item radio (controlled)

Uses `XUIActionMenuRadioGroup` to wrap all `XUIActionMenuItemRadio`s in the `XUIActionMenuItems`. The selected radio state is passed to the `XUIActionMenuRadioGroup` and each `XUIActionMenuItemRadio` updates the state when selected.

```jsx harmony
import {
  XUIActionMenuButtonTrigger,
  XUIActionMenuItems,
  XUIActionMenu,
  XUIActionMenuRadioGroup,
  XUIActionMenuItemRadio
} from '@xero/xui/react/actionmenu';
import React from 'react';

import overflowIcon from '@xero/xui-icon/icons/overflow';

const ControlledRadio = () => {
  const [selectedId, setSelectedId] = React.useState('radio-1');

  const radios = [
    { id: 'radio-1', content: 'Ascending' },
    { id: 'radio-2', content: 'Descending' }
  ];

  return (
    <XUIActionMenuRadioGroup ariaLabel="Order" selectedId={selectedId}>
      {radios.map(radio => (
        <XUIActionMenuItemRadio
          key={radio.id}
          id={radio.id}
          onSelect={() => setSelectedId(radio.id)}
        >
          {radio.content}
        </XUIActionMenuItemRadio>
      ))}
    </XUIActionMenuRadioGroup>
  );
};

const Example = () => (
  <XUIActionMenu>
    <XUIActionMenuButtonTrigger>Sort</XUIActionMenuButtonTrigger>
    <XUIActionMenuItems>
      <ControlledRadio />
    </XUIActionMenuItems>
  </XUIActionMenu>
);

<Example />;
```

### Submenus

To create a submenu, you build a `XUIActionMenu` as a child of the root `XUIActionMenu`’s `XUIActionMenuItems`. Inside this nested `XUIActionMenu` the first child must be a `XUIActionMenuItemWithSubmenu`, which is the menu item that functions as the trigger for the submenu. The second child of the submenu is a `XUIActionMenuItems` component with `XUIActionMenuItem` children. You must provide a `backButtonLabel` on the `XUIActionMenuItems` for the submenu.

```jsx harmony
import {
  XUIActionMenu,
  XUIActionMenuButtonTrigger,
  XUIActionMenuItems,
  XUIActionMenuItemCheckbox,
  XUIActionMenuItemWithSubmenu
} from '@xero/xui/react/actionmenu';

import overflowIcon from '@xero/xui-icon/icons/overflow';

const onSelect = () => console.log('onSelect');

const Example = () => (
  <XUIActionMenu>
    <XUIActionMenuButtonTrigger>Filter</XUIActionMenuButtonTrigger>
    <XUIActionMenuItems>
      <XUIActionMenuItemCheckbox onSelect={onSelect}>Deleted and voided</XUIActionMenuItemCheckbox>
      <XUIActionMenuItemCheckbox onSelect={onSelect}>Overdue</XUIActionMenuItemCheckbox>
      <XUIActionMenu>
        <XUIActionMenuItemWithSubmenu>Document type</XUIActionMenuItemWithSubmenu>
        <XUIActionMenuItems backButtonLabel="Back">
          <XUIActionMenuItemCheckbox onSelect={onSelect}>Bills</XUIActionMenuItemCheckbox>
          <XUIActionMenuItemCheckbox onSelect={onSelect}>Credit notes</XUIActionMenuItemCheckbox>
          <XUIActionMenuItemCheckbox onSelect={onSelect}>Prepayments</XUIActionMenuItemCheckbox>
          <XUIActionMenuItemCheckbox onSelect={onSelect}>Overpayments</XUIActionMenuItemCheckbox>
        </XUIActionMenuItems>
      </XUIActionMenu>
    </XUIActionMenuItems>
  </XUIActionMenu>
);

<Example />;
```

### Grouping

Groups are made using a `XUIActionMenuGroup` or `XUIActionMenuRadioGroup` as the child of a `XUIActionMenuItems`.
A `XUIActionMenuGroup` can be used to group `XUIActionMenuItems` and `XUIActionMenuItemCheckbox`es. A `XUIActionMenuRadioGroup` is required when using `XUIActionMenuItemRadio`s to group them.
To visually separate groups, you can use a `XUIMenuItemSeparator` and/or a `XUIActionMenuHeading` to label the set.

```jsx harmony
import {
  XUIActionMenu,
  XUIActionMenuIconButtonTrigger,
  XUIActionMenuItems,
  XUIActionMenuItem,
  XUIActionMenuGroup,
  XUIActionMenuRadioGroup,
  XUIActionMenuItemRadio,
  XUIActionMenuSeparator,
  XUIActionMenuHeading
} from '@xero/xui/react/actionmenu';

import overflowIcon from '@xero/xui-icon/icons/overflow';

const Example = () => (
  <XUIActionMenu>
    <XUIActionMenuIconButtonTrigger ariaLabel="More options" icon={overflowIcon} />
    <XUIActionMenuItems>
      <XUIActionMenuHeading id="heading-1">Status</XUIActionMenuHeading>
      <XUIActionMenuRadioGroup ariaLabelledBy="heading-1">
        <XUIActionMenuItemRadio isDefaultChecked>Draft</XUIActionMenuItemRadio>
        <XUIActionMenuItemRadio>In progress</XUIActionMenuItemRadio>
        <XUIActionMenuItemRadio>Closed</XUIActionMenuItemRadio>
      </XUIActionMenuRadioGroup>

      <XUIActionMenuSeparator />

      <XUIActionMenuGroup ariaLabel="Manage project">
        <XUIActionMenuItem>Edit</XUIActionMenuItem>
        <XUIActionMenuItem>Duplicate</XUIActionMenuItem>
        <XUIActionMenuItem>Delete</XUIActionMenuItem>
      </XUIActionMenuGroup>
    </XUIActionMenuItems>
  </XUIActionMenu>
);

<Example />;
```

### Icons in menu items

Add an icon to `XUIActionMenuItem` with `leftIcon`.

```jsx harmony
import {
  XUIActionMenuIconButtonTrigger,
  XUIActionMenuItems,
  XUIActionMenu,
  XUIActionMenuItem
} from '@xero/xui/react/actionmenu';

import { checkboxCheckIcon, commentIcon, editIcon, overflowIcon, trashIcon } from '@xero/xui-icon';

const Example = () => (
  <XUIActionMenu>
    <XUIActionMenuIconButtonTrigger ariaLabel="More options" icon={overflowIcon} />
    <XUIActionMenuItems>
      <XUIActionMenuItem leftIcon={editIcon}>Edit transactions</XUIActionMenuItem>
      <XUIActionMenuItem leftIcon={checkboxCheckIcon}>Approve all</XUIActionMenuItem>
      <XUIActionMenuItem leftIcon={trashIcon}>Delete all</XUIActionMenuItem>
    </XUIActionMenuItems>
  </XUIActionMenu>
);

<Example />;
```

### With controlled menu

```jsx harmony
import {
  XUIActionMenuIconButtonTrigger,
  XUIActionMenuItems,
  XUIActionMenu,
  XUIActionMenuItem
} from '@xero/xui/react/actionmenu';
import React from 'react';

import overflowIcon from '@xero/xui-icon/icons/overflow';

const Example = () => {
  const [isOpen, setIsOpen] = React.useState(false);

  const closeFlyout = React.useCallback(() => {
    setIsOpen(false);
  }, [setIsOpen]);

  return (
    <XUIActionMenu onClickOutside={closeFlyout} isOpen={isOpen}>
      <XUIActionMenuIconButtonTrigger
        ariaLabel="More options"
        icon={overflowIcon}
        onClick={() => setIsOpen(prevIsOpen => !prevIsOpen)}
      />
      <XUIActionMenuItems>
        <XUIActionMenuItem onSelect={closeFlyout}>Edit transactions</XUIActionMenuItem>
        <XUIActionMenuItem onSelect={closeFlyout}>Approve all</XUIActionMenuItem>
      </XUIActionMenuItems>
    </XUIActionMenu>
  );
};

<Example />;
```

### With navigating menu items

Wherever possible, avoid including links in action menus. Menu items with links have `role=menuitem` set on them, meaning screenreaders do not properly identify them as links nor clearly communicate that the menu item is intended for navigation. This leads to unexpected behaviour for screenreader users. If the flyout only contains links, don't use `XUIActionMenu`.

When it is necessary to include a link in `XUIActionMenu`, set `isLink` on the appropriate `XUIActionMenuItem` and specify the path using the `href` prop.

If the link navigates via `react-router`, set `isLink` and specify the route with the `to` prop. Use the provided `onClick` and `onKeyDown` to implement your own custom navigation logic.

```jsx harmony
import {
  XUIActionMenuIconButtonTrigger,
  XUIActionMenuItems,
  XUIActionMenu,
  XUIActionMenuItem
} from '@xero/xui/react/actionmenu';
import XUIIcon from '@xero/xui/react/icon';

import overflowIcon from '@xero/xui-icon/icons/overflow';
import externalIcon from '@xero/xui-icon/icons/external';

const onSelect = () => console.log('onSelect');

const Example = () => (
  <XUIActionMenu>
    <XUIActionMenuIconButtonTrigger ariaLabel="More options" icon={overflowIcon} />
    <XUIActionMenuItems>
      <XUIActionMenuItem onSelect={onSelect}>Manage bill payments</XUIActionMenuItem>
      <XUIActionMenuItem
        isLink
        to="https://xui.xero.com"
        onClick={e => {
          e.preventDefault();
          console.log("I'm navigating away with React Router!");
        }}
        onKeyDown={e => {
          if (e.key === ' ' || e.key === 'Enter') {
            e.preventDefault();
            console.log("I'm navigating away with React Router!");
          }
        }}
      >
        Learn about bill payments
        <XUIIcon icon={externalIcon} className="xui-margin-left-small" title="Opens in new tab" />
      </XUIActionMenuItem>
    </XUIActionMenuItems>
  </XUIActionMenu>
);

<Example />;
```

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = useTriggerClickAndKeyboardEvents;
require("core-js/modules/es.array.includes.js");
var React = _interopRequireWildcard(require("react"));
var _reactKeyHandler = require("../../helpers/reactKeyHandler");
var _constants = require("./constants");
var _helpers = require("./helpers");
var _useActionMenuContext = require("./useActionMenuContext");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function useTriggerClickAndKeyboardEvents({
  onClick,
  onKeyDown,
  isDisabled,
  isSubmenuTrigger = false
}) {
  const [shouldFocusLastItem, setShouldFocusLastItem] = React.useState(false);
  const {
    isFlyoutOpen,
    menuRefsRef,
    setFocusedMenuItemId,
    setIsFocusVisible,
    setIsFlyoutOpen
  } = (0, _useActionMenuContext.useActionMenuContext)();
  const composedHandleTriggerClick = React.useCallback(event => {
    setIsFlyoutOpen(prevIsMenuOpen => !prevIsMenuOpen);
    setShouldFocusLastItem(false);
    onClick === null || onClick === void 0 || onClick(event);
  }, [onClick, setIsFlyoutOpen]);
  const composedHandleTriggerKeyDown = React.useCallback(event => {
    if (event.key === _reactKeyHandler.eventKeyValues.space || event.key === _reactKeyHandler.eventKeyValues.enter || !isSubmenuTrigger && event.key === _reactKeyHandler.eventKeyValues.down) {
      event.preventDefault();
      setIsFlyoutOpen(true);
      setShouldFocusLastItem(false);
    } else if (event.key === _reactKeyHandler.eventKeyValues.up && !isSubmenuTrigger) {
      setIsFlyoutOpen(true);
      setShouldFocusLastItem(true);
    } else if (event.key === _reactKeyHandler.eventKeyValues.right && isSubmenuTrigger) {
      setIsFlyoutOpen(true);
      setShouldFocusLastItem(false);
    }
    if (_constants.focusVisibleKeys.includes(event.key)) setIsFocusVisible(true);
    if (!isDisabled) onKeyDown === null || onKeyDown === void 0 || onKeyDown(event);
  }, [isDisabled, isSubmenuTrigger, onKeyDown, setIsFocusVisible, setIsFlyoutOpen]);
  React.useEffect(() => {
    if (!isFlyoutOpen) return;
    let refToFocus = menuRefsRef.current.menuitems[0];
    if (shouldFocusLastItem) {
      refToFocus = menuRefsRef.current.menuitems[menuRefsRef.current.menuitems.length - 1];
    }
    const elementToFocus = (0, _helpers.getNodeFromRef)(refToFocus);
    if (elementToFocus) {
      elementToFocus.focus();
      setFocusedMenuItemId(elementToFocus.getAttribute('id'));
    }
  }, [isFlyoutOpen, menuRefsRef, shouldFocusLastItem, setFocusedMenuItemId, setShouldFocusLastItem]);
  return {
    composedHandleTriggerClick,
    composedHandleTriggerKeyDown
  };
}
//# sourceMappingURL=useTriggerClickAndKeyboardEvents.js.map
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.XUIActionMenu = XUIActionMenu;
exports.default = void 0;
var React = _interopRequireWildcard(require("react"));
var _developmentConsole = require("../helpers/developmentConsole");
var _getTriggerElementRef = _interopRequireDefault(require("../helpers/getTriggerElementRef"));
var _ActionMenuContext = _interopRequireDefault(require("./private/ActionMenuContext"));
var _helpers = require("./private/helpers");
var _useActionMenuItemKeyboardEvents = _interopRequireDefault(require("./private/useActionMenuItemKeyboardEvents"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function XUIActionMenu({
  children,
  isOpen: providedIsOpen,
  onClickOutside,
  onClose,
  preferredFlyoutPosition
}) {
  var _context$focusedMenuI, _context$setFocusedMe, _context$isFocusVisib, _context$setIsFocusVi;
  const flyoutRef = React.useRef(null);
  const context = React.useContext(_ActionMenuContext.default);
  const [isFlyoutOpen, setIsFlyoutOpen] = React.useState(false);
  const [flyoutId, setFlyoutId] = React.useState();
  const [isParentMenu] = React.useState(context === undefined);
  let [focusedMenuItemId, setFocusedMenuItemId] = React.useState();
  let [isFocusVisible, setIsFocusVisible] = React.useState(false);
  const calculatedPreferredFlyoutPosition = preferredFlyoutPosition !== null && preferredFlyoutPosition !== void 0 ? preferredFlyoutPosition : isParentMenu ? 'bottom-left' : 'right-top';
  const calculatedMenuOpenValue = providedIsOpen !== null && providedIsOpen !== void 0 ? providedIsOpen : isFlyoutOpen;
  const initialObject = {
    triggerRef: /*#__PURE__*/React.createRef(),
    menuitems: []
  };

  // Parent values for passing down to child contexts
  const currentMenuRef = React.useRef(initialObject);
  const mainTriggerRef = context ? context.mainTriggerRef : currentMenuRef.current.triggerRef;
  const parentMenuRefsObject = context ? context.menuRefsRef : currentMenuRef;
  const isMainFlyoutOpen = context ? context.isMainFlyoutOpen : isFlyoutOpen;
  const setIsMainFlyoutOpen = context ? context.setIsMainFlyoutOpen : setIsFlyoutOpen;
  const isSubmenu = !!context;
  const setContainingMenuOpen = context === null || context === void 0 ? void 0 : context.setIsFlyoutOpen;
  focusedMenuItemId = (_context$focusedMenuI = context === null || context === void 0 ? void 0 : context.focusedMenuItemId) !== null && _context$focusedMenuI !== void 0 ? _context$focusedMenuI : focusedMenuItemId;
  setFocusedMenuItemId = (_context$setFocusedMe = context === null || context === void 0 ? void 0 : context.setFocusedMenuItemId) !== null && _context$setFocusedMe !== void 0 ? _context$setFocusedMe : setFocusedMenuItemId;
  isFocusVisible = (_context$isFocusVisib = context === null || context === void 0 ? void 0 : context.isFocusVisible) !== null && _context$isFocusVisib !== void 0 ? _context$isFocusVisib : isFocusVisible;
  setIsFocusVisible = (_context$setIsFocusVi = context === null || context === void 0 ? void 0 : context.setIsFocusVisible) !== null && _context$setIsFocusVi !== void 0 ? _context$setIsFocusVi : setIsFocusVisible;
  const handleClickOutside = React.useCallback(event => {
    if (!currentMenuRef.current.triggerRef) {
      return;
    }
    const trigger = (0, _getTriggerElementRef.default)(currentMenuRef.current.triggerRef);
    if (event.target && trigger.current && !trigger.current.contains(event.target) && flyoutRef.current && !flyoutRef.current.contains(event.target)) {
      onClickOutside === null || onClickOutside === void 0 || onClickOutside();
      setIsFlyoutOpen(false);
      setFocusedMenuItemId(prevId => {
        if (prevId) {
          var _findMenuItemNodeFrom;
          (_findMenuItemNodeFrom = (0, _helpers.findMenuItemNodeFromId)(currentMenuRef.current, prevId)) === null || _findMenuItemNodeFrom === void 0 || _findMenuItemNodeFrom.blur();
        }
        return undefined;
      });
      onClose === null || onClose === void 0 || onClose();
    }
  }, [currentMenuRef, onClickOutside, setFocusedMenuItemId, onClose]);
  const {
    handleMenuItemKeyDown
  } = (0, _useActionMenuItemKeyboardEvents.default)({
    currentMenuRef,
    focusedMenuItemId,
    flyoutRef,
    mainTriggerRef,
    parentMenuRefsObject,
    setContainingMenuOpen,
    setIsFocusVisible,
    setIsFlyoutOpen,
    setIsMainFlyoutOpen,
    setFocusedMenuItemId
  });
  React.useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [handleClickOutside]);
  React.useEffect(() => {
    var _currentMenuRef$curre;
    if (!((_currentMenuRef$curre = currentMenuRef.current) !== null && _currentMenuRef$curre !== void 0 && (_currentMenuRef$curre = _currentMenuRef$curre.triggerRef) !== null && _currentMenuRef$curre !== void 0 && _currentMenuRef$curre.current)) {
      return;
    }
    if (isSubmenu && currentMenuRef.current.triggerRef.current.getAttribute('role') !== 'menuitem') {
      (0, _developmentConsole.logError)({
        componentName: 'XUIActionMenu',
        message: 'Submenu triggers must contain role "menuitem".'
      });
    }
  }, [isSubmenu]);
  React.useEffect(() => {
    const parentMenuRef = parentMenuRefsObject.current;
    currentMenuRef.current.isSubmenu = isSubmenu;
    if (isSubmenu && parentMenuRefsObject.current) {
      parentMenuRef.menuitems.push(currentMenuRef);
    }
    return () => {
      parentMenuRef.menuitems = parentMenuRef.menuitems.filter(menuItemRef => menuItemRef !== currentMenuRef);
    };
  }, [isSubmenu, parentMenuRefsObject]);
  React.useEffect(() => {
    if (!isMainFlyoutOpen) {
      setIsFlyoutOpen(false);
      setIsFocusVisible(false);
    }
  }, [isMainFlyoutOpen, setIsFocusVisible]);
  const menuContextValue = React.useMemo(() => ({
    focusedMenuItemId,
    handleMenuItemKeyDown,
    isFocusVisible,
    isMainFlyoutOpen,
    isParentMenu,
    isFlyoutOpen: calculatedMenuOpenValue,
    flyoutId,
    flyoutRef,
    menuRefsRef: currentMenuRef,
    mainTriggerRef,
    preferredFlyoutPosition: calculatedPreferredFlyoutPosition,
    setFocusedMenuItemId,
    setIsFocusVisible,
    setIsFlyoutOpen,
    setIsMainFlyoutOpen,
    setFlyoutId
  }), [calculatedMenuOpenValue, focusedMenuItemId, handleMenuItemKeyDown, isFocusVisible, isMainFlyoutOpen, isParentMenu, flyoutId, mainTriggerRef, calculatedPreferredFlyoutPosition, setFocusedMenuItemId, setIsFocusVisible, setIsMainFlyoutOpen, setFlyoutId]);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_ActionMenuContext.default.Provider, {
    value: menuContextValue,
    children: children
  });
}
var _default = exports.default = XUIActionMenu;
//# sourceMappingURL=XUIActionMenu.js.map
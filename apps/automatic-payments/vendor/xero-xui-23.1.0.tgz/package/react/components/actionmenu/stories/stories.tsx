// Libs
import React from 'react';

// Storybook things
import { storiesOf } from '@storybook/react';
import centered from '../../../../../.storybook/decorators/xuiResponsiveCenter';
import ExampleContainer from '../../../docs/ExampleContainer';
import { variations, storiesWithVariationsKindName, storiesWithKnobsKindName } from './variations';

// Components we need to test with
import {
  XUIActionMenu,
  XUIActionMenuIconButtonTrigger,
  XUIActionMenuItems,
  XUIActionMenuItem,
  XUIActionMenuGroup,
  XUIActionMenuItemCheckbox,
  XUIActionMenuRadioGroup,
  XUIActionMenuItemRadio,
  XUIActionMenuSeparator,
  XUIActionMenuHeading,
  XUIActionMenuItemWithSubmenu,
  XUIActionMenuButtonTrigger,
} from '../../../actionmenu';
import { overflowIcon, trashIcon, editIcon, commentIcon, checkboxCheckIcon } from '@xero/xui-icon';

import { boolean, select, text } from '@storybook/addon-knobs';
import { preferredFlyoutPositionFallbacks } from '../private/constants';
import { textButtonVariants } from '../../button/private/constants';
import { flattenedIconList, flattenedIconMap } from '../../helpers/icons';

const containerStyles = { maxWidth: '400px' };

const storiesWithKnobs = storiesOf(storiesWithKnobsKindName, module);
storiesWithKnobs.addDecorator(centered);
storiesWithKnobs.add('Playground', () => {
  const reactProps = {
    preferredFlyoutPosition: select(
      'Preferred flyout position',
      preferredFlyoutPositionFallbacks,
      'bottom-left',
    ),
  };

  const storybookProps = { triggerType: select('triggerType', ['button', 'icon'], 'icon') };

  const { triggerType } = storybookProps;

  const iconList = ['', ...flattenedIconList];

  return (
    <ExampleContainer style={containerStyles}>
      <XUIActionMenu {...(reactProps as any)} {...storybookProps}>
        {triggerType === 'icon' ? (
          <XUIActionMenuIconButtonTrigger
            ariaLabel={text('buttonLabel', 'More options')}
            className={text('buttonClassName', '')}
            icon={overflowIcon}
          />
        ) : (
          <XUIActionMenuButtonTrigger
            children={text('buttonLabel', 'More options')}
            className={text('buttonClassName', '')}
            hasCaret={boolean('hasCaret', false)}
            leftIcon={flattenedIconMap[select('leftIcon', iconList, undefined)]}
            rightIcon={flattenedIconMap[select('rightIcon', iconList, undefined)]}
            variant={select('buttonVariant', Object.keys(textButtonVariants), 'standard' as any)}
          />
        )}

        <XUIActionMenuItems className={text('menuItemsClassName', '')}>
          <XUIActionMenuItem leftIcon={editIcon}>Edit transactions</XUIActionMenuItem>
          <XUIActionMenuItem leftIcon={checkboxCheckIcon}>Approve</XUIActionMenuItem>
          <XUIActionMenuItem leftIcon={commentIcon}>Decline</XUIActionMenuItem>
          <XUIActionMenuItem leftIcon={trashIcon}>Delete</XUIActionMenuItem>
          <XUIActionMenu>
            <XUIActionMenuItemWithSubmenu>Filter transactions</XUIActionMenuItemWithSubmenu>
            <XUIActionMenuItems backButtonLabel="Back">
              <XUIActionMenuHeading id="heading-1">Date</XUIActionMenuHeading>
              <XUIActionMenuGroup ariaLabelledBy="heading-1">
                <XUIActionMenuItemCheckbox>2023</XUIActionMenuItemCheckbox>
                <XUIActionMenuItemCheckbox>2024</XUIActionMenuItemCheckbox>
              </XUIActionMenuGroup>
            </XUIActionMenuItems>
          </XUIActionMenu>
          <XUIActionMenuSeparator />
          <XUIActionMenuHeading id="heading-2">Group by</XUIActionMenuHeading>
          <XUIActionMenuRadioGroup ariaLabelledBy="heading-2">
            <XUIActionMenuItemRadio isDefaultChecked>Date</XUIActionMenuItemRadio>
            <XUIActionMenuItemRadio>Category</XUIActionMenuItemRadio>
          </XUIActionMenuRadioGroup>
        </XUIActionMenuItems>
      </XUIActionMenu>
    </ExampleContainer>
  );
});

const storiesWithVariations = storiesOf(storiesWithVariationsKindName, module);
variations.forEach(variation => {
  storiesWithVariations.add(variation.storyTitle, () => {
    const variationMinusStoryDetails = { ...variation };
    const [isOpen, setIsOpen] = React.useState(true);
    const [isSubmenuOpen, setIsSubmenuOpen] = React.useState(true);

    const toggleIsOpen = () => setIsOpen(prevIsOpen => !prevIsOpen);
    const onMenuItemClick = () => setIsOpen(false);

    const {
      buttonLabel,
      buttonVariant,
      buttonSize,
      hasCustomWidth,
      menuContent,
      withMenuitemIcons,
      ...props
    }: any = variationMinusStoryDetails;

    const trigger = buttonVariant ? (
      <XUIActionMenuButtonTrigger
        onClick={toggleIsOpen}
        onKeyDown={e => {
          if (e.key === 'Enter' || e.code === 'Space') {
            toggleIsOpen();
          }
        }}
        size={buttonSize as any}
      >
        {buttonLabel}
      </XUIActionMenuButtonTrigger>
    ) : (
      <XUIActionMenuIconButtonTrigger
        ariaLabel="More options"
        icon={overflowIcon}
        onClick={toggleIsOpen}
        onKeyDown={e => {
          if (e.key === 'Enter' || e.code === 'Space') {
            toggleIsOpen();
          }
        }}
      />
    );

    const menuitems = (
      <>
        <XUIActionMenuItem
          leftIcon={withMenuitemIcons ? editIcon : undefined}
          onSelect={onMenuItemClick}
        >
          {withMenuitemIcons ? <>Edit</> : <>Save</>}
        </XUIActionMenuItem>
        <XUIActionMenuItem
          leftIcon={withMenuitemIcons ? checkboxCheckIcon : undefined}
          onSelect={onMenuItemClick}
        >
          Approve
        </XUIActionMenuItem>
        <XUIActionMenuItem
          leftIcon={withMenuitemIcons ? trashIcon : undefined}
          onSelect={onMenuItemClick}
        >
          Delete
        </XUIActionMenuItem>
      </>
    );

    const checkboxes = (
      <>
        <XUIActionMenuItemCheckbox>View archived</XUIActionMenuItemCheckbox>
        <XUIActionMenuItemCheckbox>View new</XUIActionMenuItemCheckbox>
      </>
    );

    const radiogroup = (
      <XUIActionMenuRadioGroup ariaLabel="Sort">
        <XUIActionMenuItemRadio onSelect={onMenuItemClick} isDefaultChecked>
          Ascending
        </XUIActionMenuItemRadio>
        <XUIActionMenuItemRadio onSelect={onMenuItemClick}>Descending</XUIActionMenuItemRadio>
      </XUIActionMenuRadioGroup>
    );

    const group = (
      <XUIActionMenuGroup ariaLabel="Save">
        <XUIActionMenuItem onSelect={onMenuItemClick}>Save as draft</XUIActionMenuItem>
        <XUIActionMenuItem onSelect={onMenuItemClick}>Save and submit</XUIActionMenuItem>
      </XUIActionMenuGroup>
    );

    const groupWithHeading = (
      <>
        <XUIActionMenuHeading id="heading-1">Save as</XUIActionMenuHeading>
        <XUIActionMenuGroup ariaLabelledBy="heading-1">
          <XUIActionMenuItem onSelect={onMenuItemClick}>PDF</XUIActionMenuItem>
          <XUIActionMenuItem onSelect={onMenuItemClick}>CSV</XUIActionMenuItem>
        </XUIActionMenuGroup>
      </>
    );

    const submenu = (
      <>
        <XUIActionMenu isOpen={isSubmenuOpen}>
          <XUIActionMenuItemWithSubmenu>Document type</XUIActionMenuItemWithSubmenu>
          <XUIActionMenuItems backButtonLabel="Back">
            <XUIActionMenuGroup ariaLabel="Document types">
              <XUIActionMenuItemCheckbox>Bills</XUIActionMenuItemCheckbox>
              <XUIActionMenuItemCheckbox>Credit notes</XUIActionMenuItemCheckbox>
              <XUIActionMenuItemCheckbox isChecked>Prepayments</XUIActionMenuItemCheckbox>
              <XUIActionMenuItemCheckbox>Overpayments</XUIActionMenuItemCheckbox>
            </XUIActionMenuGroup>
          </XUIActionMenuItems>
        </XUIActionMenu>
      </>
    );

    return (
      <XUIActionMenu {...(props as any)} isOpen={isOpen}>
        {trigger}
        <XUIActionMenuItems style={hasCustomWidth && { minWidth: 400 }}>
          {(menuContent?.includes('menuitem') || !menuContent) && menuitems}
          {menuContent?.includes('checkbox') && checkboxes}
          {menuContent?.includes('radio') && radiogroup}
          {menuContent?.includes('submenu') && submenu}
          {menuContent?.includes('separator') && <XUIActionMenuSeparator />}
          {menuContent?.includes('group') && group}
          {menuContent?.includes('heading') && groupWithHeading}
        </XUIActionMenuItems>
      </XUIActionMenu>
    );
  });
});

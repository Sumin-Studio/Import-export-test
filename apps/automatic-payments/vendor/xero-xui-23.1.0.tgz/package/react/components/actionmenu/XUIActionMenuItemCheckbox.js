"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.XUIActionMenuItemCheckbox = XUIActionMenuItemCheckbox;
exports.default = void 0;
var _clsx = _interopRequireDefault(require("clsx"));
var _nanoid = require("nanoid");
var React = _interopRequireWildcard(require("react"));
var _reactKeyHandler = require("../helpers/reactKeyHandler");
var _XUITouchTarget = _interopRequireDefault(require("../touchtarget/XUITouchTarget"));
var _ActionMenuItemWrapper = require("./private/ActionMenuItemWrapper");
var _constants = require("./private/constants");
var _useActionMenuContext = require("./private/useActionMenuContext");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function XUIActionMenuItemCheckbox({
  className,
  id,
  isChecked: providedIsChecked,
  onClick,
  onKeyDown,
  onSelect,
  children,
  ...props
}) {
  const {
    handleMenuItemKeyDown
  } = (0, _useActionMenuContext.useActionMenuContext)();
  const [isChecked, setIsChecked] = React.useState(false);
  const [shouldAnimate, setShouldAnimate] = React.useState(true);
  const generatedMenuItemId = React.useRef((0, _nanoid.nanoid)());
  const calculatedMenuItemId = id || generatedMenuItemId.current || undefined;
  const handleChange = React.useCallback(() => {
    setIsChecked(checked => {
      if (checked) setShouldAnimate(true);
      return !checked;
    });
  }, [setIsChecked, setShouldAnimate]);
  const composedHandleClick = React.useCallback(event => {
    event.preventDefault();
    handleChange();
    onSelect === null || onSelect === void 0 || onSelect(calculatedMenuItemId);
    onClick === null || onClick === void 0 || onClick(event);
  }, [calculatedMenuItemId, handleChange, onClick, onSelect]);
  const composedHandleKeyDown = React.useCallback(event => {
    if (event.key === _reactKeyHandler.eventKeyValues.space || event.key === _reactKeyHandler.eventKeyValues.enter) {
      event.preventDefault();
      handleChange();
      onSelect === null || onSelect === void 0 || onSelect(calculatedMenuItemId);
      onKeyDown === null || onKeyDown === void 0 || onKeyDown(event);
      return;
    }
    handleMenuItemKeyDown(event);
    onKeyDown === null || onKeyDown === void 0 || onKeyDown(event);
  }, [calculatedMenuItemId, handleMenuItemKeyDown, handleChange, onKeyDown, onSelect]);
  const handleAnimationEnd = React.useCallback(() => {
    setShouldAnimate(false);
  }, [setShouldAnimate]);
  const calculatedCheckedValue = providedIsChecked !== null && providedIsChecked !== void 0 ? providedIsChecked : isChecked;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_ActionMenuItemWrapper.ActionMenuItemWrapper, {
    "aria-checked": calculatedCheckedValue,
    className: className,
    id: calculatedMenuItemId,
    onClick: composedHandleClick,
    onKeyDown: composedHandleKeyDown,
    role: "menuitemcheckbox",
    ...props,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: (0, _clsx.default)(`${_constants.baseClassName}__menuitem-checkbox`, calculatedCheckedValue && `${_constants.baseClassName}__menuitem-checkbox--is-checked`, !shouldAnimate && `${_constants.baseClassName}__menuitem-checkbox--is-animationdone`),
      onAnimationEnd: handleAnimationEnd,
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_XUITouchTarget.default, {})
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: `${_constants.baseClassName}__menuitem-text`,
      children: children
    })]
  });
}
var _default = exports.default = XUIActionMenuItemCheckbox;
//# sourceMappingURL=XUIActionMenuItemCheckbox.js.map
#### Action Menu Group

Used to group `XUIActionMenuItem`s and `XUIActionMenuItemCheckbox`es.

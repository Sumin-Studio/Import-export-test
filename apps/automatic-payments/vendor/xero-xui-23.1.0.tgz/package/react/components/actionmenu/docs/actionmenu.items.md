#### Action Menu Items

A wrapper for any of: `XUIActionMenu` (for submenus), `XUIActionMenuItem`, `XUIActionMenuGroup`, `XUIActionMenuItemCheckbox`, `XUIActionMenuRadioGroup`, `XUIActionMenuSeparator`, `XUIActionMenuHeading`

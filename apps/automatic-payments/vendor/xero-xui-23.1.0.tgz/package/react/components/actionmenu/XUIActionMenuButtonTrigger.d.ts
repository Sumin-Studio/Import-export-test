import * as React from 'react';
import { Prettify } from '../../helpers/helperTypes';
import XUIButton from '../button/XUIButton';
type ButtonProps = Pick<React.ComponentProps<typeof XUIButton>, 'caretIcon' | 'children' | 'className' | 'fullWidth' | 'hasCaret' | 'isDisabled' | 'isInverted' | 'leftIcon' | 'onClick' | 'onKeyDown' | 'qaHook' | 'rightIcon' | 'size' | 'variant'>;
type Props = ButtonProps & React.ButtonHTMLAttributes<HTMLButtonElement>;
export type XUIActionMenuButtonTriggerProps = Prettify<Props>;
declare function XUIActionMenuButtonTrigger({ className, hasCaret, onClick, onKeyDown, id, style, ...props }: Props): React.JSX.Element;
export default XUIActionMenuButtonTrigger;

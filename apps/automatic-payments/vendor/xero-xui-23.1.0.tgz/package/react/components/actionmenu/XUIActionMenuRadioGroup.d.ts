import * as React from 'react';
import { Prettify } from '../../helpers/helperTypes';
import { XUIActionMenuGroupProps } from './XUIActionMenuGroup';
interface ActionMenuRadioGroupProps extends XUIActionMenuGroupProps {
    /**
     * The ID for the selected `XUIActionMenuItemRadio`.
     * Use for the controlled implementation
     */
    selectedId?: string;
    /**
     * Expects `XUIActionMenuItemRadio` children
     */
    children: React.ReactNode;
}
export type XUIActionMenuRadioGroupProps = Prettify<ActionMenuRadioGroupProps>;
export declare function XUIActionMenuRadioGroup({ children, selectedId: providedSelectedId, ...props }: ActionMenuRadioGroupProps): React.JSX.Element;
export default XUIActionMenuRadioGroup;

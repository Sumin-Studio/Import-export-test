import * as React from 'react';
export type RadioGroupContext = {
    selectedId?: string;
    setSelectedId: React.Dispatch<React.SetStateAction<string | undefined>>;
};
declare const MenuRadioGroupContext: React.Context<RadioGroupContext | undefined>;
export default MenuRadioGroupContext;

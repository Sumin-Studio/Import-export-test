import XUIButton from '../../button/XUIButton';
import XUIIconButton from '../../button/XUIIconButton';
import { MenuRefs } from './ActionMenuContext';
export declare function getNodeFromRef(menuItemRef: React.RefObject<XUIButton | XUIIconButton | HTMLButtonElement | HTMLAnchorElement> | React.MutableRefObject<MenuRefs | null> | undefined): HTMLButtonElement | HTMLAnchorElement | null | undefined;
export declare function findMenuItemNodeFromId(menuObject: MenuRefs, id: string): HTMLButtonElement | HTMLAnchorElement | undefined;
export declare function getMenuItemRefIndexFromId(menuObject: MenuRefs, id: string): {
    idx: number;
    currentMenu: MenuRefs;
} | undefined;
export declare function isSubmenuRef(obj: any): obj is MenuRefs;

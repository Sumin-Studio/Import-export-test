import * as React from 'react';
import { Prettify } from '../../helpers/helperTypes';
interface ActionMenuHeadingProps {
    /**
     * The text content of the heading
     */
    children: React.ReactNode;
    /**
     * Additional classes to apply to the heading
     */
    className?: string;
    /**
     * The ID for the heading.
     * The same value must be given to the `ariaLabelledBy` prop on `XUIMenuActionGroup` to associate the heading
     * with its corresponding group
     */
    id: string;
}
export type XUIActionMenuHeadingProps = Prettify<ActionMenuHeadingProps>;
export default function XUIActionMenuHeading({ children, className, ...props }: ActionMenuHeadingProps): React.JSX.Element;
export {};

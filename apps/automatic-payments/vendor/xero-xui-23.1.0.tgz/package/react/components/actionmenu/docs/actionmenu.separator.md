#### Action Menu Separator

Used to visually signify groups and make the flyout easier to scan.

import '@testing-library/jest-dom';

import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import React from 'react';

import XUIActionMenu from '../XUIActionMenu';
import XUIActionMenuButtonTrigger from '../XUIActionMenuButtonTrigger';
import XUIActionMenuItem from '../XUIActionMenuItem';
import XUIActionMenuItemCheckbox from '../XUIActionMenuItemCheckbox';
import XUIActionMenuItemRadio from '../XUIActionMenuItemRadio';
import XUIActionMenuItems from '../XUIActionMenuItems';
import XUIActionMenuItemWithSubmenu from '../XUIActionMenuItemWithSubmenu';
import XUIActionMenuRadioGroup from '../XUIActionMenuRadioGroup';
import { cleanupTestEnvironment, configureTestEnvironment, createBasicMenu } from './helpers';

jest.mock(
  '../../helpers/Positioning/Positioning',
  () =>
    // eslint-disable-next-line func-names
    function ({ children }: { children: () => React.ReactNode }) {
      return <div data-testid="mocked-positioning">{children()}</div>;
    },
);

const menuOpenClass = 'xui-action-menu__flyout--is-open';

describe('XUIActionMenuIconButtonTrigger and XUIActionMenuButtonTrigger keyboard interactions', () => {
  describe.each([
    ['space', ' ', 'icon'],
    ['enter', '{enter}', 'icon'],
    ['space', ' ', 'button'],
    ['enter', '{enter}', 'button'],
  ])('%s key', (_name: string, key: string, triggerType: string) => {
    test(`activates the ${triggerType} trigger and opens the menu`, async () => {
      // Arrange
      render(createBasicMenu({ triggerType }));

      // Act
      await userEvent.tab();
      await userEvent.keyboard(key);

      // Assert
      expect(screen.getByRole('menu', { name: 'More options' })).toHaveClass(menuOpenClass);
      expect(screen.getByRole('button', { name: 'More options' })).toHaveAttribute(
        'aria-expanded',
        'true',
      );
    });

    test(`when the ${triggerType} trigger is activated via keyboard, focus is sent to the first menuitem`, async () => {
      // Arrange
      render(createBasicMenu({ triggerType }));
      expect(screen.getByRole('menuitem', { name: 'Menuitem 1' })).not.toHaveFocus();

      // Act
      await userEvent.tab();
      await userEvent.keyboard(key);

      // Assert
      expect(screen.getByRole('menuitem', { name: 'Menuitem 1' })).toHaveFocus();
    });
  });

  describe.each([
    ['space', ' ', 'icon'],
    ['enter', '{enter}', 'icon'],
    ['space', ' ', 'button'],
    ['enter', '{enter}', 'button'],
  ])('%s key', (_name: string, key: string, triggerType: string) => {
    test(`activates the ${triggerType} trigger and opens the menu`, async () => {
      // Arrange
      render(createBasicMenu({ triggerType }));

      // Act
      await userEvent.tab();
      await userEvent.keyboard(key);

      // Assert
      expect(screen.getByRole('menu', { name: 'More options' })).toHaveClass(menuOpenClass);
      expect(screen.getByRole('button', { name: 'More options' })).toHaveAttribute(
        'aria-expanded',
        'true',
      );
    });

    test(`when the ${triggerType} trigger is activated via keyboard, focus is sent to the first menuitem`, async () => {
      // Arrange
      render(createBasicMenu({ triggerType }));
      expect(screen.getByRole('menuitem', { name: 'Menuitem 1' })).not.toHaveFocus();

      // Act
      await userEvent.tab();
      await userEvent.keyboard(key);

      // Assert
      expect(screen.getByRole('menuitem', { name: 'Menuitem 1' })).toHaveFocus();
    });
  });

  describe.each([['icon'], ['button']])('%s trigger', (triggerType: string) => {
    test(`when the flyout is closed, pressing down opens the flyout and places focus on the first menuitem`, async () => {
      // Arrange
      render(createBasicMenu({ triggerType }));

      // Act
      await userEvent.tab();
      await userEvent.keyboard('[ArrowDown]');

      // Assert
      expect(screen.getByRole('button', { name: 'More options' })).toHaveAttribute(
        'aria-expanded',
        'true',
      );
      expect(screen.getByRole('menuitem', { name: 'Menuitem 1' })).toHaveFocus();
    });

    test(`when the flyout is closed, pressing up opens the flyout and places focus on the last menuitem`, async () => {
      // Arrange
      render(createBasicMenu({ triggerType }));

      // Act
      await userEvent.tab();
      await userEvent.keyboard('[ArrowUp]');

      // Assert
      expect(screen.getByRole('menuitem', { name: 'Menuitem 3' })).toHaveFocus();
    });
  });
});

describe('XUIActionMenuItemWithSubmenu (menuitem trigger) keyboard interactions', () => {
  describe.each([
    ['space', ' '],
    ['enter', '{enter}'],
    ['right', '[ArrowRight]'],
  ])('%s key', (_name: string, key: string) => {
    test('activates the submenu trigger and opens the submenu', async () => {
      // Arrange
      render(
        <XUIActionMenu>
          <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
          <XUIActionMenuItems backButtonLabel="Back">
            <XUIActionMenu>
              <XUIActionMenuItemWithSubmenu>Expand me</XUIActionMenuItemWithSubmenu>
              <XUIActionMenuItems backButtonLabel="Back">
                <XUIActionMenuItem>One</XUIActionMenuItem>
                <XUIActionMenuItem>Two</XUIActionMenuItem>
              </XUIActionMenuItems>
            </XUIActionMenu>
          </XUIActionMenuItems>
        </XUIActionMenu>,
      );

      // Act
      await userEvent.tab();
      await userEvent.keyboard(' ');
      expect(screen.getByRole('button', { name: 'More options' })).toHaveAttribute(
        'aria-expanded',
        'true',
      );
      expect(screen.getByRole('menuitem', { name: 'Expand me' })).toHaveAttribute(
        'aria-expanded',
        'false',
      );
      await userEvent.keyboard(key);

      // Assert
      expect(screen.getByRole('menu', { name: 'Expand me' })).toHaveClass(menuOpenClass);
      expect(screen.getByRole('menuitem', { name: 'Expand me' })).toHaveAttribute(
        'aria-expanded',
        'true',
      );
    });

    test('when the submenu trigger opens the submenu, focus is sent to the first submenu menuitem', async () => {
      // Arrange
      render(
        <XUIActionMenu>
          <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
          <XUIActionMenuItems backButtonLabel="Back">
            <XUIActionMenu>
              <XUIActionMenuItemWithSubmenu>Expand me</XUIActionMenuItemWithSubmenu>
              <XUIActionMenuItems backButtonLabel="Back">
                <XUIActionMenuItem>One</XUIActionMenuItem>
                <XUIActionMenuItem>Two</XUIActionMenuItem>
              </XUIActionMenuItems>
            </XUIActionMenu>
          </XUIActionMenuItems>
        </XUIActionMenu>,
      );

      // Act
      await userEvent.tab();
      await userEvent.keyboard(' ');
      expect(screen.getByRole('menuitem', { name: 'Expand me' })).toHaveFocus();
      await userEvent.keyboard(key);

      // Assert
      expect(screen.getByRole('menuitem', { name: 'One' })).toHaveFocus();
    });
  });
});

describe('XUIActionMenuItem keyboard interactions', () => {
  describe('non-trigger menuitem', () => {
    describe.each([
      ['space', ' '],
      ['enter', '{enter}'],
    ])('%s key', (_name: string, key: string) => {
      test('activates the menuitem and closes the menu', async () => {
        // Arrange
        render(
          <XUIActionMenu>
            <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
            <XUIActionMenuItems>
              <XUIActionMenuItem>One</XUIActionMenuItem>
            </XUIActionMenuItems>
          </XUIActionMenu>,
        );

        // Act
        await userEvent.tab();
        await userEvent.keyboard(' ');
        await userEvent.keyboard('[ArrowDown]');
        expect(
          screen.getByRole('button', { name: 'More options' }).getAttribute('aria-expanded'),
        ).toBe('true');
        await userEvent.keyboard(key);

        // Assert
        expect(
          screen.getByRole('button', { name: 'More options' }).getAttribute('aria-expanded'),
        ).toBe('false');
      });

      test('calls the user-provided onSelect', async () => {
        const onSelect = jest.fn();

        // Arrange
        render(
          <XUIActionMenu>
            <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
            <XUIActionMenuItems>
              <XUIActionMenuItem onSelect={onSelect}>One</XUIActionMenuItem>
            </XUIActionMenuItems>
          </XUIActionMenu>,
        );

        // Act
        await userEvent.tab();
        await userEvent.keyboard(' ');
        await userEvent.keyboard(key);

        // Assert
        expect(onSelect).toHaveBeenCalledTimes(1);
      });

      test('on small viewports, activates the back button and closes the current submenu', async () => {
        configureTestEnvironment();

        // Arrange
        render(
          <XUIActionMenu>
            <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
            <XUIActionMenuItems backButtonLabel="Back">
              <XUIActionMenu>
                <XUIActionMenuItemWithSubmenu>Submenu trigger</XUIActionMenuItemWithSubmenu>
                <XUIActionMenuItems backButtonLabel="Back to main menu">
                  <XUIActionMenuItem>Option one</XUIActionMenuItem>
                  <XUIActionMenuItem>Option two</XUIActionMenuItem>
                </XUIActionMenuItems>
              </XUIActionMenu>
            </XUIActionMenuItems>
          </XUIActionMenu>,
        );

        // Act
        await userEvent.tab();
        await userEvent.keyboard(' ');
        await userEvent.keyboard(' ');
        await userEvent.keyboard(key);

        // Assert
        expect(screen.getByRole('button', { name: 'More options' })).toHaveAttribute(
          'aria-expanded',
          'true',
        );
        expect(screen.getByRole('menuitem', { name: 'Submenu trigger' })).toHaveAttribute(
          'aria-expanded',
          'false',
        );

        cleanupTestEnvironment();
      });
    });

    test('pressing any key calls the user-provided onKeyDown', async () => {
      const onKeyDown = jest.fn();

      // Arrange
      render(
        <XUIActionMenu>
          <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
          <XUIActionMenuItems>
            <XUIActionMenuItem onKeyDown={onKeyDown}>One</XUIActionMenuItem>
          </XUIActionMenuItems>
        </XUIActionMenu>,
      );

      // Act
      await userEvent.tab();
      await userEvent.keyboard(' ');
      await userEvent.keyboard(' ');

      // Assert
      expect(onKeyDown).toHaveBeenCalledTimes(1);
    });

    test('pressing the right arrow key on a non-trigger menuitem does not do anything', async () => {
      // Arrange
      render(createBasicMenu({ triggerType: 'button' }));

      // Act
      await userEvent.tab();
      await userEvent.keyboard(' ');

      expect(screen.getByRole('menuitem', { name: 'Menuitem 1' })).toHaveFocus();
      await userEvent.keyboard('[ArrowRight]');

      // Assert
      expect(screen.getByRole('menuitem', { name: 'Menuitem 1' })).toHaveFocus();
    });
  });

  describe('on both trigger and non-trigger menuitems', () => {
    test('if not in a submenu, pressing the left arrow key does not shift focus', async () => {
      // Arrange
      render(createBasicMenu({ triggerType: 'button' }));

      // Act
      await userEvent.tab();
      await userEvent.keyboard(' ');
      expect(screen.getByRole('menuitem', { name: 'Menuitem 1' })).toHaveFocus();
      await userEvent.keyboard('[ArrowLeft]');

      // Assert
      expect(screen.getByRole('menuitem', { name: 'Menuitem 1' })).toHaveFocus();
    });

    test('pressing the esc key closes the menu', async () => {
      // Arrange
      render(createBasicMenu());

      // Act
      await userEvent.tab();
      await userEvent.keyboard(' ');

      const buttonTrigger = screen.getByRole('button', { name: 'More options' });
      expect(buttonTrigger.getAttribute('aria-expanded')).toBe('true');
      await userEvent.keyboard('[Escape]');

      // Assert
      expect(buttonTrigger.getAttribute('aria-expanded')).toBe('false');
    });

    test('when the menu is closed via the escape key, focus returns to the trigger', async () => {
      // Arrange
      render(createBasicMenu());

      // Act
      await userEvent.tab();
      await userEvent.keyboard(' ');
      expect(screen.getByRole('menuitem', { name: 'Menuitem 1' })).toHaveFocus();
      await userEvent.keyboard('[Escape]');

      // Assert
      expect(screen.getByRole('button', { name: 'More options' })).toHaveFocus();
    });

    test('pressing home sends focus to the first menuitem', async () => {
      // Arrange
      render(createBasicMenu({ triggerType: 'button' }));

      // Act
      await userEvent.tab();
      await userEvent.keyboard(' ');
      await userEvent.keyboard('[ArrowDown]');
      await userEvent.keyboard('[ArrowDown]');
      expect(screen.getByRole('menuitem', { name: 'Menuitem 3' })).toHaveFocus();
      await userEvent.keyboard('[Home]');

      // Assert
      expect(screen.getByRole('menuitem', { name: 'Menuitem 1' })).toHaveFocus();
    });

    test('pressing end sends focus to the last menuitem', async () => {
      // Arrange
      render(createBasicMenu({ triggerType: 'button' }));

      // Act
      await userEvent.tab();
      await userEvent.keyboard(' ');
      expect(screen.getByRole('menuitem', { name: 'Menuitem 1' })).toHaveFocus();
      await userEvent.keyboard('[End]');

      // Assert
      expect(screen.getByRole('menuitem', { name: 'Menuitem 3' })).toHaveFocus();
    });

    test('pressing tab closes the menu and moves focus to the next focusable element', async () => {
      // Arrange
      render(
        <div>
          {createBasicMenu({ triggerType: 'button' })}
          <button data-automationid="button" type="button">
            Foo
          </button>
        </div>,
      );

      // Act
      await userEvent.tab();
      await userEvent.keyboard(' ');
      expect(
        screen.getByRole('button', { name: 'More options' }).getAttribute('aria-expanded'),
      ).toBe('true');
      await userEvent.tab();

      // Assert
      expect(screen.getByTestId('button')).toHaveFocus();
      expect(
        screen.getByRole('button', { name: 'More options' }).getAttribute('aria-expanded'),
      ).toBe('false');
      expect(screen.getByRole('menu', { name: 'More options' })).not.toHaveClass(menuOpenClass);
    });

    test('pressing shift + tab closes the menu and moves focus to the previous focusable element', async () => {
      // Arrange
      render(
        <div>
          <button data-automationid="button" type="button">
            Foo
          </button>
          {createBasicMenu({ triggerType: 'button' })}
        </div>,
      );

      // Act
      await userEvent.tab();
      await userEvent.tab();
      await userEvent.keyboard(' ');
      expect(
        screen.getByRole('button', { name: 'More options' }).getAttribute('aria-expanded'),
      ).toBe('true');
      await userEvent.tab({ shift: true });

      // Assert
      expect(screen.getByTestId('button')).toHaveFocus();
      expect(
        screen.getByRole('button', { name: 'More options' }).getAttribute('aria-expanded'),
      ).toBe('false');
      expect(screen.getByRole('menu', { name: 'More options' })).not.toHaveClass(menuOpenClass);
    });

    test('pressing up navigates to the previous menuitem', async () => {
      // Arrange
      render(createBasicMenu({ triggerType: 'button' }));

      // Act
      await userEvent.tab();
      await userEvent.keyboard(' ');
      await userEvent.keyboard('[ArrowDown]');
      expect(screen.getByRole('menuitem', { name: 'Menuitem 2' })).toHaveFocus();
      await userEvent.keyboard('[ArrowUp]');

      // Assert
      expect(screen.getByRole('menuitem', { name: 'Menuitem 1' })).toHaveFocus();
    });

    test('if focus is already on the first menuitem, pressing up does not do anything', async () => {
      // Arrange
      render(createBasicMenu({ triggerType: 'button' }));

      // Act
      await userEvent.tab();
      await userEvent.keyboard(' ');
      await userEvent.keyboard('[ArrowUp]');

      // Assert
      expect(screen.getByRole('menuitem', { name: 'Menuitem 1' })).toHaveFocus();
    });

    test('pressing down navigates to the next menuitem', async () => {
      // Arrange
      render(createBasicMenu({ triggerType: 'button' }));

      // Act
      await userEvent.tab();
      await userEvent.keyboard(' ');
      expect(screen.getByRole('menuitem', { name: 'Menuitem 1' })).toHaveFocus();
      await userEvent.keyboard('[ArrowDown]');

      // Assert
      expect(screen.getByRole('menuitem', { name: 'Menuitem 2' })).toHaveFocus();
    });

    test('if on the last menuitem, pressing down does not do anything', async () => {
      // Arrange
      render(createBasicMenu({ triggerType: 'button' }));

      // Act
      await userEvent.tab();
      await userEvent.keyboard(' ');
      await userEvent.keyboard('[ArrowDown]');
      await userEvent.keyboard('[ArrowDown]');

      // Assert
      expect(screen.getByRole('menuitem', { name: 'Menuitem 3' })).toHaveFocus();
    });
  });

  describe('in an open submenu', () => {
    test('pressing home sends focus to the first menuitem in the submenu', async () => {
      // Arrange
      render(
        <XUIActionMenu>
          <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
          <XUIActionMenuItems backButtonLabel="Back">
            <XUIActionMenu>
              <XUIActionMenuItemWithSubmenu>Expand me</XUIActionMenuItemWithSubmenu>
              <XUIActionMenuItems backButtonLabel="Back">
                <XUIActionMenuItem>One</XUIActionMenuItem>
                <XUIActionMenuItem>Two</XUIActionMenuItem>
                <XUIActionMenuItem>Three</XUIActionMenuItem>
              </XUIActionMenuItems>
            </XUIActionMenu>
          </XUIActionMenuItems>
        </XUIActionMenu>,
      );

      // Act
      await userEvent.tab();
      await userEvent.keyboard(' ');
      await userEvent.keyboard('[ArrowRight]');
      await userEvent.keyboard('[ArrowDown]');
      await userEvent.keyboard('[ArrowDown]');
      expect(screen.getByRole('menuitem', { name: 'Three' })).toHaveFocus();
      await userEvent.keyboard('[Home]');

      // Assert
      expect(screen.getByRole('menuitem', { name: 'One' })).toHaveFocus();
    });

    test('pressing the esc key closes the submenu and sends focus to the menuitem trigger', async () => {
      // Arrange
      render(
        <XUIActionMenu>
          <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
          <XUIActionMenuItems backButtonLabel="Back">
            <XUIActionMenu>
              <XUIActionMenuItemWithSubmenu>Expand me</XUIActionMenuItemWithSubmenu>
              <XUIActionMenuItems backButtonLabel="Back">
                <XUIActionMenuItem>One</XUIActionMenuItem>
                <XUIActionMenuItem>Two</XUIActionMenuItem>
              </XUIActionMenuItems>
            </XUIActionMenu>
          </XUIActionMenuItems>
        </XUIActionMenu>,
      );

      // Act
      await userEvent.tab();
      await userEvent.keyboard(' ');
      await userEvent.keyboard('[ArrowRight]');
      const menuItemTrigger = screen.getByRole('menuitem', { name: 'Expand me' });
      expect(menuItemTrigger.getAttribute('aria-expanded')).toBe('true');
      await userEvent.keyboard('[Escape]');

      // Assert
      expect(menuItemTrigger.getAttribute('aria-expanded')).toBe('false');
    });

    test('when the submenu closes, focus returns to the menuitem trigger', async () => {
      // Arrange
      render(
        <XUIActionMenu>
          <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
          <XUIActionMenuItems backButtonLabel="Back">
            <XUIActionMenu>
              <XUIActionMenuItemWithSubmenu>Expand me</XUIActionMenuItemWithSubmenu>
              <XUIActionMenuItems backButtonLabel="Back">
                <XUIActionMenuItem>One</XUIActionMenuItem>
                <XUIActionMenuItem>Two</XUIActionMenuItem>
              </XUIActionMenuItems>
            </XUIActionMenu>
          </XUIActionMenuItems>
        </XUIActionMenu>,
      );

      // Act
      await userEvent.tab();
      await userEvent.keyboard(' ');
      await userEvent.keyboard('[ArrowRight]');
      expect(screen.getByRole('menuitem', { name: 'One' })).toHaveFocus();
      await userEvent.keyboard('[Escape]');

      // Assert
      expect(screen.getByRole('menuitem', { name: 'Expand me' })).toHaveFocus();
    });

    test('pressing end sends focus to the last menuitem in the submenu', async () => {
      // Arrange
      render(
        <XUIActionMenu>
          <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
          <XUIActionMenuItems backButtonLabel="Back">
            <XUIActionMenu>
              <XUIActionMenuItemWithSubmenu>Expand me</XUIActionMenuItemWithSubmenu>
              <XUIActionMenuItems backButtonLabel="Back">
                <XUIActionMenuItem>One</XUIActionMenuItem>
                <XUIActionMenuItem>Two</XUIActionMenuItem>
                <XUIActionMenuItem>Three</XUIActionMenuItem>
              </XUIActionMenuItems>
            </XUIActionMenu>
          </XUIActionMenuItems>
        </XUIActionMenu>,
      );

      // Act
      await userEvent.tab();
      await userEvent.keyboard(' ');
      await userEvent.keyboard('[ArrowRight]');
      expect(screen.getByRole('menuitem', { name: 'One' })).toHaveFocus();
      await userEvent.keyboard('[End]');

      // Assert
      expect(screen.getByRole('menuitem', { name: 'Three' })).toHaveFocus();
    });

    test('pressing the left arrow key closes the submenu', async () => {
      // Arrange
      render(
        <XUIActionMenu>
          <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
          <XUIActionMenuItems backButtonLabel="Back">
            <XUIActionMenu>
              <XUIActionMenuItemWithSubmenu>Expand me</XUIActionMenuItemWithSubmenu>
              <XUIActionMenuItems backButtonLabel="Back">
                <XUIActionMenuItem>One</XUIActionMenuItem>
                <XUIActionMenuItem>Two</XUIActionMenuItem>
              </XUIActionMenuItems>
            </XUIActionMenu>
          </XUIActionMenuItems>
        </XUIActionMenu>,
      );

      // Act
      await userEvent.tab();
      await userEvent.keyboard(' ');
      await userEvent.keyboard('[ArrowRight]');
      expect(
        screen.getByRole('menuitem', { name: 'Expand me' }).getAttribute('aria-expanded'),
      ).toBe('true');
      await userEvent.keyboard('[ArrowLeft]');

      // Assert
      expect(
        screen.getByRole('menuitem', { name: 'Expand me' }).getAttribute('aria-expanded'),
      ).toBe('false');
    });
  });
});

describe('<XUIActionMenuItemCheckbox />', () => {
  describe.each([
    ['space', ' '],
    ['enter', '{enter}'],
  ])('%s key', (_name: string, key: string) => {
    test('when the checkbox is not already selected, sets aria-checked to true', async () => {
      // Arrange
      render(
        <XUIActionMenu>
          <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
          <XUIActionMenuItems>
            <XUIActionMenuItemCheckbox>Test checkbox</XUIActionMenuItemCheckbox>
          </XUIActionMenuItems>
        </XUIActionMenu>,
      );

      await userEvent.tab();
      await userEvent.keyboard(' ');
      const checkbox = screen.getByRole('menuitemcheckbox', { name: 'Test checkbox' });
      expect(checkbox).toHaveFocus();
      expect(checkbox).toHaveAttribute('aria-checked', 'false');
      await userEvent.keyboard(key);

      // Assert
      expect(checkbox).toHaveAttribute('aria-checked', 'true');
    });

    test('when the checkbox is selected, sets aria-checked to false', async () => {
      // Arrange
      render(
        <XUIActionMenu>
          <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
          <XUIActionMenuItems>
            <XUIActionMenuItemCheckbox>Test checkbox</XUIActionMenuItemCheckbox>
          </XUIActionMenuItems>
        </XUIActionMenu>,
      );

      await userEvent.tab();
      await userEvent.keyboard(' ');
      const checkbox = screen.getByRole('menuitemcheckbox', { name: 'Test checkbox' });
      expect(checkbox).toHaveFocus();
      await userEvent.keyboard(' ');
      expect(checkbox).toHaveAttribute('aria-checked', 'true');
      await userEvent.keyboard(key);

      // Assert
      expect(checkbox).toHaveAttribute('aria-checked', 'false');
    });

    test('calls the user-provided onSelect', async () => {
      const onSelect = jest.fn();

      // Arrange
      render(
        <XUIActionMenu>
          <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
          <XUIActionMenuItems>
            <XUIActionMenuItemCheckbox onSelect={onSelect}>Test checkbox</XUIActionMenuItemCheckbox>
          </XUIActionMenuItems>
        </XUIActionMenu>,
      );

      // Act
      await userEvent.tab();
      await userEvent.keyboard(' ');
      await userEvent.keyboard(key);

      // Assert
      expect(onSelect).toHaveBeenCalledTimes(1);
    });

    test('the menu remains open when the checkbox is toggled with space/enter', async () => {
      // Arrange
      render(
        <XUIActionMenu>
          <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
          <XUIActionMenuItems>
            <XUIActionMenuItemCheckbox>Test checkbox</XUIActionMenuItemCheckbox>
          </XUIActionMenuItems>
        </XUIActionMenu>,
      );

      await userEvent.tab();
      await userEvent.keyboard(' ');
      const checkbox = screen.getByRole('menuitemcheckbox', { name: 'Test checkbox' });
      expect(checkbox).toHaveFocus();
      await userEvent.keyboard(key);

      // Assert
      expect(screen.getByRole('button', { name: 'More options' })).toHaveAttribute(
        'aria-expanded',
        'true',
      );
      expect(screen.getByRole('menu', { name: 'More options' })).toHaveClass(menuOpenClass);
    });
  });
});

describe('<XUIActionMenuItemRadioGroup />', () => {
  describe.each([
    ['space', ' '],
    ['enter', '{enter}'],
  ])('%s key', (_name: string, key: string) => {
    test('changes aria-checked to the selected XUIActionMenuItemRadio', async () => {
      // Arrange
      render(
        <XUIActionMenu>
          <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
          <XUIActionMenuItems>
            <XUIActionMenuRadioGroup ariaLabel="Radio options">
              <XUIActionMenuItemRadio isDefaultChecked>Option one</XUIActionMenuItemRadio>
              <XUIActionMenuItemRadio>Option two</XUIActionMenuItemRadio>
            </XUIActionMenuRadioGroup>
          </XUIActionMenuItems>
        </XUIActionMenu>,
      );

      await userEvent.tab();
      expect(screen.getByRole('button', { name: 'More options' })).toHaveFocus();
      await userEvent.keyboard(' ');
      const radioOne = screen.getByRole('menuitemradio', { name: 'Option one' });
      expect(radioOne).toHaveFocus();
      expect(radioOne).toHaveAttribute('aria-checked', 'true');
      await userEvent.keyboard('[ArrowDown]');
      await userEvent.keyboard(key);

      // Assert
      expect(radioOne).toHaveAttribute('aria-checked', 'false');
      expect(screen.getByRole('menuitemradio', { name: 'Option two' })).toHaveAttribute(
        'aria-checked',
        'true',
      );
    });

    test('calls the user-provided onSelect', async () => {
      const onSelect = jest.fn();

      // Arrange
      render(
        <XUIActionMenu>
          <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
          <XUIActionMenuItems>
            <XUIActionMenuRadioGroup ariaLabel="Radio options">
              <XUIActionMenuItemRadio>Option one</XUIActionMenuItemRadio>
              <XUIActionMenuItemRadio onSelect={onSelect}>Option two</XUIActionMenuItemRadio>
            </XUIActionMenuRadioGroup>
          </XUIActionMenuItems>
        </XUIActionMenu>,
      );

      // Act
      await userEvent.tab();
      await userEvent.keyboard(' ');
      await userEvent.keyboard('[ArrowDown]');
      await userEvent.keyboard(key);

      // Assert
      expect(onSelect).toHaveBeenCalledTimes(1);
    });

    test('the menu closes after the XUIActionMenuItemRadio is selected with space/enter', async () => {
      // Arrange
      render(
        <XUIActionMenu>
          <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
          <XUIActionMenuItems>
            <XUIActionMenuRadioGroup ariaLabel="Radio options">
              <XUIActionMenuItemRadio>Option one</XUIActionMenuItemRadio>
              <XUIActionMenuItemRadio>Option two</XUIActionMenuItemRadio>
            </XUIActionMenuRadioGroup>
          </XUIActionMenuItems>
        </XUIActionMenu>,
      );

      await userEvent.tab();
      expect(screen.getByRole('button', { name: 'More options' })).toHaveFocus();
      await userEvent.keyboard(' ');
      await userEvent.keyboard('[ArrowDown]');
      await userEvent.keyboard('[Enter]');

      // Assert
      expect(screen.getByRole('button', { name: 'More options' })).toHaveAttribute(
        'aria-expanded',
        'false',
      );
    });
  });
});

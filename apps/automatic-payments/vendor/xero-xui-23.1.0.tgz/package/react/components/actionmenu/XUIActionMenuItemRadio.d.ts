import * as React from 'react';
import { Prettify } from '../../helpers/helperTypes';
import { BaseActionMenuItemProps } from './private/BaseActionMenuItemProps';
export interface ActionMenuItemRadioProps extends BaseActionMenuItemProps {
    /**
     * If `true`, then the radio will be checked by default.
     * Use for the uncontrolled implementation.
     * Will be ignored if `selectedId` is set on the `XUIActionMenuRadioGroup` for controlled implementation
     */
    isDefaultChecked?: boolean;
}
export type XUIActionMenuItemRadioProps = Prettify<ActionMenuItemRadioProps>;
export declare function XUIActionMenuItemRadio({ children, className, isDefaultChecked, onClick, onKeyDown, onSelect, ...props }: ActionMenuItemRadioProps): React.JSX.Element;
export default XUIActionMenuItemRadio;

import * as React from 'react';
import XUIButton from '../../button/XUIButton';
import XUIIconButton from '../../button/XUIIconButton';
import { AnchorSide } from '../../helpers/Positioning/helpers/positioning';
export interface MenuRefs {
    triggerRef?: React.RefObject<XUIIconButton | XUIButton | HTMLButtonElement>;
    isSubmenu?: boolean;
    menuitems: Array<React.MutableRefObject<MenuRefs | null> | React.RefObject<HTMLButtonElement | HTMLAnchorElement>>;
}
export type XUIActionMenuContextValue = {
    anchorElementAttributes?: React.HTMLAttributes<HTMLElement> & {
        style: React.CSSProperties & {
            anchorName: string;
        };
    };
    focusedMenuItemId?: string;
    isFocusVisible: boolean;
    isFlyoutOpen: boolean;
    isMainFlyoutOpen: boolean;
    isParentMenu: boolean;
    flyoutId?: string;
    flyoutRef: React.RefObject<HTMLUListElement>;
    menuRefsRef: React.MutableRefObject<MenuRefs>;
    mainTriggerRef?: React.RefObject<XUIButton | XUIIconButton>;
    handleMenuItemKeyDown: React.KeyboardEventHandler<HTMLButtonElement | HTMLAnchorElement>;
    positionedElementAttributes?: React.HTMLAttributes<HTMLElement>;
    preferredFlyoutPosition: AnchorSide;
    setFocusedMenuItemId: React.Dispatch<React.SetStateAction<string | undefined>>;
    setFlyoutId: React.Dispatch<React.SetStateAction<string | undefined>>;
    setIsFlyoutOpen: React.Dispatch<React.SetStateAction<boolean>>;
    setIsFocusVisible: React.Dispatch<React.SetStateAction<boolean>>;
    setIsMainFlyoutOpen: React.Dispatch<React.SetStateAction<boolean>>;
};
declare const ActionMenuContext: React.Context<XUIActionMenuContextValue | undefined>;
export default ActionMenuContext;

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useActionMenuContext = void 0;
var React = _interopRequireWildcard(require("react"));
var _ActionMenuContext = _interopRequireDefault(require("./ActionMenuContext"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
const useActionMenuContext = () => {
  const context = React.useContext(_ActionMenuContext.default);
  if (context) {
    return context;
  }
  throw new Error('`useActionMenuContext` needs to be used inside of a `ActionMenuContext` Provider. Please wrap your component in `XUIActionMenu`.');
};
exports.useActionMenuContext = useActionMenuContext;
//# sourceMappingURL=useActionMenuContext.js.map
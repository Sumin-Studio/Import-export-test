import * as React from 'react';
import { XUIActionMenuItemProps } from '../XUIActionMenuItem';
interface ActionMenuItemWrapperProps extends XUIActionMenuItemProps {
    hasSubmenu?: boolean;
}
type NativeAnchorProps = Omit<React.ButtonHTMLAttributes<HTMLAnchorElement>, keyof ActionMenuItemWrapperProps | 'disabled' | 'aria-disabled'>;
type NativeButtonProps = Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, keyof ActionMenuItemWrapperProps | 'disabled' | 'aria-disabled'>;
type ConditionalProps = ({
    isLink: true;
} & NativeAnchorProps) | ({
    isLink?: false;
} & NativeButtonProps);
export declare function ActionMenuItemWrapper(props: ActionMenuItemWrapperProps & ConditionalProps): React.JSX.Element;
export {};

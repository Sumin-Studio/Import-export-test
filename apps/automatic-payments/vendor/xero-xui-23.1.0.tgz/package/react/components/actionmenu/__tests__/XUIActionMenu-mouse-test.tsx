import '@testing-library/jest-dom';

import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import React from 'react';

import XUIActionMenu from '../XUIActionMenu';
import XUIActionMenuButtonTrigger from '../XUIActionMenuButtonTrigger';
import XUIActionMenuItem from '../XUIActionMenuItem';
import XUIActionMenuItemCheckbox from '../XUIActionMenuItemCheckbox';
import XUIActionMenuItemRadio from '../XUIActionMenuItemRadio';
import XUIActionMenuItems from '../XUIActionMenuItems';
import XUIActionMenuItemWithSubmenu from '../XUIActionMenuItemWithSubmenu';
import XUIActionMenuRadioGroup from '../XUIActionMenuRadioGroup';
import { cleanupTestEnvironment, configureTestEnvironment, createBasicMenu } from './helpers';

jest.mock(
  '../../helpers/Positioning/Positioning',
  () =>
    // eslint-disable-next-line func-names
    function ({ children }: { children: () => React.ReactNode }) {
      return <div data-testid="mocked-positioning">{children()}</div>;
    },
);

describe('<XUIActionMenuButtonTrigger />', () => {
  test('when the menu is closed, clicking the trigger opens the menu', async () => {
    // Arrange
    render(createBasicMenu({ triggerType: 'button' }));

    // Act
    await userEvent.click(screen.getByRole('button', { name: 'More options' }));

    // Assert
    expect(screen.getByRole('button', { name: 'More options' })).toHaveAttribute(
      'aria-expanded',
      'true',
    );
  });
});

test('when the menu is open, clicking the trigger closes the menu', async () => {
  // Arrange
  render(createBasicMenu({ triggerType: 'button' }));

  // Act
  await userEvent.click(screen.getByRole('button', { name: 'More options' }));
  await userEvent.click(screen.getByRole('button', { name: 'More options' }));

  // Assert
  expect(screen.getByRole('button', { name: 'More options' })).toHaveAttribute(
    'aria-expanded',
    'false',
  );
});

describe('<XUIActionMenuIconButtonTrigger />', () => {
  test('when the menu is closed, clicking the trigger opens the menu', async () => {
    // Arrange
    render(createBasicMenu());

    // Act
    await userEvent.click(screen.getByRole('button', { name: 'More options' }));

    // Assert
    expect(screen.getByRole('button', { name: 'More options' })).toHaveAttribute(
      'aria-expanded',
      'true',
    );
  });

  test('when the menu is open, clicking the trigger closes the menu', async () => {
    // Arrange
    render(createBasicMenu());

    // Act
    await userEvent.click(screen.getByRole('button', { name: 'More options' }));
    await userEvent.click(screen.getByRole('button', { name: 'More options' }));

    // Assert
    expect(screen.getByRole('button', { name: 'More options' })).toHaveAttribute(
      'aria-expanded',
      'false',
    );
  });
});

describe('<XUIActionMenuItemWithSubmenu />', () => {
  test('when the submenu is closed, clicking the trigger opens the submenu', async () => {
    // Arrange
    render(
      <XUIActionMenu>
        <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
        <XUIActionMenuItems backButtonLabel="Back">
          <XUIActionMenu>
            <XUIActionMenuItemWithSubmenu>Submenu trigger</XUIActionMenuItemWithSubmenu>
            <XUIActionMenuItems backButtonLabel="Back">
              <XUIActionMenuItem>Menuitem one</XUIActionMenuItem>
              <XUIActionMenuItem>Menuitem two</XUIActionMenuItem>
            </XUIActionMenuItems>
          </XUIActionMenu>
        </XUIActionMenuItems>
      </XUIActionMenu>,
    );

    // Act
    await userEvent.click(screen.getByRole('button', { name: 'More options' }));
    await userEvent.click(screen.getByRole('menuitem', { name: 'Submenu trigger' }));

    // Assert
    expect(screen.getByRole('button', { name: 'More options' })).toHaveAttribute(
      'aria-expanded',
      'true',
    );
    expect(screen.getByRole('menuitem', { name: 'Submenu trigger' })).toHaveAttribute(
      'aria-expanded',
      'true',
    );
  });

  test('when the submenu is open, clicking the trigger closes the submenu', async () => {
    // Arrange
    render(
      <XUIActionMenu>
        <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
        <XUIActionMenuItems backButtonLabel="Back">
          <XUIActionMenu>
            <XUIActionMenuItemWithSubmenu>Submenu trigger</XUIActionMenuItemWithSubmenu>
            <XUIActionMenuItems backButtonLabel="Back">
              <XUIActionMenuItem>Menuitem one</XUIActionMenuItem>
              <XUIActionMenuItem>Menuitem two</XUIActionMenuItem>
            </XUIActionMenuItems>
          </XUIActionMenu>
        </XUIActionMenuItems>
      </XUIActionMenu>,
    );

    // Act
    await userEvent.click(screen.getByRole('button', { name: 'More options' }));
    await userEvent.click(screen.getByRole('menuitem', { name: 'Submenu trigger' }));
    await userEvent.click(screen.getByRole('menuitem', { name: 'Submenu trigger' }));

    // Assert
    expect(screen.getByRole('button', { name: 'More options' })).toHaveAttribute(
      'aria-expanded',
      'true',
    );
    expect(screen.getByRole('menuitem', { name: 'Submenu trigger' })).toHaveAttribute(
      'aria-expanded',
      'false',
    );
  });

  test('on small viewports, clicking the back button closes the current submenu', async () => {
    configureTestEnvironment();

    // Arrange
    render(
      <XUIActionMenu>
        <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
        <XUIActionMenuItems backButtonLabel="Back">
          <XUIActionMenu>
            <XUIActionMenuItemWithSubmenu>Submenu trigger</XUIActionMenuItemWithSubmenu>
            <XUIActionMenuItems backButtonLabel="Back to main menu">
              <XUIActionMenuItem>Option one</XUIActionMenuItem>
              <XUIActionMenuItem>Option two</XUIActionMenuItem>
            </XUIActionMenuItems>
          </XUIActionMenu>
        </XUIActionMenuItems>
      </XUIActionMenu>,
    );

    // Act
    await userEvent.click(screen.getByRole('button', { name: 'More options' }));
    await userEvent.click(screen.getByRole('menuitem', { name: 'Submenu trigger' }));
    await userEvent.click(screen.getByRole('menuitem', { name: 'Back to main menu' }));

    // Assert
    expect(screen.getByRole('button', { name: 'More options' })).toHaveAttribute(
      'aria-expanded',
      'true',
    );
    expect(screen.getByRole('menuitem', { name: 'Submenu trigger' })).toHaveAttribute(
      'aria-expanded',
      'false',
    );

    cleanupTestEnvironment();
  });
});

test('clicking outside of the parent menu closes all menus', async () => {
  // Arrange
  render(
    <>
      <button type="button">Outside button</button>
      <XUIActionMenu>
        <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
        <XUIActionMenuItems backButtonLabel="Back">
          <XUIActionMenu>
            <XUIActionMenuItemWithSubmenu>Submenu trigger</XUIActionMenuItemWithSubmenu>
            <XUIActionMenuItems backButtonLabel="Back">
              <XUIActionMenuItem>Menuitem one</XUIActionMenuItem>
              <XUIActionMenuItem>Menuitem two</XUIActionMenuItem>
            </XUIActionMenuItems>
          </XUIActionMenu>
        </XUIActionMenuItems>
      </XUIActionMenu>
    </>,
  );

  // Act
  await userEvent.click(screen.getByRole('button', { name: 'More options' }));
  await userEvent.click(screen.getByRole('menuitem', { name: 'Submenu trigger' }));
  await userEvent.click(screen.getByRole('button', { name: 'Outside button' }));

  // Assert
  expect(screen.getByRole('button', { name: 'More options' })).toHaveAttribute(
    'aria-expanded',
    'false',
  );
  expect(screen.getByRole('menuitem', { name: 'Submenu trigger' })).toHaveAttribute(
    'aria-expanded',
    'false',
  );
});

test('clicking outside of the current submenu but into the parent menu closes the submenu only', async () => {
  // Arrange
  render(
    <XUIActionMenu>
      <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
      <XUIActionMenuItems backButtonLabel="Back">
        <XUIActionMenu>
          <XUIActionMenuItemWithSubmenu>Submenu trigger</XUIActionMenuItemWithSubmenu>
          <XUIActionMenuItems backButtonLabel="Back">
            <XUIActionMenuItem>Menuitem one</XUIActionMenuItem>
            <XUIActionMenuItem>Menuitem two</XUIActionMenuItem>
          </XUIActionMenuItems>
        </XUIActionMenu>
      </XUIActionMenuItems>
    </XUIActionMenu>,
  );

  // Act
  await userEvent.click(screen.getByRole('button', { name: 'More options' }));
  await userEvent.click(screen.getByRole('menuitem', { name: 'Submenu trigger' }));
  await userEvent.click(screen.getByRole('menuitem', { name: 'Submenu trigger' }));

  // Assert
  expect(screen.getByRole('button', { name: 'More options' })).toHaveAttribute(
    'aria-expanded',
    'true',
  );
  expect(screen.getByRole('menuitem', { name: 'Submenu trigger' })).toHaveAttribute(
    'aria-expanded',
    'false',
  );
});

test('clicking outside calls the provided onClickOutside', async () => {
  const onClickOutside = jest.fn();

  // Arrange
  render(
    <>
      <button type="button">Outside button</button>
      <XUIActionMenu onClickOutside={onClickOutside}>
        <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
        <XUIActionMenuItems backButtonLabel="Back">
          <XUIActionMenuItem>Menuitem one</XUIActionMenuItem>
          <XUIActionMenuItem>Menuitem two</XUIActionMenuItem>
        </XUIActionMenuItems>
      </XUIActionMenu>
    </>,
  );

  // Act
  await userEvent.click(screen.getByRole('button', { name: 'More options' }));
  await userEvent.click(screen.getByRole('button', { name: 'Outside button' }));

  // Assert
  expect(onClickOutside).toHaveBeenCalled();
});

test('supports a controlled menu', async () => {
  const onClickOutside = jest.fn();

  // Arrange
  render(
    <>
      <button type="button">Outside button</button>
      <XUIActionMenu isOpen onClickOutside={onClickOutside}>
        <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
        <XUIActionMenuItems backButtonLabel="Back">
          <XUIActionMenuItem>Menuitem one</XUIActionMenuItem>
          <XUIActionMenuItem>Menuitem two</XUIActionMenuItem>
        </XUIActionMenuItems>
      </XUIActionMenu>
    </>,
  );

  // Act
  await userEvent.click(screen.getByRole('button', { name: 'Outside button' }));

  // Assert
  expect(onClickOutside).toHaveBeenCalled();
  expect(screen.getByRole('button', { name: 'More options' })).toHaveAttribute(
    'aria-expanded',
    'true',
  );
});

describe('<XUIActionMenuItemCheckbox />', () => {
  test('when the checkbox is unchecked, aria-checked is set to true when the checkbox is clicked', async () => {
    // Arrange
    render(
      <XUIActionMenu>
        <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
        <XUIActionMenuItems backButtonLabel="Back">
          <XUIActionMenuItemCheckbox>Test checkbox</XUIActionMenuItemCheckbox>
        </XUIActionMenuItems>
      </XUIActionMenu>,
    );

    // Act
    await userEvent.click(screen.getByRole('button', { name: 'More options' }));
    await userEvent.click(screen.getByRole('menuitemcheckbox', { name: 'Test checkbox' }));

    // Assert
    expect(screen.getByRole('menuitemcheckbox', { name: 'Test checkbox' })).toHaveAttribute(
      'aria-checked',
      'true',
    );
  });

  test('when the checkbox is checked, aria-checked is set to false when the checkbox is clicked', async () => {
    // Arrange
    render(
      <XUIActionMenu>
        <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
        <XUIActionMenuItems backButtonLabel="Back">
          <XUIActionMenuItemCheckbox>Test checkbox</XUIActionMenuItemCheckbox>
        </XUIActionMenuItems>
      </XUIActionMenu>,
    );

    // Act
    await userEvent.click(screen.getByRole('button', { name: 'More options' }));
    await userEvent.click(screen.getByRole('menuitemcheckbox', { name: 'Test checkbox' }));
    await userEvent.click(screen.getByRole('menuitemcheckbox', { name: 'Test checkbox' }));

    // Assert
    expect(screen.getByRole('menuitemcheckbox', { name: 'Test checkbox' })).toHaveAttribute(
      'aria-checked',
      'false',
    );
  });

  test('should call the provided onClick every time the component is clicked', async () => {
    const onClick = jest.fn();

    // Arrange
    render(
      <XUIActionMenu>
        <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
        <XUIActionMenuItems backButtonLabel="Back">
          <XUIActionMenuItemCheckbox onClick={onClick}>Test checkbox</XUIActionMenuItemCheckbox>
        </XUIActionMenuItems>
      </XUIActionMenu>,
    );

    // Act
    await userEvent.click(screen.getByRole('button', { name: 'More options' }));
    await userEvent.click(screen.getByRole('menuitemcheckbox', { name: 'Test checkbox' }));

    // Assert
    expect(onClick).toHaveBeenCalled();
  });

  test('should call the provided onSelect every time the menuitem is clicked', async () => {
    const onSelect = jest.fn();

    // Arrange
    render(
      <XUIActionMenu>
        <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
        <XUIActionMenuItems backButtonLabel="Back">
          <XUIActionMenuItem onSelect={onSelect}>Test menuitem</XUIActionMenuItem>
        </XUIActionMenuItems>
      </XUIActionMenu>,
    );

    // Act
    await userEvent.click(screen.getByRole('button', { name: 'More options' }));
    await userEvent.click(screen.getByRole('menuitem', { name: 'Test menuitem' }));

    // Assert
    expect(onSelect).toHaveBeenCalled();
  });
});

describe('<XUIActionMenuItemRadioGroup />', () => {
  test('sets aria-checked on the selected radio item', async () => {
    // Arrange
    render(
      <XUIActionMenu>
        <XUIActionMenuButtonTrigger>More options</XUIActionMenuButtonTrigger>
        <XUIActionMenuItems backButtonLabel="Back">
          <XUIActionMenuRadioGroup ariaLabel="Radio options">
            <XUIActionMenuItemRadio>Option one</XUIActionMenuItemRadio>
            <XUIActionMenuItemRadio>Option two</XUIActionMenuItemRadio>
          </XUIActionMenuRadioGroup>
        </XUIActionMenuItems>
      </XUIActionMenu>,
    );

    // Act
    await userEvent.click(screen.getByRole('button', { name: 'More options' }));
    await userEvent.click(screen.getByRole('menuitemradio', { name: 'Option two' }));

    // Assert
    expect(screen.getByRole('menuitemradio', { name: 'Option one' })).toHaveAttribute(
      'aria-checked',
      'false',
    );
    expect(screen.getByRole('menuitemradio', { name: 'Option two' })).toHaveAttribute(
      'aria-checked',
      'true',
    );
  });
});

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ActionMenuMobileBackMenuItem;
var _back = _interopRequireDefault(require("@xero/xui-icon/icons/back"));
var _clsx = _interopRequireDefault(require("clsx"));
var React = _interopRequireWildcard(require("react"));
var _reactKeyHandler = require("../../helpers/reactKeyHandler");
var _XUIIcon = _interopRequireDefault(require("../../icon/XUIIcon"));
var _XUIActionMenuSeparator = _interopRequireDefault(require("../XUIActionMenuSeparator"));
var _constants = require("./constants");
var _helpers = require("./helpers");
var _useActionMenuContext = require("./useActionMenuContext");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function ActionMenuMobileBackMenuItem({
  isBelowSmallBreakpoint,
  id,
  children,
  onSelect,
  qaHook,
  ...props
}) {
  const {
    menuRefsRef,
    setIsFlyoutOpen,
    setFocusedMenuItemId,
    setIsFocusVisible,
    handleMenuItemKeyDown
  } = (0, _useActionMenuContext.useActionMenuContext)();
  const backButtonRef = React.useRef(null);
  React.useEffect(() => {
    const currentMenu = menuRefsRef.current;
    currentMenu.menuitems.unshift(backButtonRef);
    return () => {
      currentMenu.menuitems = currentMenu.menuitems.filter(menuItemRef => menuItemRef !== backButtonRef);
    };
  }, [menuRefsRef]);
  const handleNavigateBack = React.useCallback(() => {
    setIsFlyoutOpen(false);
  }, [setIsFlyoutOpen]);
  const handleClick = React.useCallback(() => {
    handleNavigateBack();
    onSelect === null || onSelect === void 0 || onSelect(id);
  }, [handleNavigateBack, id, onSelect]);
  const handleBackButtonKeyDown = React.useCallback(e => {
    e.preventDefault();
    if (e.key === _reactKeyHandler.eventKeyValues.space || e.key === _reactKeyHandler.eventKeyValues.enter) {
      handleNavigateBack();
      const triggerNode = (0, _helpers.getNodeFromRef)(menuRefsRef.current.triggerRef);
      if (!triggerNode) return;
      setFocusedMenuItemId(triggerNode.getAttribute('id'));
      setIsFocusVisible(true);
      triggerNode.focus();
      onSelect === null || onSelect === void 0 || onSelect(id);
    } else {
      handleMenuItemKeyDown(e);
    }
  }, [handleMenuItemKeyDown, handleNavigateBack, id, menuRefsRef, onSelect, setFocusedMenuItemId, setIsFocusVisible]);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
      className: (0, _clsx.default)(`${_constants.baseClassName}__menuitem-wrapper`),
      role: "none",
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        ...props,
        "data-automationid": qaHook,
        id: id,
        role: "menuitem",
        ref: backButtonRef,
        onClick: handleClick,
        onKeyDown: handleBackButtonKeyDown,
        type: "button",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: `${_constants.baseClassName}__menuitem-left-icon`,
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_XUIIcon.default, {
            icon: _back.default,
            color: "black-faint"
          })
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: `${_constants.baseClassName}__menuitem-text`,
          children: children
        })]
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_XUIActionMenuSeparator.default, {})]
  });
}
//# sourceMappingURL=ActionMenuMobileBackMenuItem.js.map
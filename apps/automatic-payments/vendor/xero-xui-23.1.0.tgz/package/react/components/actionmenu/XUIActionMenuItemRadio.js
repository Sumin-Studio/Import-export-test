"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.XUIActionMenuItemRadio = XUIActionMenuItemRadio;
exports.default = void 0;
var _clsx = _interopRequireDefault(require("clsx"));
var _nanoid = require("nanoid");
var React = _interopRequireWildcard(require("react"));
var _reactKeyHandler = require("../helpers/reactKeyHandler");
var _ActionMenuItemWrapper = require("./private/ActionMenuItemWrapper");
var _constants = require("./private/constants");
var _useActionMenuContext = require("./private/useActionMenuContext");
var _useActionMenuRadioGroupContext = require("./private/useActionMenuRadioGroupContext");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function XUIActionMenuItemRadio({
  children,
  className,
  isDefaultChecked,
  onClick,
  onKeyDown,
  onSelect,
  ...props
}) {
  const {
    selectedId,
    setSelectedId
  } = (0, _useActionMenuRadioGroupContext.useActionMenuRadioGroupContext)();
  const {
    handleMenuItemKeyDown,
    setIsMainFlyoutOpen
  } = (0, _useActionMenuContext.useActionMenuContext)();
  const generatedRadioId = React.useRef((0, _nanoid.nanoid)());
  const radioId = props.id || generatedRadioId.current;
  const composedHandleClick = React.useCallback(event => {
    event.preventDefault();
    setSelectedId(radioId);
    setIsMainFlyoutOpen(false);
    onSelect === null || onSelect === void 0 || onSelect(radioId);
    onClick === null || onClick === void 0 || onClick(event);
  }, [setSelectedId, onClick, onSelect, setIsMainFlyoutOpen, radioId]);
  const composedHandleKeyDown = React.useCallback(event => {
    if (event.key === _reactKeyHandler.eventKeyValues.space || event.key === _reactKeyHandler.eventKeyValues.enter) {
      event.preventDefault();
      setSelectedId(radioId);
      setIsMainFlyoutOpen(false);
      onSelect === null || onSelect === void 0 || onSelect(radioId);
    }
    handleMenuItemKeyDown(event);
    onKeyDown === null || onKeyDown === void 0 || onKeyDown(event);
  }, [handleMenuItemKeyDown, setSelectedId, onKeyDown, onSelect, radioId, setIsMainFlyoutOpen]);
  React.useEffect(() => {
    if (isDefaultChecked) {
      setSelectedId(radioId);
    }
  }, [isDefaultChecked, radioId, setSelectedId]);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_ActionMenuItemWrapper.ActionMenuItemWrapper, {
    ...props,
    "aria-checked": selectedId === radioId,
    className: (0, _clsx.default)(`${_constants.baseClassName}__menuitemradio`, className, selectedId === radioId && `${_constants.baseClassName}__menuitemradio--is-selected`),
    id: radioId,
    onClick: composedHandleClick,
    onKeyDown: composedHandleKeyDown,
    role: "menuitemradio",
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: `${_constants.baseClassName}__menuitem-text`,
      children: children
    })
  });
}
var _default = exports.default = XUIActionMenuItemRadio;
//# sourceMappingURL=XUIActionMenuItemRadio.js.map
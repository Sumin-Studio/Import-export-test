import React from 'react';
import { render, screen } from '@testing-library/react';
import { axe, toHaveNoViolations } from 'jest-axe';
import accessibility from '@xero/xui-icon/icons/accessibility';
import XUIIcon from '../XUIIcon';

expect.extend(toHaveNoViolations);

describe('XUIIcon', () => {
  test('renders expected markup', () => {
    const { container } = render(
      <XUIIcon className="classyMcClassFace" icon={accessibility} title="title" />,
    );
    expect(container).toMatchSnapshot();
  });

  test('Should render with a role of img if a title is included', () => {
    render(<XUIIcon icon={accessibility} title="Accessibility" />);
    const icon = screen.getByRole('img');
    expect(icon).toBeInTheDocument();
  });

  test('should pass accessibility testing', async () => {
    const { container } = render(<XUIIcon icon={accessibility} />);
    const results = await axe(container);
    expect(results).toHaveNoViolations();
  });
});

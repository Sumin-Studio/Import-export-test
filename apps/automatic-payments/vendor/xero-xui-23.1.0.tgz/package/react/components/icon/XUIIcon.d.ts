import * as React from 'react';

import { Prettify } from '../../helpers/helperTypes';
import { colorClasses, rotationClasses, wrapperSizeClasses } from './private/constants';

export interface XUIIconData {
  height: number;
  path: string;
  width: number;
}

interface BaseProps {
  className?: string;
  /**
   * Adds a color modifier to the icon.
   */
  color?: keyof typeof colorClasses;
  /**
   * An object describing the path, width and height.
   */
  icon: XUIIconData;
  /**
   * Whether the icon should be wrapped in a wrapper with a set size.
   */
  isBoxed?: boolean;
  qaHook?: string;
  /**
   * Role to be applied to the SVG for screen readers.
   */
  role?: string;
  /**
   * Adds a rotation modifier to the icon.
   *
   * Defaults to `0`.
   */
  rotation?: keyof typeof rotationClasses | 0 | '0' | '90' | '180' | '270';
  /**
   * Adds a size modifier to the icon.
   */
  size?: keyof typeof wrapperSizeClasses;
  /**
   * An object to pass attributes to the icon's svg.
   */
  svgProps?: React.DetailedHTMLProps<React.SVGAttributes<SVGElement>, SVGElement>;
  /**
   * Title to be read by screen readers.
   */
  title?: string;
}

type SpreadProps = React.SVGAttributes<SVGElement>;

type Props = BaseProps & SpreadProps;

export type XUIIconProps = Prettify<Props>;

declare const XUIIcon: React.FunctionComponent<XUIIconProps>;
export default XUIIcon;

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("../helpers/xuiGlobalChecks");
var _clsx = _interopRequireDefault(require("clsx"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react = _interopRequireDefault(require("react"));
var _developmentConsole = require("../helpers/developmentConsole");
var _constants = require("./private/constants");
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const XUIIcon = /*#__PURE__*/_react.default.forwardRef((props, ref) => {
  const {
    className,
    qaHook,
    size = 'medium',
    title,
    role,
    rotation,
    color,
    icon,
    isBoxed,
    svgProps
  } = props;

  // Log a warning if the role prop is used
  if (role) {
    (0, _developmentConsole.logWarning)({
      componentName: 'XUIIcon',
      message: '`role` prop will be deprecated in XUI 24. For decorative icons, the aria-hidden attribute is set to true by default, hiding them from screen readers. For icons that convey meaning, setting a value to the `title` prop will automatically add the accessible role of img to the icon SVG.'
    });
  }
  const svgClasses = (0, _clsx.default)(_constants.baseClass, _constants.colorClasses[color], _constants.rotationClasses[rotation], !isBoxed && className // If no wrapper is needed, apply custom classes directly on the SVG
  );
  const optionalTitle = title ? /*#__PURE__*/(0, _jsxRuntime.jsx)("title", {
    children: title
  }) : null;
  const isInformative = Boolean(title);
  const optionalRole = role || isInformative ? 'img' : null;
  const sizeMultiplier = _constants.iconSizeMultipliers[size] || 1;
  const svgElement = /*#__PURE__*/(0, _jsxRuntime.jsxs)("svg", {
    "aria-hidden": !isInformative,
    className: svgClasses,
    "data-automationid": qaHook,
    focusable: "false",
    height: icon.height * sizeMultiplier,
    ref: ref,
    role: optionalRole,
    viewBox: `0 0 ${icon.width} ${icon.height}`,
    width: icon.width * sizeMultiplier,
    ...svgProps,
    children: [optionalTitle, /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
      d: icon.path
    })]
  });
  return !isBoxed ? svgElement : /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: (0, _clsx.default)(className, _constants.wrapperClass, _constants.wrapperSizeClasses[size]),
    "data-automationid": qaHook && `${qaHook}-wrapper`,
    children: svgElement
  });
});
XUIIcon.propTypes = {
  className: _propTypes.default.string,
  /** Adds a color modifier to the icon */
  color: _propTypes.default.oneOf(Object.keys(_constants.colorClasses)),
  /** An object describing the path, width and height. */
  icon: _propTypes.default.shape({
    height: _propTypes.default.number.isRequired,
    path: _propTypes.default.string.isRequired,
    width: _propTypes.default.number.isRequired
  }).isRequired,
  /** Whether the icon should be wrapped in a wrapper with a set size */
  isBoxed: _propTypes.default.bool,
  qaHook: _propTypes.default.string,
  /** Role to be applied to the SVG for screen readers
   *
   * Note: This prop is sunsetting and will be deprecated in XUI 24.
   */
  role: _propTypes.default.string,
  /** Adds a rotation modifier to the icon. Accepted values are 0 (default), 90, 180, 270 */
  rotation: _propTypes.default.oneOf([...Object.keys(_constants.rotationClasses), ...Object.keys(_constants.rotationClasses).map(n => parseInt(n, 10))]),
  /** Adds a size modifier to the icon */
  size: _propTypes.default.oneOf(Object.keys(_constants.wrapperSizeClasses)),
  /** An object to pass attributes to the icon's svg. */
  svgProps: _propTypes.default.object,
  /** Title to be read by screen readers */
  title: _propTypes.default.string
};
XUIIcon.displayName = 'XUIIcon';
var _default = exports.default = XUIIcon;
//# sourceMappingURL=XUIIcon.js.map
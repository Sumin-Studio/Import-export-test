export declare const baseClass: string;
export declare const wrapperClass: string;
export declare const wrapperSizeClasses: {
    xsmall: string;
    small: string;
    medium: string;
    large: string;
    xlarge: string;
};
export declare const iconSizeMultipliers: {
    xsmall: number;
    small: number;
    medium: number;
    large: number;
    xlarge: number;
};
export declare const rotationClasses: {
    0: string;
    90: string;
    180: string;
    270: string;
};
export declare const colorClasses: {
    black: string;
    'black-muted': string;
    'black-faint': string;
    white: string;
    white_muted: string;
    white_faint: string;
    blue: string;
    'dark-blue': string;
    green: string;
    red: string;
    orange: string;
    yellow: string;
    mint: string;
    turquoise: string;
    violet: string;
    grape: string;
    pink: string;
    file_spreadsheet: string;
    file_pdf: string;
};

import * as React from 'react';

export interface XUIBannerMessageDetailProps {
  className?: string;
  /**
   * The banner message details to be displayed as a list.
   */
  messageDetails: React.ReactNode[];
  qaHook?: string;
}

declare const XUIBannerMessageDetail: React.FunctionComponent<XUIBannerMessageDetailProps>;
export default XUIBannerMessageDetail;

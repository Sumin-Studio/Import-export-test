import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import { axe, toHaveNoViolations } from 'jest-axe';
import XUIBannerActions from '../XUIBannerActions';

expect.extend(toHaveNoViolations);

describe('<XUIBannerAction />', () => {
  it('should match snapshot', () => {
    const { container } = render(
      <XUIBannerActions>
        <button>Action</button>
        <button>Action</button>
      </XUIBannerActions>,
    );

    expect(container.firstElementChild).toMatchSnapshot();
  });

  it('should render a passed qaHook as an automation id', () => {
    render(
      <XUIBannerActions qaHook="banner-action">
        <button>Action 1</button>
        <button>Action 2</button>
      </XUIBannerActions>,
    );

    expect(screen.getByTestId('banner-action')).toBeInTheDocument();
  });

  it('should pass accessibility testing', async () => {
    const { container } = render(
      <XUIBannerActions>
        <button>Action 1</button>
        <button>Action 2</button>
      </XUIBannerActions>,
    );
    const results = await axe(container.firstElementChild);
    expect(results).toHaveNoViolations();
  });
});

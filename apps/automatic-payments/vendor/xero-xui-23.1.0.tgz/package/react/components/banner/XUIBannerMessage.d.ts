import * as React from 'react';

export interface XUIBannerMessageProps {
  children?: React.ReactNode;
  className?: string;
  qaHook?: string;
}

declare const XUIBannerMessage: React.FunctionComponent<XUIBannerMessageProps>;
export default XUIBannerMessage;

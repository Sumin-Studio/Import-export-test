import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import { axe, toHaveNoViolations } from 'jest-axe';
import XUIBannerAction from '../XUIBannerAction';

expect.extend(toHaveNoViolations);

describe('<XUIBannerAction />', () => {
  it('should match snapshot', () => {
    const { container } = render(<XUIBannerAction>Action</XUIBannerAction>);
    expect(container.firstElementChild).toMatchSnapshot();
  });

  it('should render as a link if an href value is passed and isLink prop is true', () => {
    render(
      <XUIBannerAction href="http://xero.com" isLink={true}>
        Action
      </XUIBannerAction>,
    );

    expect(screen.getByRole('link', { name: 'Action' })).toBeInTheDocument();
  });

  it('should pass accessibility testing', async () => {
    const { container } = render(<XUIBannerAction>Action</XUIBannerAction>);
    const results = await axe(container.firstElementChild);
    expect(results).toHaveNoViolations();
  });
});

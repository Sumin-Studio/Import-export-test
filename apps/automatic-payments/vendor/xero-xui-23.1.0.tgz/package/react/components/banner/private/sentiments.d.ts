declare const _default: {
    positive: {
        class: string;
        role: string;
    };
    negative: {
        class: string;
        role: string;
    };
    neutral: {
        class: string;
        role: string;
    };
};
export default _default;

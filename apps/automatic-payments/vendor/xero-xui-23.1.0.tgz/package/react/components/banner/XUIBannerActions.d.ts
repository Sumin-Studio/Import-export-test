import * as React from 'react';

export interface XUIBannerActionsProps {
  children?: React.ReactNode;
  className?: string;
  qaHook?: string;
}

declare const XUIBannerActions: React.FunctionComponent<XUIBannerActionsProps>;
export default XUIBannerActions;

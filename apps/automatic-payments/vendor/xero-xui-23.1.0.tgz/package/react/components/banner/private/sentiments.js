"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _xuiClassNamespace = require("../../helpers/xuiClassNamespace");
var _default = exports.default = {
  positive: {
    class: `${_xuiClassNamespace.ns}-banner-positive`,
    role: 'status'
  },
  negative: {
    class: `${_xuiClassNamespace.ns}-banner-negative`,
    role: 'alert'
  },
  neutral: {
    class: `${_xuiClassNamespace.ns}-banner-neutral`,
    role: 'status'
  }
};
//# sourceMappingURL=sentiments.js.map
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _clsx = _interopRequireDefault(require("clsx"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react = _interopRequireDefault(require("react"));
var _xuiClassNamespace = require("../helpers/xuiClassNamespace");
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function XUIBannerActions({
  children,
  className,
  qaHook
}) {
  const actionsClassName = (0, _clsx.default)(className, `${_xuiClassNamespace.ns}-banner--actions`);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: actionsClassName,
    "data-automationid": qaHook,
    children: children
  });
}
var _default = exports.default = XUIBannerActions;
XUIBannerActions.propTypes = {
  children: _propTypes.default.node,
  className: _propTypes.default.string,
  qaHook: _propTypes.default.string
};
//# sourceMappingURL=XUIBannerActions.js.map
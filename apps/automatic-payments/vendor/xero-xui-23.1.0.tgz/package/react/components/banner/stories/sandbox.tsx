import * as React from 'react';
import XUIBanner from '../XUIBanner';
import XUIBannerMessage from '../XUIBannerMessage';

export default function Sandbox() {
  const handleCloseClick = () => {
    alert('onCloseClick');
  };

  return (
    <div>
      <XUIBanner>
        <XUIBannerMessage>
          Unless you have experience managing your general ledger, ask your account or bookkeeper to
          create a journal.
        </XUIBannerMessage>
      </XUIBanner>
      <XUIBanner closeButtonLabel="Close" onCloseClick={handleCloseClick} sentiment="negative">
        <XUIBannerMessage>
          Data can't be loaded as there's a problem with your internet connection. Check your
          connection and try again.
        </XUIBannerMessage>
      </XUIBanner>
    </div>
  );
}

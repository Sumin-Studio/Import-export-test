"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _clsx = _interopRequireDefault(require("clsx"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react = _interopRequireDefault(require("react"));
var _button = _interopRequireDefault(require("../../button"));
var _xuiClassNamespace = require("../helpers/xuiClassNamespace");
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function XUIBannerAction({
  className,
  qaHook,
  onClick,
  href,
  isLink = false,
  children
}) {
  const buttonClassName = (0, _clsx.default)(className, `${_xuiClassNamespace.ns}-banner--action`, `${_xuiClassNamespace.ns}-button-small`);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_button.default, {
    className: buttonClassName,
    qaHook: qaHook,
    href: href,
    isLink: isLink,
    onClick: onClick,
    size: "small",
    variant: "borderless-main",
    children: children
  });
}
var _default = exports.default = XUIBannerAction;
XUIBannerAction.propTypes = {
  children: _propTypes.default.node,
  className: _propTypes.default.string,
  /** URL of the link */
  href: _propTypes.default.string,
  /** Whether or not to render this button using an anchor element */
  isLink: _propTypes.default.bool,
  /** Click event handler for the banner action */
  onClick: _propTypes.default.func,
  qaHook: _propTypes.default.string
};
//# sourceMappingURL=XUIBannerAction.js.map
import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import { axe, toHaveNoViolations } from 'jest-axe';
import XUIBannerMessageDetail from '../XUIBannerMessageDetail';

expect.extend(toHaveNoViolations);

describe('<XUIBannerMessageDetail />', () => {
  it('should match snapshot', () => {
    const { container } = render(<XUIBannerMessageDetail messageDetails={['a', 'b']} />);

    expect(container.firstElementChild).toMatchSnapshot();
  });

  it('should render a passed qaHook as an automation id', () => {
    render(
      <XUIBannerMessageDetail qaHook="banner-messagedetail" messageDetails={['a', 'b', 'c']} />,
    );

    expect(screen.getByTestId('banner-messagedetail')).toBeInTheDocument();
  });

  it('should map the list of mesage details to list elements', () => {
    render(<XUIBannerMessageDetail messageDetails={['a', 'b', 'c']} />);

    const listItems = screen.getAllByRole('listitem');
    expect(listItems).toHaveLength(3);
    expect(listItems[0]).toHaveTextContent('a');
    expect(listItems[1]).toHaveTextContent('b');
    expect(listItems[2]).toHaveTextContent('c');
  });

  it('should pass accessibility testing', async () => {
    const { container } = render(<XUIBannerMessageDetail messageDetails={['a', 'b']} />);
    const results = await axe(container.firstElementChild);
    expect(results).toHaveNoViolations();
  });
});

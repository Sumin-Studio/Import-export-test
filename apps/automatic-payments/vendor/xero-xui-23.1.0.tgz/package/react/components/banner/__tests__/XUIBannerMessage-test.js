import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import { axe, toHaveNoViolations } from 'jest-axe';
import XUIBannerMessage from '../XUIBannerMessage';

expect.extend(toHaveNoViolations);

describe('<XUIBannerMessage />', () => {
  it('should match snapshot', () => {
    const { container } = render(
      <XUIBannerMessage>
        <span>Message Content</span>
      </XUIBannerMessage>,
    );

    expect(container.firstElementChild).toMatchSnapshot();
  });

  it('should render a passed qaHook as an automation id', () => {
    render(
      <XUIBannerMessage qaHook="banner-action">
        <span>Message Content</span>
      </XUIBannerMessage>,
    );

    expect(screen.getByTestId('banner-action')).toBeInTheDocument();
  });

  it('should pass accessibility testing', async () => {
    const { container } = render(
      <XUIBannerMessage>
        <span>Message Content</span>
      </XUIBannerMessage>,
    );
    const results = await axe(container.firstElementChild);
    expect(results).toHaveNoViolations();
  });
});

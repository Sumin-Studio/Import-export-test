Strings to be displayed as an unordered list below the main message in a banner.

```jsx harmony
import XUIBanner, {
  XUIBannerAction,
  XUIBannerActions,
  XUIBannerMessage,
  XUIBannerMessageDetail
} from '@xero/xui/react/banner';

const handleCloseClick = () => {
  console.log('onCloseClick');
};

<div>
  <XUIBanner sentiment="negative">
    <XUIBannerMessage>
      The custom report couldn’t be saved as it doesn’t meet the new layout rules.
    </XUIBannerMessage>
    <XUIBannerMessageDetail
      messageDetails={[
        'In your old report, update the layout to meet the new layout rules.',
        'Create a new report using the custom layout.'
      ]}
    />
    <XUIBannerActions>
      <XUIBannerAction onClick={handleCloseClick}>Update report layout</XUIBannerAction>
    </XUIBannerActions>
  </XUIBanner>
</div>;
```

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _cross = _interopRequireDefault(require("@xero/xui-icon/icons/cross"));
var _clsx = _interopRequireDefault(require("clsx"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react = _interopRequireDefault(require("react"));
var _checkRequiredProps = _interopRequireDefault(require("../../helpers/checkRequiredProps"));
var _XUIIconButton = _interopRequireDefault(require("../button/XUIIconButton"));
var _xuiClassNamespace = require("../helpers/xuiClassNamespace");
var _sentiments = _interopRequireDefault(require("./private/sentiments"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const sentiments = Object.keys(_sentiments.default);
function XUIBanner({
  children,
  className,
  closeButtonLabel,
  hasDefaultLayout = true,
  onCloseClick,
  qaHook,
  role,
  sentiment
}) {
  const closeButton = onCloseClick && /*#__PURE__*/(0, _jsxRuntime.jsx)(_XUIIconButton.default, {
    ariaLabel: closeButtonLabel,
    className: `${_xuiClassNamespace.ns}-banner--close`,
    icon: _cross.default,
    onClick: onCloseClick,
    qaHook: qaHook && `${qaHook}-close--button`,
    size: "small"
  });
  const sentimentData = _sentiments.default[sentiment];
  const sentimentClass = sentimentData && sentimentData.class;
  const classes = (0, _clsx.default)(className, `${_xuiClassNamespace.ns}-banner`, {
    [`${_xuiClassNamespace.ns}-banner-layout`]: hasDefaultLayout
  }, sentimentClass);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: classes,
    "data-automationid": qaHook,
    role: role,
    children: [closeButton, children]
  });
}
var _default = exports.default = XUIBanner;
XUIBanner.propTypes = {
  children: _propTypes.default.node,
  className: _propTypes.default.string,
  /**
   * Title and accessibility label to be applied to the banner close "X" button.
   * This is required if an `onCloseClick` callback prop is provided.
   * <br />
   * Recommended English value: *Close*
   */
  closeButtonLabel(...parameters) {
    return (0, _checkRequiredProps.default)('onCloseClick', _propTypes.default.string.isRequired, ...parameters);
  },
  /** Defines whether the default layout class should be supplied */
  hasDefaultLayout: _propTypes.default.bool,
  /** Handles the click event for the action */
  onCloseClick: _propTypes.default.func,
  qaHook: _propTypes.default.string,
  /** Applies a role attribute to the banner element. Use `role = alert` for negative sentiment banners. */
  role: _propTypes.default.string,
  /** Alters the banner to show positive or negative sentiment */
  sentiment: _propTypes.default.oneOf(sentiments)
};
//# sourceMappingURL=XUIBanner.js.map
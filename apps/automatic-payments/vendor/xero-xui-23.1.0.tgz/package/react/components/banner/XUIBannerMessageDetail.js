"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _clsx = _interopRequireDefault(require("clsx"));
var _nanoid = require("nanoid");
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react = _interopRequireDefault(require("react"));
var _xuiClassNamespace = require("../helpers/xuiClassNamespace");
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function XUIBannerMessageDetail({
  className,
  messageDetails,
  qaHook
}) {
  const messageDetailClassName = (0, _clsx.default)(className, `${_xuiClassNamespace.ns}-banner--messagedetail`);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
    className: messageDetailClassName,
    "data-automationid": qaHook,
    children: messageDetails.map(listItem => /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
      children: listItem
    }, (0, _nanoid.nanoid)(5)))
  });
}
var _default = exports.default = XUIBannerMessageDetail;
XUIBannerMessageDetail.propTypes = {
  className: _propTypes.default.string,
  /** The banner message details to be displayed as a list */
  messageDetails: _propTypes.default.arrayOf(_propTypes.default.node).isRequired,
  qaHook: _propTypes.default.string
};
//# sourceMappingURL=XUIBannerMessageDetail.js.map
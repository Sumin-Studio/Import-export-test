import React from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import '@testing-library/jest-dom';
import { axe, toHaveNoViolations } from 'jest-axe';
import XUIBanner from '../XUIBanner';
import XUIBannerAction from '../XUIBannerAction';
import XUIBannerActions from '../XUIBannerActions';
import XUIBannerMessage from '../XUIBannerMessage';
import NOOP from '../../helpers/noop';

expect.extend(toHaveNoViolations);

describe('XUIBanner', () => {
  it('should match snapshot', () => {
    const { container } = render(<XUIBanner closeButtonLabel="Close" sentiment="positive" />);
    expect(container.firstChild).toMatchSnapshot();
  });
  it('should render without a close button if no close click function is provided', () => {
    render(<XUIBanner qaHook="test" />);
    expect(screen.queryByTestId('test-close--button')).not.toBeInTheDocument();
  });

  it('should render with a close button if close click function is provided', () => {
    render(<XUIBanner closeButtonLabel="Close" onCloseClick={NOOP} />);
    expect(screen.getByLabelText('Close')).toBeInTheDocument();
  });

  it('tabs in the correct order', async () => {
    const user = userEvent.setup();
    render(
      <XUIBanner closeButtonLabel="Close" onCloseClick={NOOP}>
        <XUIBannerMessage>Message here</XUIBannerMessage>
        <XUIBannerActions>
          <XUIBannerAction>Action 1</XUIBannerAction>
          <XUIBannerAction>Action 2</XUIBannerAction>
        </XUIBannerActions>
      </XUIBanner>,
    );

    await user.tab();
    expect(screen.getByLabelText('Close')).toHaveFocus();
    await user.tab();
    expect(screen.getByText('Action 1')).toHaveFocus();
    await user.tab();
    expect(screen.getByText('Action 2')).toHaveFocus();
  });

  test('passes accessibility testing', async () => {
    const { container } = render(<XUIBanner />);
    const results = await axe(container.firstElementChild);
    expect(results).toHaveNoViolations();
  });
});

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.formatBytes = exports.fakeUpload = exports.defaultProps = exports.defaultFileList = exports.baseClass = exports.acceptedFileList = void 0;
exports.getAnnouncementMessage = getAnnouncementMessage;
exports.getFileById = getFileById;
exports.parseUploadProgressPercentage = exports.getFileTypeIcon = void 0;
require("core-js/modules/es.array.includes.js");
require("core-js/modules/es.promise.js");
var _attach = _interopRequireDefault(require("@xero/xui-icon/icons/attach"));
var _email = _interopRequireDefault(require("@xero/xui-icon/icons/email"));
var _fileCsv = _interopRequireDefault(require("@xero/xui-icon/icons/file-csv"));
var _fileDocument = _interopRequireDefault(require("@xero/xui-icon/icons/file-document"));
var _fileExcel = _interopRequireDefault(require("@xero/xui-icon/icons/file-excel"));
var _filePdf = _interopRequireDefault(require("@xero/xui-icon/icons/file-pdf"));
var _fileSpreadsheet = _interopRequireDefault(require("@xero/xui-icon/icons/file-spreadsheet"));
var _fileWord = _interopRequireDefault(require("@xero/xui-icon/icons/file-word"));
var _fileZip = _interopRequireDefault(require("@xero/xui-icon/icons/file-zip"));
var _image = _interopRequireDefault(require("@xero/xui-icon/icons/image"));
var _nanoid = require("nanoid");
var _developmentConsole = require("../helpers/developmentConsole");
var _noop = _interopRequireDefault(require("../helpers/noop"));
var _xuiClassNamespace = require("../helpers/xuiClassNamespace");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const baseClass = exports.baseClass = `${_xuiClassNamespace.ns}-fileuploader`;

// Accepted file types listed in Xero Central
// https://central.xero.com/s/article/Manage-your-file-library#Aboutthefilelibrary
const fileExtensions = {
  // archives
  '7z': {
    icon: _fileZip.default,
    color: 'black-muted'
  },
  rar: {
    icon: _fileDocument.default,
    color: 'black-muted'
  },
  xzip: {
    icon: _fileZip.default,
    color: 'black-muted'
  },
  zip: {
    icon: _fileZip.default,
    color: 'black-muted'
  },
  zipx: {
    icon: _fileZip.default,
    color: 'black-muted'
  },
  // documents
  csv: {
    icon: _fileCsv.default,
    color: 'file_spreadsheet'
  },
  doc: {
    icon: _fileWord.default,
    color: 'blue'
  },
  docx: {
    icon: _fileWord.default,
    color: 'blue'
  },
  key: {
    icon: _fileDocument.default,
    color: 'black-muted'
  },
  keynote: {
    icon: _fileDocument.default,
    color: 'black-muted'
  },
  numbers: {
    icon: _fileSpreadsheet.default,
    color: 'file_spreadsheet'
  },
  'numbers-tef': {
    icon: _fileSpreadsheet.default,
    color: 'file_spreadsheet'
  },
  odf: {
    icon: _fileDocument.default,
    color: 'black-muted'
  },
  ods: {
    icon: _fileSpreadsheet.default,
    color: 'file_spreadsheet'
  },
  odt: {
    icon: _fileDocument.default,
    color: 'black-muted'
  },
  pages: {
    icon: _fileDocument.default,
    color: 'black-muted'
  },
  'pages-tef': {
    icon: _fileDocument.default,
    color: 'black-muted'
  },
  pdf: {
    icon: _filePdf.default,
    color: 'file_pdf'
  },
  ppt: {
    icon: _fileDocument.default,
    color: 'black-muted'
  },
  pptx: {
    icon: _fileDocument.default,
    color: 'black-muted'
  },
  rtf: {
    icon: _fileDocument.default,
    color: 'black-muted'
  },
  txt: {
    icon: _fileDocument.default,
    color: 'black-muted'
  },
  xls: {
    icon: _fileExcel.default,
    color: 'file_spreadsheet'
  },
  xlsx: {
    icon: _fileExcel.default,
    color: 'file_spreadsheet'
  },
  // email
  eml: {
    icon: _email.default,
    color: 'black-muted'
  },
  msg: {
    icon: _email.default,
    color: 'black-muted'
  }
};
const formatBytes = (bytes, fileSizeUnits) => {
  if (bytes === 0) return `0 ${fileSizeUnits[0]}`;
  const k = 1024;
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / k ** i).toFixed(2))} ${fileSizeUnits[i]}`;
};
exports.formatBytes = formatBytes;
const getFileTypeIcon = (name, mimeType) => {
  const defaultIcon = {
    color: 'black-muted',
    icon: _attach.default
  };
  if (typeof name !== 'string' || typeof mimeType !== 'string') {
    return defaultIcon;
  }
  // All types of images use the same icon, so it's easier to know from the MIME type
  if (mimeType.includes('image')) {
    return {
      color: 'black-muted',
      icon: _image.default
    };
  }
  const fileType = name.substring(name.lastIndexOf('.') + 1).toLowerCase();

  // Cannot assert that fileType will match key in fileExtensions, safe because of defaultIcon fallback
  // @ts-ignore
  return fileExtensions[fileType] || defaultIcon;
};
exports.getFileTypeIcon = getFileTypeIcon;
function getFileById(fileList, id) {
  return fileList.find(file => file.uid === id);
}
function getAnnouncementMessage({
  fileList,
  unannouncedFileIds,
  getUploadFileErrorMessage,
  getUploadFileSuccessMessage,
  getUploadMultipleFilesErrorMessage,
  uploadMultipleFilesSuccessMessage
}) {
  const firstUnnanouncedFile = getFileById(fileList, unannouncedFileIds[0]);
  if (fileList.filter(file => unannouncedFileIds.includes(file.uid)).every(file => file.status === 'done')) {
    if (unannouncedFileIds.length === 1 && firstUnnanouncedFile) {
      return getUploadFileSuccessMessage === null || getUploadFileSuccessMessage === void 0 ? void 0 : getUploadFileSuccessMessage(firstUnnanouncedFile.originalFile.name);
    }
    return uploadMultipleFilesSuccessMessage;
  }
  if (unannouncedFileIds.length === 1 && firstUnnanouncedFile) {
    return getUploadFileErrorMessage === null || getUploadFileErrorMessage === void 0 ? void 0 : getUploadFileErrorMessage(firstUnnanouncedFile.originalFile.name);
  }
  return getUploadMultipleFilesErrorMessage === null || getUploadMultipleFilesErrorMessage === void 0 ? void 0 : getUploadMultipleFilesErrorMessage(fileList.filter(file => unannouncedFileIds.includes(file.uid)).filter(file => file.status === 'error').length);
}

// originalFile should be File, but File API isn't implemented in Node.js (when running vis-reg tests)
// so just use the object here for tests
const defaultFileList = exports.defaultFileList = [{
  uid: (0, _nanoid.nanoid)(10),
  status: 'uploading',
  originalFile: {
    name: 'INV-1001.jpg',
    type: 'image/jpeg',
    size: 11111
  }
}, {
  uid: (0, _nanoid.nanoid)(10),
  status: 'done',
  originalFile: {
    name: 'INV-1002.pdf',
    type: 'application/pdf',
    size: 2222
  }
}, {
  uid: (0, _nanoid.nanoid)(10),
  status: 'error',
  originalFile: {
    name: 'INV-1003.zip',
    type: 'application/zip',
    size: 33333
  }
}, {
  uid: (0, _nanoid.nanoid)(10),
  status: 'uploading',
  originalFile: {
    name: 'INV-1004.zip',
    type: 'application/zip',
    size: 44444
  },
  uploadProgressPercentage: 50
}];
const acceptedFileList = exports.acceptedFileList = Object.keys(fileExtensions).map((extension, i) => ({
  uid: (0, _nanoid.nanoid)(10),
  status: 'done',
  originalFile: {
    name: `filetype${i}.${extension}`,
    type: 'application/zip',
    size: 44444
  }
}));

// This is just for tests/docs use
const defaultProps = exports.defaultProps = {
  buttonText: 'Select file',
  cancelButtonText: 'Cancel',
  defaultErrorMessage: 'Failed to upload file',
  getDeleteLabel: () => `Delete file`,
  dropZoneMessage: 'Drag and drop file(s) or select manually',
  errorIconAriaLabel: 'Error',
  fileList: [],
  // Usually the file won't be that large, but it's better to include all units
  fileSizeUnits: ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
  label: 'Upload document(s)',
  retryButtonText: 'Retry',
  secondaryButtonOnClick: _noop.default,
  uploadingIconAriaLabel: 'Uploading',
  uploadingMessage: 'Uploading...',
  uploadingMultipleFilesMessage: 'Multiple files uploading, please wait',
  uploadMultipleFilesSuccessMessage: 'Multiple files uploaded',
  onDelete: _noop.default,
  onFilesChange: _noop.default,
  onRetry: _noop.default
};
const fakeUpload = () => {
  const fakeStatus = ['done', 'error'][Math.floor(Math.random() * 2)];
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (fakeStatus === 'error') {
        reject(new Error('Upload failed'));
      }
      resolve();
    }, 1000);
  });
};
exports.fakeUpload = fakeUpload;
const parseUploadProgressPercentage = value => {
  if (value === undefined) return undefined;
  if (Number.isNaN(value)) return undefined;
  if (value < 0 || value > 100) {
    const newValue = value < 0 ? 0 : 100;
    (0, _developmentConsole.logWarning)({
      componentName: 'XUIFileUploader',
      message: `uploadProgressPercentage was provided ${value}. This has been rounded to ${newValue}.`
    });
    return newValue;
  }
  return Math.floor(value);
};
exports.parseUploadProgressPercentage = parseUploadProgressPercentage;
//# sourceMappingURL=helpers.js.map
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/es.array.includes.js");
var _clsx = _interopRequireDefault(require("clsx"));
var _nanoid = require("nanoid");
var React = _interopRequireWildcard(require("react"));
var _XUIButton = _interopRequireDefault(require("../button/XUIButton"));
var _XUIControlWrapper = _interopRequireDefault(require("../controlwrapper/XUIControlWrapper"));
var _ariaHelpers = _interopRequireWildcard(require("../helpers/ariaHelpers"));
var _labelRequiredError = _interopRequireDefault(require("../helpers/labelRequiredError"));
var _useLiveRegion = require("../helpers/useLiveRegion");
var _usePrevious = _interopRequireDefault(require("../helpers/usePrevious"));
var _xuiClassNamespace = require("../helpers/xuiClassNamespace");
var _helpers = require("./helpers");
var _XUIFileList = _interopRequireDefault(require("./XUIFileList"));
var _XUIFileListItem = _interopRequireDefault(require("./XUIFileListItem"));
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function XUIFileUploader({
  acceptedFileExtensions,
  acceptsMultipleFiles = true,
  buttonText,
  cancelButtonText,
  className,
  defaultErrorMessage,
  dropZoneMessage,
  errorIconAriaLabel,
  fieldClassName,
  fileList,
  fileListClassName,
  fileSizeUnits,
  getDeleteLabel,
  getUploadFileErrorMessage,
  getUploadFileSuccessMessage,
  getUploadingFileMessage,
  getUploadMultipleFilesErrorMessage,
  hasDragAndDrop,
  hintMessage,
  isDisabled,
  isFieldLayout,
  isInvalid,
  isLabelHidden,
  label,
  labelClassName,
  labelId,
  onCancel,
  onDelete,
  onFilesChange,
  onRetry,
  qaHook,
  retryButtonText,
  secondaryButtonOnClick,
  secondaryButtonText,
  showFilesAsMultiline = true,
  showIcon = true,
  uploadingIconAriaLabel,
  uploadingMessage,
  uploadingMultipleFilesMessage,
  uploadMultipleFilesSuccessMessage,
  validationMessage
}) {
  const labelRef = /*#__PURE__*/React.createRef();
  const inputEl = React.useRef(null);
  const uploadButtonRef = React.useRef(null);
  const [dragState, setDragState] = React.useState();
  const [announcedFileIds, setAnnouncedFileIds] = React.useState([]);
  const [unannouncedFileIds, setUnannouncedFileIds] = React.useState([]);
  const previousUnnanouncedFileIds = (0, _usePrevious.default)(unannouncedFileIds);
  const [liveRegion, setLiveRegionText] = (0, _useLiveRegion.useLiveRegion)('file-uploader');
  const invalidState = isInvalid && !isDisabled;
  const noStatusMessagesDefined = getUploadFileErrorMessage == null && getUploadFileSuccessMessage == null && uploadMultipleFilesSuccessMessage == null && getUploadMultipleFilesErrorMessage == null;
  React.useEffect(
  // eslint-disable-next-line prefer-arrow-callback
  function keepTrackOfUnnanouncedFiles() {
    const fileIdsNeedingAnnouncement = fileList.filter(file => file.status === 'uploading' || !announcedFileIds.includes(file.uid)).map(file => file.uid);
    setUnannouncedFileIds(fileIdsNeedingAnnouncement);
    if (announcedFileIds.filter(announcedFileId => !fileIdsNeedingAnnouncement.includes(announcedFileId)).length === announcedFileIds.length) {
      return;
    }
    setAnnouncedFileIds(announcedFileIds.filter(announcedFileId => !fileIdsNeedingAnnouncement.includes(announcedFileId)));
  }, [announcedFileIds, fileList]);
  React.useEffect(
  // eslint-disable-next-line prefer-arrow-callback
  function announceNewFiles() {
    if (!(fileList !== null && fileList !== void 0 && fileList.length) || noStatusMessagesDefined) {
      return;
    }
    const newUnnanouncedFileIds = unannouncedFileIds.filter(unannouncedFileId => !(previousUnnanouncedFileIds !== null && previousUnnanouncedFileIds !== void 0 && previousUnnanouncedFileIds.includes(unannouncedFileId)));
    const firstNewUnnanouncedFile = (0, _helpers.getFileById)(fileList, newUnnanouncedFileIds[0]);
    let announcementMessage;
    if (newUnnanouncedFileIds.length === 1 && firstNewUnnanouncedFile) {
      announcementMessage = getUploadingFileMessage === null || getUploadingFileMessage === void 0 ? void 0 : getUploadingFileMessage(firstNewUnnanouncedFile.originalFile.name);
    }
    if (newUnnanouncedFileIds.length > 1) {
      announcementMessage = uploadingMultipleFilesMessage;
    }
    if (announcementMessage) {
      setLiveRegionText(announcementMessage);
    }
  }, [fileList, getUploadingFileMessage, noStatusMessagesDefined, previousUnnanouncedFileIds, setLiveRegionText, unannouncedFileIds, uploadingMultipleFilesMessage]);
  React.useEffect(
  // eslint-disable-next-line prefer-arrow-callback
  function announceCompletedFiles() {
    if (!(fileList !== null && fileList !== void 0 && fileList.length) || noStatusMessagesDefined) {
      return;
    }
    const isUploadingFiles = fileList.some(file => file.status === 'uploading');
    if (isUploadingFiles) {
      return;
    }
    if (fileList.every(file => announcedFileIds.includes(file.uid)) && !isUploadingFiles) {
      return;
    }
    const announcementMessage = (0, _helpers.getAnnouncementMessage)({
      fileList,
      unannouncedFileIds,
      getUploadFileErrorMessage,
      getUploadFileSuccessMessage,
      getUploadMultipleFilesErrorMessage,
      uploadMultipleFilesSuccessMessage
    });
    if (announcementMessage) {
      setLiveRegionText(announcementMessage);
    }
    setAnnouncedFileIds(fileList.map(file => file.uid));
    setUnannouncedFileIds([]);
  }, [announcedFileIds, fileList, getUploadFileErrorMessage, getUploadFileSuccessMessage, getUploadMultipleFilesErrorMessage, noStatusMessagesDefined, setLiveRegionText, unannouncedFileIds, uploadMultipleFilesSuccessMessage]);
  const onClick = () => {
    var _inputEl$current;
    (_inputEl$current = inputEl.current) === null || _inputEl$current === void 0 || _inputEl$current.click();
  };
  const handleOnChange = (files, event) => {
    const enhancedFileList = Array.from(files).map(file => ({
      uid: (0, _nanoid.nanoid)(10),
      // A unique identifier used as the key of file items
      status: '',
      // user could change it to: uploading / error / done
      originalFile: file // original File object
    }));
    onFilesChange(enhancedFileList, event);
  };
  const onDragChange = event => {
    // Prevent default behavior (Prevent file from being opened)
    event.preventDefault();
    if (isDisabled) {
      return;
    }
    const {
      type,
      dataTransfer
    } = event;
    setDragState(type);
    if (type === 'drop' && dataTransfer.files.length > 0) {
      handleOnChange(dataTransfer.files, event);
    }
  };
  const onInputChange = event => {
    const {
      target
    } = event;
    handleOnChange(event.target.files || new FileList(), event);
    // Make sure users can upload the same file
    target.value = '';
  };
  const dropZoneClassNames = hasDragAndDrop ? (0, _clsx.default)(`${_helpers.baseClass}--dropzone`, dragState === 'dragover' && `${_helpers.baseClass}--dropzone-active`, isDisabled && `${_helpers.baseClass}--dropzone-disabled`, invalidState && dragState !== 'dragover' && `${_helpers.baseClass}--dropzone-invalid`) : '';
  const wrapperIds = (0, _ariaHelpers.default)({
    labelId
  });
  const wrapperProps = {
    labelClassName,
    label,
    labelId,
    labelRef,
    isLabelHidden,
    isInvalid: invalidState,
    validationMessage,
    hintMessage
  };
  const inputProps = {
    accept: acceptedFileExtensions,
    disabled: isDisabled,
    multiple: acceptsMultipleFiles,
    ref: inputEl,
    type: 'file',
    ...(0, _ariaHelpers.getAriaAttributes)(wrapperIds, wrapperProps)
  };
  const manageFocusOnDeleteOrCancel = () => {
    var _uploadButtonRef$curr;
    if (typeof (uploadButtonRef === null || uploadButtonRef === void 0 || (_uploadButtonRef$curr = uploadButtonRef.current) === null || _uploadButtonRef$curr === void 0 ? void 0 : _uploadButtonRef$curr.focus) === 'function') {
      uploadButtonRef.current.focus();
    }
  };
  React.useEffect(() => {
    var _labelRef$current;
    (0, _labelRequiredError.default)(XUIFileUploader.name, ['includes a label with text', 'labelId provided'], [Boolean(((_labelRef$current = labelRef.current) === null || _labelRef$current === void 0 ? void 0 : _labelRef$current.textContent) && !isLabelHidden),
    // @ts-ignore
    typeof (label === null || label === void 0 ? void 0 : label[0]) === 'string', Boolean(labelId)]);
  }, [isLabelHidden, label, labelId, labelRef]);
  const handleCancel = (file, files, event) => {
    onDelete(file, files, event);
    if (onCancel) {
      onCancel(file, files, event);
    }
    manageFocusOnDeleteOrCancel();
  };
  const handleDelete = (file, files, event) => {
    onDelete(file, files, event);
    manageFocusOnDeleteOrCancel();
  };
  const buildDeleteLabel = fileName => getDeleteLabel(fileName);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: (0, _clsx.default)(className, _helpers.baseClass, isFieldLayout && `${_xuiClassNamespace.ns}-field-layout`),
    "data-automationid": qaHook,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_XUIControlWrapper.default, {
      fieldClassName: fieldClassName,
      wrapperIds: wrapperIds,
      ...wrapperProps,
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: dropZoneClassNames,
        onDragLeave: onDragChange,
        onDragOver: onDragChange,
        onDrop: onDragChange,
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
          className: `${_helpers.baseClass}--input`,
          ...inputProps,
          "aria-hidden": true,
          onChange: onInputChange,
          "data-automationid": qaHook && `${qaHook}--input`,
          tabIndex: -1
        }), hasDragAndDrop && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          children: dropZoneMessage
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_XUIButton.default, {
            isDisabled: isDisabled,
            onClick: onClick,
            ref: uploadButtonRef,
            size: "small",
            children: buttonText
          }), secondaryButtonText && secondaryButtonOnClick && /*#__PURE__*/(0, _jsxRuntime.jsx)(_XUIButton.default, {
            isDisabled: isDisabled,
            onClick: secondaryButtonOnClick,
            size: "small",
            className: "xui-margin-left-xsmall",
            children: secondaryButtonText
          })]
        })]
      })
    }), fileList.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)(_XUIFileList.default, {
      className: fileListClassName,
      qaHook: qaHook && `${qaHook}-filelist`,
      children: fileList.map(file => /*#__PURE__*/(0, _jsxRuntime.jsx)(_XUIFileListItem.default, {
        cancelButtonText: cancelButtonText,
        defaultErrorMessage: defaultErrorMessage,
        deleteLabel: buildDeleteLabel(file.originalFile.name),
        errorIconAriaLabel: errorIconAriaLabel,
        file: file,
        fileSizeUnits: fileSizeUnits,
        isMultiline: showFilesAsMultiline,
        onCancel: event => handleCancel(file, fileList, event),
        onDelete: event => handleDelete(file, fileList, event),
        onRetry: event => onRetry(file, fileList, event),
        qaHook: qaHook && `${qaHook}-filelistitem-${file.uid}`,
        retryButtonText: retryButtonText,
        showIcon: showIcon,
        uploadingIconAriaLabel: uploadingIconAriaLabel,
        uploadingMessage: uploadingMessage
      }, file.uid))
    }), liveRegion]
  });
}
var _default = exports.default = XUIFileUploader;
//# sourceMappingURL=XUIFileUploader.js.map
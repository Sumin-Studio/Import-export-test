import * as React from 'react';
import { BaseProps } from './XUIFileListItem';
export interface XUIFileUploaderProps extends BaseProps {
    /**
     * File extensions accepted by the file input
     */
    acceptedFileExtensions?: string;
    /**
     * Whether to support selecting multiple files
     */
    acceptsMultipleFiles?: boolean;
    /**
     * Button text
     * <br />
     * Recommended English value: *Select file*
     */
    buttonText: string;
    /**
     * Class names to be added to the div wrapping the select button/drop zone and file list
     */
    className?: string;
    /**
     * The message that shows in the drop zone
     * <br />
     * Recommended English value: *Drag and drop file(s) or select manually*
     */
    dropZoneMessage: string;
    /**
     * Class names to be added to the div wrapping the select button/drop zone
     */
    fieldClassName?: string;
    /**
     * Array of the following format Object:
     * <br />
     * {
     *   uid: String, // Unique identifier used as a file key. This value is generated when the file input changed, and should not be modified
     *   status: String, // User could change it to: uploading / done / error
     *   originalFile: File, // Original File object
     *   errorMessage: String, // Optional, custom error message, will overwrite prop `defaultErrorMessage`
     *   rightContent: ReactNode, // Optional, custom rightContent for files with `done` status, shows in the left of delete icon
     * }
     */
    fileList: FileObject[];
    /**
     * Class names to be added to the div wrapping filelist
     */
    fileListClassName?: string;
    /**
     * Label for "delete" icon for accessibility.
     *
     * Recommended English value: *Delete file test.jpg* (where *test.jpg* is the `fileName`)
     */
    getDeleteLabel: (fileName: string) => string;
    /**
     * Called when a single file completes uploading with error. Return the localised message to be read by screen readers.
     *
     * Recommended English value: *File test.jpg failed to upload. More information beneath the 'select file' button.* (where test.jpg is the `fileName`, and "select file" is `buttonText`)
     */
    getUploadFileErrorMessage?: (fileName: string) => string;
    /**
     * Called when a single file completes uploading without error. Return the localised message to be read by screen readers.
     *
     * Recommended English value: *File test.jpg uploaded* (where *test.jpg* is the `fileName`)
     */
    getUploadFileSuccessMessage?: (fileName: string) => string;
    /**
     * Called when a single file starts uploading. Return the localised message to be read by screen readers.
     *
     * Recommended English value: *Uploading test.jpg* (where *test.jpg* is the `fileName`)
     */
    getUploadingFileMessage?: (fileName: string) => string;
    /**
     * Called when multiple files complete uploading with one or more errors. Return the localised message to be read by screen readers. Only relevant if the file list can contain more than one file.
     *
     * Recommended English value: *5 files failed to upload. More information beneath the 'select file' button.* (where *5* is the `failedCount`, *files* is pluralised as appropriate, and "select file" is `buttonText`)
     */
    getUploadMultipleFilesErrorMessage?: (failedCount: number) => string;
    /**
     * Whether to support the drag and drop to upload
     */
    hasDragAndDrop?: boolean;
    /**
     * Hint message to show under the input
     */
    hintMessage?: React.ReactNode;
    /**
     * Whether the fileUploader is disabled
     */
    isDisabled?: boolean;
    /**
     * Whether to use the field layout classes
     */
    isFieldLayout?: boolean;
    /**
     * Whether the current input value is invalid
     */
    isInvalid?: boolean;
    /**
     * Prevents the label element from being displayed on the page. Label is still accessible to screen readers
     */
    isLabelHidden?: boolean;
    /**
     * Label to show above the input. If for a single file uploader, specify this in the label, e.g. "Upload a document"
     */
    label?: React.ReactNode;
    /**
     * Class names to add to the label
     */
    labelClassName?: string;
    /**
     * Provide a specific label ID which will be used as the aria-labelledby property
     */
    labelId?: string;
    /**
     * Message to be read by screen readers when multiple files start uploading. Only relevant if `acceptsMultipleFiles` is true.
     *
     * Recommended English value: *Multiple files uploading, please wait*
     */
    uploadingMultipleFilesMessage?: string;
    /**
     * Message to be read by screen readers when multiple files complete uploading without any errors. Only relevant if the file list can contain more than one file.
     *
     * Recommended English value: *Multiple files uploaded*
     */
    uploadMultipleFilesSuccessMessage?: string;
    /**
     * Called when the cancel button is clicked
     * <br />
     * `(file, fileList, event) => {}`
     */
    onCancel?: FileHandler;
    /**
     * Called when the delete button is clicked
     * <br />
     * `(file, fileList, event) => {}`
     */
    onDelete: FileHandler;
    /**
     * Called when a file is opened or dropped
     * <br />
     * `(fileList, event) => {}`
     */
    onFilesChange: (fileList: FileObject[], event: React.ChangeEvent<HTMLElement> | React.DragEvent<HTMLElement>) => void;
    /**
     * Called when retry button is clicked
     * <br />
     * `(file, fileList, event) => {}`
     */
    onRetry: FileHandler;
    /**
     * Show multi line in the file list item
     */
    showFilesAsMultiline?: boolean;
    /**
     * Validation message to show under the input if `isInvalid` is true
     */
    validationMessage?: React.ReactNode;
}
type ConditionalProps = {
    /**
     * Text to show on a secondary button within the file uploader drag and drop
     */
    secondaryButtonText: string;
    /**
     * Called when the optional secondary button is clicked. Required if the `secondaryButtonText` prop is set to a string.
     */
    secondaryButtonOnClick: () => void;
} | {
    /**
     * Text to show on a secondary button within the file uploader drag and drop
     */
    secondaryButtonText?: never;
    /**
     * Called when the optional secondary button is clicked. Required if the `secondaryButtonText` prop is set to a string.
     */
    secondaryButtonOnClick?: never;
};
export type FileObject = {
    errorMessage?: string;
    hideRetryButton?: boolean;
    originalFile: File;
    rightContent?: React.ReactNode;
    supplementaryContent?: React.ReactNode;
    status: string;
    uid: string;
    uploadProgressPercentage?: number;
};
export type FileHandler = (file: FileObject, fileList: FileObject[], event: InteractionEvent) => void;
type InteractionEvent = React.MouseEvent | React.KeyboardEvent;
declare function XUIFileUploader({ acceptedFileExtensions, acceptsMultipleFiles, buttonText, cancelButtonText, className, defaultErrorMessage, dropZoneMessage, errorIconAriaLabel, fieldClassName, fileList, fileListClassName, fileSizeUnits, getDeleteLabel, getUploadFileErrorMessage, getUploadFileSuccessMessage, getUploadingFileMessage, getUploadMultipleFilesErrorMessage, hasDragAndDrop, hintMessage, isDisabled, isFieldLayout, isInvalid, isLabelHidden, label, labelClassName, labelId, onCancel, onDelete, onFilesChange, onRetry, qaHook, retryButtonText, secondaryButtonOnClick, secondaryButtonText, showFilesAsMultiline, showIcon, uploadingIconAriaLabel, uploadingMessage, uploadingMultipleFilesMessage, uploadMultipleFilesSuccessMessage, validationMessage, }: XUIFileUploaderProps & ConditionalProps): React.JSX.Element;
export default XUIFileUploader;

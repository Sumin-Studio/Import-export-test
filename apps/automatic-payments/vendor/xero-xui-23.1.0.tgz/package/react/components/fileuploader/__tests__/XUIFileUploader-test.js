import React from 'react';
import { nanoid } from 'nanoid';
import { fireEvent, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { axe, toHaveNoViolations } from 'jest-axe';
import XUIFileUploader from '../XUIFileUploader';
import { defaultFileList, defaultProps } from '../helpers';

expect.extend(toHaveNoViolations);

const testFileList = defaultFileList.map((file, index) => ({ ...file, uid: index.toString() }));
const FileUploaderWrapper = props => (
  <XUIFileUploader {...defaultProps} labelId="testLabel" {...props} />
);
const WithFileListWrapper = props => <FileUploaderWrapper fileList={testFileList} {...props} />;
const DragWrapper = props => <FileUploaderWrapper {...props} hasDragAndDrop />;

const secondaryButtonOnClick = jest.fn();
const secondaryButtonText = 'Add another file';
const SecondaryButtonWrapper = () => (
  <FileUploaderWrapper
    secondaryButtonText={secondaryButtonText}
    secondaryButtonOnClick={secondaryButtonOnClick}
    qaHook="test"
  />
);

const inputChangeEventFiles = [
  { name: 'INV-1001.jpg', type: 'image/jpeg', size: 11111 },
  { name: 'INV-1002.pdf', type: 'application/pdf', size: 2222 },
];

describe('<XUIFileUploader/>', () => {
  test('should render expected markup', () => {
    const { container } = render(
      <FileUploaderWrapper
        acceptedFileExtensions="image/*"
        className="custom-root-class"
        fieldClassName="custom-filed-class"
        isFieldLayout
        label={<>Upload document(s)</>}
        labelClassName="custom-label-class"
        qaHook="fileUploader-test"
      />,
    );
    expect(container).toMatchSnapshot();
  });

  test('should not show validationMessage when is disabled', () => {
    render(<FileUploaderWrapper isDisabled isInvalid validationMessage="Test validation text" />);
    expect(screen.queryByText('Test validation text')).not.toBeInTheDocument();
  });

  test('should call the passed onFilesChange when open files', async () => {
    const onFilesChange = jest.fn();
    render(<FileUploaderWrapper onFilesChange={onFilesChange} qaHook="test" />);

    await userEvent.upload(screen.getByTestId('test--input'), inputChangeEventFiles);
    expect(onFilesChange).toHaveBeenCalledTimes(1);
  });

  test('should update live region text on single file upload started', async () => {
    // Arrange
    const file = inputChangeEventFiles[0];
    const getAnnouncementText = fileName => `Uploading ${fileName}`;
    const getUploadingFileMessage = jest.fn().mockImplementationOnce(getAnnouncementText);

    const { rerender } = render(
      <FileUploaderWrapper getUploadingFileMessage={getUploadingFileMessage} qaHook="test" />,
    );

    // Act
    await userEvent.upload(screen.getByTestId('test--input'), file);

    const updatedFiles = [{ originalFile: { ...file }, status: 'uploading', uid: nanoid(10) }];

    rerender(
      <FileUploaderWrapper
        fileList={updatedFiles}
        getUploadingFileMessage={getUploadingFileMessage}
      />,
    );

    // Assert
    expect(screen.getByText(getAnnouncementText(file.name))).toBeDefined();
  });

  test('should update live region text on multiple file upload started', async () => {
    // Arrange
    const uploadingMultipleFilesMessage = 'Multiple files uploading, please wait';

    const { rerender } = render(
      <FileUploaderWrapper
        uploadingMultipleFilesMessage={uploadingMultipleFilesMessage}
        qaHook="test"
      />,
    );

    // Act
    await userEvent.upload(screen.getByTestId('test--input'), inputChangeEventFiles);

    const updatedFiles = inputChangeEventFiles.map(file => ({
      originalFile: { ...file },
      status: 'uploading',
      uid: nanoid(10),
    }));

    rerender(
      <FileUploaderWrapper
        fileList={updatedFiles}
        uploadingMultipleFilesMessage={uploadingMultipleFilesMessage}
      />,
    );

    // Assert
    expect(screen.getByText(uploadingMultipleFilesMessage)).toBeDefined();
  });

  test('should update live region text on single file upload successfully uploaded', async () => {
    // Arrange
    const file = { ...defaultFileList[0], status: 'uploading' };
    const getAnnouncementText = fileName => `File ${fileName} uploaded`;
    const getUploadFileSuccessMessage = jest.fn().mockImplementationOnce(getAnnouncementText);

    const { rerender } = render(
      <FileUploaderWrapper
        getUploadFileSuccessMessage={getUploadFileSuccessMessage}
        fileList={[file]}
      />,
    );

    // Act
    const updatedFile = { ...file, status: 'done' };
    rerender(
      <FileUploaderWrapper
        getUploadFileSuccessMessage={getUploadFileSuccessMessage}
        fileList={[updatedFile]}
      />,
    );

    // Assert
    expect(screen.getByText(getAnnouncementText(file.originalFile.name))).toBeDefined();
  });

  test('should update live region text on single file upload error', async () => {
    // Arrange
    const file = { ...defaultFileList[0], status: 'uploading' };
    const getAnnouncementText = fileName =>
      `File ${fileName} failed to upload. More information beneath the 'select file' button.`;
    const getUploadFileErrorMessage = jest.fn().mockImplementationOnce(getAnnouncementText);

    const { rerender } = render(
      <FileUploaderWrapper
        getUploadFileErrorMessage={getUploadFileErrorMessage}
        fileList={[file]}
      />,
    );

    // Act
    const updatedFile = { ...file, status: 'error' };
    rerender(
      <FileUploaderWrapper
        getUploadFileErrorMessage={getUploadFileErrorMessage}
        fileList={[updatedFile]}
      />,
    );

    // Assert
    expect(screen.getByText(getAnnouncementText(file.originalFile.name))).toBeDefined();
  });

  test('should update live region text on multiple files successfully uploaded', async () => {
    // Arrange
    const files = [
      { ...defaultFileList[0], status: 'uploading' },
      { ...defaultFileList[1], status: 'uploading' },
    ];
    const uploadMultipleFilesSuccessMessage = 'Multiple files uploaded';

    const { rerender } = render(
      <FileUploaderWrapper
        uploadMultipleFilesSuccessMessage={uploadMultipleFilesSuccessMessage}
        fileList={files}
      />,
    );

    // Act
    const updatedFiles = [
      { ...files[0], status: 'done' },
      { ...files[1], status: 'done' },
    ];
    rerender(
      <FileUploaderWrapper
        uploadMultipleFilesSuccessMessage={uploadMultipleFilesSuccessMessage}
        fileList={updatedFiles}
      />,
    );

    // Assert
    expect(screen.getByText(uploadMultipleFilesSuccessMessage)).toBeDefined();
  });

  test('should update live region text on multiple files uploaded with any errored', async () => {
    // Arrange
    const files = [
      { ...defaultFileList[0], status: 'uploading' },
      { ...defaultFileList[1], status: 'uploading' },
    ];
    const getAnnouncementText = fileCount =>
      `${fileCount} file failed to upload. More information beneath the 'select file' button.`;
    const getUploadMultipleFilesErrorMessage = jest
      .fn()
      .mockImplementationOnce(getAnnouncementText);

    const { rerender } = render(
      <FileUploaderWrapper
        getUploadMultipleFilesErrorMessage={getUploadMultipleFilesErrorMessage}
        fileList={files}
      />,
    );

    // Act
    const updatedFiles = [
      { ...files[0], status: 'done' },
      { ...files[1], status: 'error' },
    ];
    rerender(
      <FileUploaderWrapper
        getUploadMultipleFilesErrorMessage={getUploadMultipleFilesErrorMessage}
        fileList={updatedFiles}
      />,
    );

    // Assert
    expect(screen.getByText(getAnnouncementText(1))).toBeDefined();
  });

  test('should not update live region text when multiple files uploading and one errors', async () => {
    // Arrange
    const files = [
      { ...defaultFileList[0], status: 'uploading' },
      { ...defaultFileList[1], status: 'uploading' },
    ];
    const getAnnouncementText = jest.fn().mockImplementationOnce(() => 'foo');

    const { rerender } = render(
      <FileUploaderWrapper
        getUploadMultipleFilesErrorMessage={getAnnouncementText}
        getUploadFileErrorMessage={getAnnouncementText}
        fileList={files}
      />,
    );

    // Act
    const updatedFiles = [
      { ...files[0], status: 'uploading' },
      { ...files[1], status: 'error' },
    ];
    rerender(
      <FileUploaderWrapper
        getUploadMultipleFilesErrorMessage={getAnnouncementText}
        getUploadFileErrorMessage={getAnnouncementText}
        fileList={updatedFiles}
      />,
    );

    // Assert
    expect(screen.queryByText(`foo`)).toBeNull();
  });

  test(`given getDeleteLabel prop it should set the delete button's accessible label`, async () => {
    // Arrange
    const file = defaultFileList[1];
    const getDeleteLabel = () => `Delete file`;
    render(<FileUploaderWrapper getDeleteLabel={getDeleteLabel} fileList={[file]} />);

    // Assert
    expect(
      screen.getByRole('button', { name: getDeleteLabel(file.originalFile.name) }),
    ).toBeDefined();
  });

  test('should pass accessibility testing', async () => {
    const { container } = render(<FileUploaderWrapper />);
    const results = await axe(container);
    expect(results).toHaveNoViolations();
  });

  describe('secondary button', () => {
    test('should render the secondaryButtonText inside the FileUploader if prop is passed', () => {
      render(<SecondaryButtonWrapper />);
      expect(screen.getByText(secondaryButtonText)).toBeInTheDocument();
    });

    test('should call the secondaryButtonOnClick callback if the secondaryButtonText is clicked', async () => {
      render(<SecondaryButtonWrapper />);
      await userEvent.click(screen.getByText(secondaryButtonText));
      expect(secondaryButtonOnClick).toHaveBeenCalled();
    });

    test('should render expected markup', () => {
      const { container } = render(<SecondaryButtonWrapper />);
      expect(container).toMatchSnapshot();
    });
  });

  describe('<FileList/>', () => {
    test('should render expected markup', () => {
      const { container } = render(
        <WithFileListWrapper
          fileList={[{ ...testFileList[1], rightContent: <button>test rightContent</button> }]}
          fileListClassName="custom-filelist-class"
        />,
      );
      expect(container).toMatchSnapshot();
    });

    test('should render the provided size unit when file size is 0', () => {
      render(
        <WithFileListWrapper
          fileList={[
            {
              uid: nanoid(10),
              status: 'done',
              originalFile: { name: 'test1.jpg', type: 'image/jpeg', size: 0 },
            },
          ]}
        />,
      );

      expect(screen.getByText('0 B')).toBeTruthy;
    });

    test('should call the passed onCancel when the cancel button is clicked', async () => {
      const onCancel = jest.fn();
      render(<WithFileListWrapper onCancel={onCancel} />);

      await userEvent.click(screen.getAllByText('Cancel')[0]);
      expect(onCancel).toHaveBeenCalledTimes(1);
    });

    test('should call the passed onDelete when the cancel button is clicked', async () => {
      const onDelete = jest.fn();
      render(<WithFileListWrapper onDelete={onDelete} />);

      await userEvent.click(screen.getAllByText('Cancel')[0]);
      expect(onDelete).toHaveBeenCalledTimes(1);
    });

    test('should call the passed onRetry when the cancel button is clicked', async () => {
      const onRetry = jest.fn();
      render(<WithFileListWrapper onRetry={onRetry} />);

      await userEvent.click(screen.getAllByText('Retry')[0]);
      expect(onRetry).toHaveBeenCalledTimes(1);
    });

    test('should pass accessibility testing', async () => {
      const { container } = render(
        <WithFileListWrapper errorIconAriaLabel="Error" uploadingIconAriaLabel="Uploading" />,
      );
      const results = await axe(container);
      expect(results).toHaveNoViolations();
    });

    test('should render supplementary content when prop is provided', () => {
      const container = render(
        <WithFileListWrapper
          fileList={[
            {
              ...testFileList[1],
              supplementaryContent: <button>test supplementaryContent</button>,
            },
          ]}
        />,
      );
      expect(screen.queryByText('test supplementaryContent')).toBeInTheDocument();
      expect(container).toMatchSnapshot();
    });

    test('should not render with supplementary content if file is in loading state', () => {
      render(
        <WithFileListWrapper
          fileList={[
            {
              ...testFileList[0],
              supplementaryContent: <button>test supplementaryContent</button>,
            },
          ]}
        />,
      );
      expect(screen.queryByText('test supplementaryContent')).not.toBeInTheDocument();
    });
  });

  describe('as drag', () => {
    test('should render as disabled', () => {
      const { container } = render(<DragWrapper isDisabled />);
      expect(container).toMatchSnapshot();
    });

    test('should call the passed onFilesChange when drop files', async () => {
      const onFilesChange = jest.fn();
      render(<DragWrapper onFilesChange={onFilesChange} qaHook="test" />);

      await userEvent.upload(screen.getByTestId('test--input'), testFileList);
      expect(onFilesChange).toHaveBeenCalledTimes(1);
    });

    test('should call the passed onFilesChange when dropping a file', async () => {
      const onFilesChange = jest.fn();
      const mockDataTransfer = {
        items: {
          0: { kind: 'file', type: 'image/png' },
        },
        files: [defaultFileList[0]],
      };

      render(<DragWrapper onFilesChange={onFilesChange} qaHook="test" />);
      fireEvent.drop(screen.getByTestId('test--input'), { dataTransfer: mockDataTransfer });

      expect(onFilesChange).toHaveBeenCalledTimes(1);
    });

    test('should not call the passed onFilesChange when dropping a non-file object', async () => {
      const onFilesChange = jest.fn();
      const mockDataTransfer = {
        items: [{ kind: 'string', type: 'text/plain' }],
        files: [],
      };

      render(<DragWrapper onFilesChange={onFilesChange} qaHook="test" />);
      fireEvent.drop(screen.getByTestId('test--input'), { dataTransfer: mockDataTransfer });

      expect(onFilesChange).toHaveBeenCalledTimes(0);
    });

    test('should pass accessibility testing', async () => {
      const { container } = render(<DragWrapper />);
      const results = await axe(container);
      expect(results).toHaveNoViolations();
    });
  });
});

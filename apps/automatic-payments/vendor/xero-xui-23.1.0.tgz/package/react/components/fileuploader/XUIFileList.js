"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _clsx = _interopRequireDefault(require("clsx"));
var PropTypes = _interopRequireWildcard(require("prop-types"));
var React = _interopRequireWildcard(require("react"));
var _helpers = require("./helpers");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function XUIFileList({
  children,
  className,
  qaHook
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
    className: (0, _clsx.default)(className, `${_helpers.baseClass}--filelist`),
    "data-automationid": qaHook,
    children: children
  });
}
var _default = exports.default = XUIFileList;
XUIFileList.propTypes = {
  /**
   * XUIFileListItems to be rendered
   */
  children: PropTypes.node.isRequired,
  /**
   * Class names to be added to the `<ul>`
   */
  className: PropTypes.string,
  /**
   * `data-automationid` on the `<ul>` for testing
   */
  qaHook: PropTypes.string
};
//# sourceMappingURL=XUIFileList.js.map
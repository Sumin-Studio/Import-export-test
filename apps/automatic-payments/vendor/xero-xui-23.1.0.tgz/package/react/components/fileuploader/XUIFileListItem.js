"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _trash = _interopRequireDefault(require("@xero/xui-icon/icons/trash"));
var _clsx = _interopRequireDefault(require("clsx"));
var PropTypes = _interopRequireWildcard(require("prop-types"));
var React = _interopRequireWildcard(require("react"));
var _checkRequiredProps = _interopRequireDefault(require("../../helpers/checkRequiredProps"));
var _progressindicator = require("../../progressindicator");
var _XUIButton = _interopRequireDefault(require("../button/XUIButton"));
var _XUIIconButton = _interopRequireDefault(require("../button/XUIIconButton"));
var _XUIIcon = _interopRequireDefault(require("../icon/XUIIcon"));
var _helpers = require("./helpers");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const fileItemBaseClass = `${_helpers.baseClass}--fileitem`;
const iconClassName = `${fileItemBaseClass}--icon`;
function XUIFileListItem({
  cancelButtonText,
  defaultErrorMessage,
  deleteLabel,
  errorIconAriaLabel,
  file,
  fileSizeUnits,
  onCancel,
  onDelete,
  onRetry,
  qaHook,
  retryButtonText,
  isMultiline = true,
  showIcon = true,
  uploadingIconAriaLabel,
  uploadingMessage
}) {
  const {
    uid,
    status,
    originalFile,
    errorMessage,
    rightContent,
    supplementaryContent,
    uploadProgressPercentage,
    hideRetryButton
  } = file;
  const roundedUploadProgressPercentage = (0, _helpers.parseUploadProgressPercentage)(uploadProgressPercentage);
  const hasUploadProgressPercentage = roundedUploadProgressPercentage !== undefined;
  const progressProps = {
    progress: hasUploadProgressPercentage ? roundedUploadProgressPercentage : 1,
    total: hasUploadProgressPercentage ? 100 : 4
  };
  const {
    name,
    size,
    type
  } = originalFile;
  const fileIcon = (0, _helpers.getFileTypeIcon)(name, type);
  const errorId = `fileuploader-error-message-${uid}`;
  const supplementaryContentPaddingClass = showIcon && `${fileItemBaseClass}--supplementarycontent-withIcon` || '';
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
    className: (0, _clsx.default)(fileItemBaseClass),
    "data-automationid": qaHook,
    children: [
    // Once the prop for loading spin of XUIProgressCircular is added,
    // the error and uploading status could be merged
    status === 'error' && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: iconClassName,
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_progressindicator.XUIProgressCircular, {
        ariaDescribedBy: errorId,
        ariaLabel: errorIconAriaLabel,
        id: `fileuploader-icon-error-${uid}`,
        isHardError: true,
        ...progressProps
      })
    }) || status === 'uploading' && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: (0, _clsx.default)(`${fileItemBaseClass}--loading`, !hasUploadProgressPercentage && `${fileItemBaseClass}--loading-indeterminate`),
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_progressindicator.XUIProgressCircular, {
        ariaLabel: uploadingIconAriaLabel,
        id: `fileuploader-icon-spin-${uid}`,
        ...progressProps
      })
    }) || showIcon && /*#__PURE__*/(0, _jsxRuntime.jsx)(_XUIIcon.default, {
      className: iconClassName,
      color: fileIcon.color,
      icon: fileIcon.icon,
      isBoxed: true
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: `${fileItemBaseClass}--maincontent`,
      children: [name, status === 'error' ? /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: `${fileItemBaseClass}--error`,
        id: errorId,
        children: errorMessage || defaultErrorMessage
      }) : isMultiline && fileSizeUnits && /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: `${fileItemBaseClass}--description`,
        children: [status === 'uploading' && uploadingMessage, status === 'done' && (0, _helpers.formatBytes)(size, fileSizeUnits)]
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: `${fileItemBaseClass}--rightcontent`,
      children: [status === 'done' && rightContent, status === 'error' && !hideRetryButton && /*#__PURE__*/(0, _jsxRuntime.jsx)(_XUIButton.default, {
        onClick: onRetry,
        size: "small",
        variant: "borderless-main",
        children: retryButtonText
      }), status === 'uploading' ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_XUIButton.default, {
        onClick: onCancel,
        size: "small",
        variant: "borderless-main",
        children: cancelButtonText
      }) : /*#__PURE__*/(0, _jsxRuntime.jsx)(_XUIIconButton.default, {
        ariaLabel: deleteLabel,
        icon: _trash.default,
        onClick: onDelete
      })]
    }), supplementaryContent && status === 'done' && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: `${fileItemBaseClass}--supplementarycontent ${supplementaryContentPaddingClass}`,
      children: supplementaryContent
    })]
  });
}
var _default = exports.default = XUIFileListItem;
XUIFileListItem.propTypes = {
  /**
   * Cancel button text
   * <br />
   * Recommended English value: *Cancel*
   */
  cancelButtonText: PropTypes.string.isRequired,
  /**
   * Default error message
   * <br />
   * Recommended English value: *Failed to upload file*
   */
  defaultErrorMessage: PropTypes.string.isRequired,
  /**
   * Label for “delete” icon for accessibility
   * <br />
   * Recommended English value: *Delete File*
   */
  deleteLabel: PropTypes.string.isRequired,
  /**
   * Aria label for the error progress icon
   */
  errorIconAriaLabel: PropTypes.string.isRequired,
  /**
   * The file object
   */
  file: PropTypes.object.isRequired,
  /**
   * The file size units array. Required if the `isMultiline` prop is set to `true`
   * <br />
   * Recommended English value: *['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']*
   */
  fileSizeUnits(...parameters) {
    return (0, _checkRequiredProps.default)('isMultiline', PropTypes.array.isRequired, ...parameters);
  },
  /**
   * Show multi line in the file list item
   */
  isMultiline: PropTypes.bool,
  /**
   * `onClick` event for cancel button
   */
  onCancel: PropTypes.func.isRequired,
  /**
   * `onClick` event for delete button
   */
  onDelete: PropTypes.func.isRequired,
  /**
   * `onClick` event for retry button
   */
  onRetry: PropTypes.func.isRequired,
  /**
   * `data-automationid` for testing
   */
  qaHook: PropTypes.string,
  /**
   * Retry button text
   * <br />
   * Recommended English value: *Retry*
   */
  retryButtonText: PropTypes.string.isRequired,
  /**
   * Show icon in the file list item
   */
  showIcon: PropTypes.bool,
  /**
   * Aria label for the uploading progress icon
   */
  uploadingIconAriaLabel: PropTypes.string.isRequired,
  /**
   * Message to display while the file is uploading. Required if the `isMultiline` prop is set to `true`
   * <br />
   * Recommended English value: *Uploading...*
   */
  uploadingMessage(...parameters) {
    return (0, _checkRequiredProps.default)('isMultiline', PropTypes.string.isRequired, ...parameters);
  }
};
//# sourceMappingURL=XUIFileListItem.js.map
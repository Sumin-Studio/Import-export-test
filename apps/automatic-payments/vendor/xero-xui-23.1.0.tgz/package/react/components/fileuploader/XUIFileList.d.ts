import * as PropTypes from 'prop-types';
import * as React from 'react';
export type XUIFileListProps = {
    /**
     * XUIFileListItems to be rendered
     */
    children: React.ReactNode;
    /**
     * Class names to be added to the `<ul>`
     */
    className?: string;
    /**
     * `data-automationid` on the `<ul>` for testing
     */
    qaHook?: string;
};
declare function XUIFileList({ children, className, qaHook }: XUIFileListProps): React.JSX.Element;
declare namespace XUIFileList {
    var propTypes: {
        /**
         * XUIFileListItems to be rendered
         */
        children: PropTypes.Validator<NonNullable<PropTypes.ReactNodeLike>>;
        /**
         * Class names to be added to the `<ul>`
         */
        className: PropTypes.Requireable<string>;
        /**
         * `data-automationid` on the `<ul>` for testing
         */
        qaHook: PropTypes.Requireable<string>;
    };
}
export default XUIFileList;

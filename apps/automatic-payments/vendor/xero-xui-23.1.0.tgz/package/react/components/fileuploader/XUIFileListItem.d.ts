import * as PropTypes from 'prop-types';
import * as React from 'react';
import { Prettify } from '../../helpers/helperTypes';
import { FileObject } from './XUIFileUploader';
declare function XUIFileListItem({ cancelButtonText, defaultErrorMessage, deleteLabel, errorIconAriaLabel, file, fileSizeUnits, onCancel, onDelete, onRetry, qaHook, retryButtonText, isMultiline, showIcon, uploadingIconAriaLabel, uploadingMessage, }: XUIFileListItemProps): React.JSX.Element;
declare namespace XUIFileListItem {
    var propTypes: {
        /**
         * Cancel button text
         * <br />
         * Recommended English value: *Cancel*
         */
        cancelButtonText: PropTypes.Validator<string>;
        /**
         * Default error message
         * <br />
         * Recommended English value: *Failed to upload file*
         */
        defaultErrorMessage: PropTypes.Validator<string>;
        /**
         * Label for “delete” icon for accessibility
         * <br />
         * Recommended English value: *Delete File*
         */
        deleteLabel: PropTypes.Validator<string>;
        /**
         * Aria label for the error progress icon
         */
        errorIconAriaLabel: PropTypes.Validator<string>;
        /**
         * The file object
         */
        file: PropTypes.Validator<object>;
        /**
         * The file size units array. Required if the `isMultiline` prop is set to `true`
         * <br />
         * Recommended English value: *['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']*
         */
        fileSizeUnits(parameters_0: Record<string, unknown>, parameters_1: string, parameters_2: string, parameters_3: string, parameters_4: string): Error | null;
        /**
         * Show multi line in the file list item
         */
        isMultiline: PropTypes.Requireable<boolean>;
        /**
         * `onClick` event for cancel button
         */
        onCancel: PropTypes.Validator<(...args: any[]) => any>;
        /**
         * `onClick` event for delete button
         */
        onDelete: PropTypes.Validator<(...args: any[]) => any>;
        /**
         * `onClick` event for retry button
         */
        onRetry: PropTypes.Validator<(...args: any[]) => any>;
        /**
         * `data-automationid` for testing
         */
        qaHook: PropTypes.Requireable<string>;
        /**
         * Retry button text
         * <br />
         * Recommended English value: *Retry*
         */
        retryButtonText: PropTypes.Validator<string>;
        /**
         * Show icon in the file list item
         */
        showIcon: PropTypes.Requireable<boolean>;
        /**
         * Aria label for the uploading progress icon
         */
        uploadingIconAriaLabel: PropTypes.Validator<string>;
        /**
         * Message to display while the file is uploading. Required if the `isMultiline` prop is set to `true`
         * <br />
         * Recommended English value: *Uploading...*
         */
        uploadingMessage(parameters_0: Record<string, unknown>, parameters_1: string, parameters_2: string, parameters_3: string, parameters_4: string): Error | null;
    };
}
export default XUIFileListItem;
export interface BaseProps {
    /**
     * Cancel button text
     * <br />
     * Recommended English value: *Cancel*
     */
    cancelButtonText: string;
    /**
     * Default error message
     * <br />
     * Recommended English value: *Failed to upload file*
     */
    defaultErrorMessage: string;
    /**
     * Label for “delete” icon for accessibility
     * <br />
     * Recommended English value: *Delete File*
     */
    deleteLabel: string;
    /**
     * Aria label for the error progress icon
     */
    errorIconAriaLabel: string;
    /**
     * The file size units array. Required if the `isMultiline` prop is set to `true`
     * <br />
     * Recommended English value: *['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']*
     */
    fileSizeUnits?: string[];
    /**
     * `data-automationid` for testing
     */
    qaHook?: string;
    /**
     * Retry button text
     * <br />
     * Recommended English value: *Retry*
     */
    retryButtonText: string;
    /**
     * Show icon in the file list item
     */
    showIcon?: boolean;
    /**
     * Aria label for the uploading progress icon
     */
    uploadingIconAriaLabel: string;
    /**
     * Message to display while the file is uploading. Required if the `isMultiline` prop is set to `true`
     * <br />
     * Recommended English value: *Uploading...*
     */
    uploadingMessage?: string;
}
export type XUIFileListItemProps = Prettify<BaseProps & {
    /**
     * The file object
     */
    file: FileObject;
    /**
     * Show multi line in the file list item
     */
    isMultiline?: boolean;
    /**
     * Called when the cancel button is clicked
     */
    onCancel: React.MouseEventHandler<HTMLElement>;
    /**
     * Called when the delete button is clicked
     */
    onDelete: React.MouseEventHandler<HTMLElement>;
    /**
     * Called when retry button is clicked
     */
    onRetry: React.MouseEventHandler<HTMLElement>;
}>;

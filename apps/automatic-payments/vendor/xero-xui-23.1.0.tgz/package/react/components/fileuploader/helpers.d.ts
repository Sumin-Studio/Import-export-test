import NOOP from '../helpers/noop';
import { FileObject } from './XUIFileUploader';
export declare const baseClass: string;
export declare const formatBytes: (bytes: number, fileSizeUnits: string[]) => string;
export declare const getFileTypeIcon: (name: string, mimeType: string) => any;
export declare function getFileById(fileList: FileObject[], id: string): FileObject | undefined;
export declare function getAnnouncementMessage({ fileList, unannouncedFileIds, getUploadFileErrorMessage, getUploadFileSuccessMessage, getUploadMultipleFilesErrorMessage, uploadMultipleFilesSuccessMessage, }: {
    fileList: FileObject[];
    unannouncedFileIds: string[];
    getUploadFileErrorMessage?: (fileName: string) => string;
    getUploadFileSuccessMessage?: (fileName: string) => string;
    getUploadMultipleFilesErrorMessage?: (failedCount: number) => string;
    uploadMultipleFilesSuccessMessage?: string;
}): string | undefined;
export declare const defaultFileList: ({
    uid: string;
    status: string;
    originalFile: {
        name: string;
        type: string;
        size: number;
    };
    uploadProgressPercentage?: undefined;
} | {
    uid: string;
    status: string;
    originalFile: {
        name: string;
        type: string;
        size: number;
    };
    uploadProgressPercentage: number;
})[];
export declare const acceptedFileList: {
    uid: string;
    status: string;
    originalFile: {
        name: string;
        type: string;
        size: number;
    };
}[];
export declare const defaultProps: {
    buttonText: string;
    cancelButtonText: string;
    defaultErrorMessage: string;
    getDeleteLabel: () => string;
    dropZoneMessage: string;
    errorIconAriaLabel: string;
    fileList: never[];
    fileSizeUnits: string[];
    label: string;
    retryButtonText: string;
    secondaryButtonOnClick: typeof NOOP;
    uploadingIconAriaLabel: string;
    uploadingMessage: string;
    uploadingMultipleFilesMessage: string;
    uploadMultipleFilesSuccessMessage: string;
    onDelete: typeof NOOP;
    onFilesChange: typeof NOOP;
    onRetry: typeof NOOP;
};
export declare const fakeUpload: () => Promise<void>;
export declare const parseUploadProgressPercentage: (value?: number) => number | undefined;

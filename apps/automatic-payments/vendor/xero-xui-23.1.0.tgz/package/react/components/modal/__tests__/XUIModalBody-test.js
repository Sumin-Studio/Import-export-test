import React from 'react';
import { render } from '@testing-library/react';
import { axe, toHaveNoViolations } from 'jest-axe';
import XUIModalBody from '../XUIModalBody';

expect.extend(toHaveNoViolations);

describe('XUIModalBody', () => {
  test('renders expected markup', () => {
    const { container } = render(
      <XUIModalBody qaHook="test-modal--body">
        <div />
      </XUIModalBody>,
    );

    expect(container).toMatchSnapshot();
  });

  test('should pass accessibility testing', async () => {
    const { container } = render(
      <XUIModalBody>
        <h1>Meow</h1>
      </XUIModalBody>,
    );
    const results = await axe(container);
    expect(results).toHaveNoViolations();
  });
});

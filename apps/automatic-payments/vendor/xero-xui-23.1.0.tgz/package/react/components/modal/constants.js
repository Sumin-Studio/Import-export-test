"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.modalSizes = exports.baseClass = void 0;
var _xuiClassNamespace = require("../helpers/xuiClassNamespace");
const baseClass = exports.baseClass = `${_xuiClassNamespace.ns}-modal`;
const modalSizes = exports.modalSizes = {
  small: `${baseClass}-width-small`,
  medium: `${baseClass}-width-medium`,
  large: `${baseClass}-width-large`,
  xlarge: `${baseClass}-width-xlarge`,
  fullscreen: `${baseClass}-fullscreen`
};
//# sourceMappingURL=constants.js.map
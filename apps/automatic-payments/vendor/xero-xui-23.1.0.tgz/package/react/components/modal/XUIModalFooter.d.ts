import * as React from 'react';

export interface XUIModalFooterProps {
  children?: React.ReactNode;
  className?: string;
  qaHook?: string;
}

declare const XUIModalFooter: React.FunctionComponent<XUIModalFooterProps>;
export default XUIModalFooter;

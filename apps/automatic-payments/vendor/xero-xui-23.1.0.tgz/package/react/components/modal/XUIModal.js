"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _cross = _interopRequireDefault(require("@xero/xui-icon/icons/cross"));
var _clsx = _interopRequireDefault(require("clsx"));
var _nanoid = require("nanoid");
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react = _interopRequireWildcard(require("react"));
var _reactPortal = require("react-portal");
var _verge = _interopRequireDefault(require("verge"));
var _XUIIconButton = _interopRequireDefault(require("../button/XUIIconButton"));
var _conditionallyRequiredValidator = _interopRequireDefault(require("../helpers/conditionallyRequiredValidator"));
var _getFocusableDescendants = _interopRequireDefault(require("../helpers/getFocusableDescendants"));
var _modalManager = require("../helpers/modalManager");
var _portalContainer = _interopRequireWildcard(require("../helpers/portalContainer"));
var _xuiClassNamespace = require("../helpers/xuiClassNamespace");
var _constants = require("../popover/private/constants");
var _constants2 = require("./constants");
var _XUIModalHeader = _interopRequireDefault(require("./XUIModalHeader"));
var _XUIModalHeading = _interopRequireDefault(require("./XUIModalHeading"));
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
const maskClass = `${_xuiClassNamespace.ns}-mask`;

/**
 * Predicate to determine if the props of a modal have changed in such as way as to necessitate
 * adding/removing global event listeners.
 *
 * @private
 * @param {Object} props
 * @param {Object} otherProps
 * @returns {Boolean}
 */
function shouldUpdateListeners(props, otherProps) {
  return !!props.onClose !== !!otherProps.onClose || props.hideOnEsc !== otherProps.hideOnEsc || props.restrictFocus !== otherProps.restrictFocus || props.keyListenerTarget !== otherProps.keyListenerTarget;
}
class XUIModal extends _react.Component {
  constructor(...args) {
    super(...args);
    _defineProperty(this, "state", {
      positionSettings: null,
      isTopModal: null // This is handled and manipulated by helpers/modalManager
    });
    _defineProperty(this, "generatedHeaderId", `xui-${(0, _nanoid.nanoid)(10)}`);
    _defineProperty(this, "_maskNode", /*#__PURE__*/_react.default.createRef());
    _defineProperty(this, "_modalNode", /*#__PURE__*/_react.default.createRef());
    /**
     * Add the global event listeners necessary to ensure that props like hideOnEsc
     * can function properly.
     */
    _defineProperty(this, "addListeners", () => {
      const {
        onClose,
        keyListenerTarget,
        restrictFocus,
        hideOnEsc
      } = this.props;
      const listenerTarget = keyListenerTarget == null ? window : keyListenerTarget;

      // Be paranoid.  Some test environments won't have a window object.
      if (listenerTarget != null) {
        if (onClose && hideOnEsc) {
          this._keydownHandler = this._keydownHandler.bind(this);
          listenerTarget.addEventListener('keydown', this._keydownHandler);
        }
        if (restrictFocus) {
          this._restrictFocus = this._restrictFocus.bind(this);
          listenerTarget.addEventListener('focus', this._restrictFocus, true);
        }
      }
    });
    /**
     * Remove any global event listeners associated with a given modal.
     */
    _defineProperty(this, "removeListeners", keyListenerTarget => {
      const listenerTarget = keyListenerTarget == null ? window : keyListenerTarget;

      // Be paranoid.  Some test environments won't have a window object.
      if (listenerTarget != null) {
        listenerTarget.removeEventListener('keydown', this._keydownHandler);
        listenerTarget.removeEventListener('focus', this._restrictFocus, true);
      }
    });
    /**
     * Calculate and set the distance of the modal relative to the top.
     *
     * @public
     */
    _defineProperty(this, "calcOffsetTop", () => {
      var _this$_modalNode$curr;
      const viewportH = _verge.default.viewportH();
      const modalHeight = (_this$_modalNode$curr = this._modalNode.current) === null || _this$_modalNode$curr === void 0 ? void 0 : _this$_modalNode$curr.getBoundingClientRect().height;
      /* subtracts 15px ($xui-s-standard) from `top` to take into account XUIMask's
       * (wrapping component) existing padding */
      const calculatedOffsetTop = Math.max((viewportH - modalHeight) / 2 - 15, 0);
      const positionSettings = {
        top: `${calculatedOffsetTop}px`
      };
      this.setState({
        positionSettings
      });
    });
    /**
     * @param {Object} event - A keydown event which is set to be listened to by componentDidMount.
     * If the modal needs to close when the user presses the esc key, we need to attach a key
     * listener to a parent (`window` by default) to catch this key press
     */
    _defineProperty(this, "_keydownHandler", event => {
      const {
        isOpen,
        onClose
      } = this.props;
      const {
        isTopModal
      } = this.state;
      if ((event.key === 'Escape' || event.key === 'Esc') && isOpen && onClose && isTopModal) {
        event.stopImmediatePropagation(); // Necessary for nested inline modals event bubbling.
        onClose();
      }
    });
    /**
     * @param {Object} event - A focus change event which is set to be listened to by componentDidMount
     * Limits the focusable elements to those within the modal
     * */
    _defineProperty(this, "_restrictFocus", event => {
      const {
        isOpen,
        restrictFocus
      } = this.props;
      if (!this._modalNode.current || !isOpen || !restrictFocus) {
        return;
      }
      if (event.target === window || event.target === document) {
        return;
      }

      // Need to check if the focus is within this modal mask, or in another portalled element (e.g. dropdowns)
      const maskAndPortalNodes = [...document.querySelectorAll(`.${_portalContainer.portalClass}, .${maskClass}, .${_constants.xuiPopoverPortalClass}`)];
      if (!maskAndPortalNodes.some(node => node.contains(event.target))) {
        var _this$_modalNode$curr2;
        event.stopPropagation();
        (_this$_modalNode$curr2 = this._modalNode.current) === null || _this$_modalNode$curr2 === void 0 || _this$_modalNode$curr2.focus();
      }
    });
    /**
     * @param {Object} event - A keyDown event
     * Overrides the `Tab` key's default behaviour to restrict focus within the modal
     */
    _defineProperty(this, "_manageTabFocus", event => {
      const {
        restrictFocus
      } = this.props;
      if (event.key !== 'Tab' || restrictFocus === false) {
        return;
      }
      const modalNode = this._modalNode.current;
      const focusableDescendants = (0, _getFocusableDescendants.default)(modalNode);
      const firstFocusableDescendant = focusableDescendants[0];
      const lastFocusableDescendant = [...focusableDescendants].slice(-1)[0];
      if (!event.shiftKey) {
        // Tabbing forwards
        if (event.target === modalNode || event.target === lastFocusableDescendant) {
          event.preventDefault();
          firstFocusableDescendant.focus();
        }
      }
      // Tabbing backwards
      else if (event.target === modalNode || event.target === firstFocusableDescendant) {
        event.preventDefault();
        lastFocusableDescendant.focus();
      }
    });
  }
  componentDidMount() {
    const {
      isOpen
    } = this.props;
    const {
      isTopModal
    } = this.state;
    this.addListeners();
    if (isOpen && !isTopModal) {
      var _this$_maskNode$curre;
      const {
        activeElement
      } = document;
      this.priorFocusedEl = activeElement;
      (0, _modalManager.registerModal)(this);
      this._isScrollLocked = true;
      this.calcOffsetTop();
      if (!((_this$_maskNode$curre = this._maskNode.current) !== null && _this$_maskNode$curre !== void 0 && _this$_maskNode$curre.contains(activeElement))) {
        var _this$_modalNode$curr3;
        (_this$_modalNode$curr3 = this._modalNode.current) === null || _this$_modalNode$curr3 === void 0 || _this$_modalNode$curr3.focus();
      }
    }
  }
  componentWillUnmount() {
    this.removeListeners(this.props.keyListenerTarget);
    const {
      isTopModal
    } = this.state;
    if (this.props.isOpen && this._isScrollLocked && isTopModal) {
      this._isScrollLocked = false;
      (0, _modalManager.deRegisterTopModal)();
    }
  }
  componentDidUpdate(prevProps) {
    var _this$_maskNode$curre2;
    const {
      isOpen,
      restrictFocus
    } = this.props;
    const {
      isTopModal
    } = this.state;
    const {
      activeElement
    } = document;
    if (shouldUpdateListeners(this.props, prevProps)) {
      this.removeListeners(prevProps.keyListenerTarget);
      this.addListeners();
    }
    if (isOpen && !this._isScrollLocked && !isTopModal) {
      this.priorFocusedEl = activeElement;
      (0, _modalManager.registerModal)(this);
      this._isScrollLocked = true;
      this.calcOffsetTop();
    }
    if (!isOpen && this._isScrollLocked && isTopModal) {
      this._isScrollLocked = false;
      (0, _modalManager.deRegisterTopModal)();
    }
    if (isOpen && restrictFocus && (!prevProps.isOpen || !prevProps.restrictFocus) && !((_this$_maskNode$curre2 = this._maskNode.current) !== null && _this$_maskNode$curre2 !== void 0 && _this$_maskNode$curre2.contains(activeElement))) {
      var _this$_modalNode$curr4;
      (_this$_modalNode$curr4 = this._modalNode.current) === null || _this$_modalNode$curr4 === void 0 || _this$_modalNode$curr4.focus();
    }
  }
  render() {
    const {
      hideOnOverlayClick,
      onClose,
      size,
      isOpen,
      className,
      maskClassName,
      closeClassName,
      children,
      hasDefaultLayout,
      ariaLabelledBy,
      ariaDescribedBy,
      qaHook,
      id,
      isForm,
      isUsingPortal,
      closeButtonLabel,
      restrictFocus
    } = this.props;
    const {
      positionSettings,
      isTopModal
    } = this.state;
    const maskClasses = (0, _clsx.default)(maskClass, maskClassName, isOpen && `${maskClass}-is-active`,
    // unmasks previous modal's mask if there is more than 1 modal open
    !isTopModal && `${_xuiClassNamespace.ns}-unmask`);
    const modalClasses = (0, _clsx.default)(_constants2.baseClass, _constants2.modalSizes[size], hasDefaultLayout && `${_constants2.baseClass}-layout`, className);
    const overlayClickHandler = hideOnOverlayClick && onClose ? event => {
      if (event.target.classList.contains(maskClass) && isOpen) {
        onClose();
      }
    } : null;
    const closeButton = onClose ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_XUIIconButton.default, {
      ariaLabel: closeButtonLabel,
      className: (0, _clsx.default)(`${_constants2.baseClass}--close`, closeClassName),
      icon: _cross.default,
      onClick: onClose,
      qaHook: qaHook && `${qaHook}--close`,
      type: "button"
    }, "close-button") : null;
    let headerElement;
    let ariaLabelledById = ariaLabelledBy;
    let headerLabelId;
    const finalChildren = _react.Children.map(children, child => {
      if (child && child.type === _XUIModalHeader.default) {
        const {
          id: headerId
        } = child.props;
        let headerIdProvidedByChild = false;
        headerLabelId = headerId || this.generatedHeaderId;
        const headerChildren = _react.Children.map(child.props.children, headerChild => {
          if (headerChild && headerChild.type === _XUIModalHeading.default) {
            const {
              id: headingId
            } = headerChild.props;
            headerLabelId = headingId || headerLabelId;
            headerIdProvidedByChild = true;

            // if we generated an id for the heading, apply the id
            if (!headingId) {
              const newProps = {
                ...headerChild.props,
                id: headerLabelId
              };
              return /*#__PURE__*/(0, _react.cloneElement)(headerChild, newProps, headerChild.props.children);
            }
          }
          return headerChild;
        });

        // Use the provided header/heading ID or apply a generated one.
        // This will be used for the label of the modal, if another is not provided.
        if (!ariaLabelledById) {
          ariaLabelledById = headerLabelId;
        }
        headerElement = /*#__PURE__*/(0, _react.cloneElement)(child, {
          ...child.props,
          id: !headerIdProvidedByChild ? headerLabelId : headerId
        }, [headerChildren, closeButton]);
        return null;
      }
      return child;
    });
    // Our CSS requires that the modal close button sits inside a header element
    if (headerElement == null && closeButton != null) {
      headerElement = /*#__PURE__*/(0, _jsxRuntime.jsx)(_XUIModalHeader.default, {
        qaHook: qaHook && `${qaHook}--header`,
        children: closeButton
      });
    }
    const MainElement = isForm ? 'form' : 'section';
    let modalTabIndex = -1;
    if (isOpen && isTopModal) {
      // Setting the tabIndex to a positive integer allows the focus to return to the browser when shift+tabbing out of the modal. We use a tab index of 1 to ensure that the modal is the first thing on the page.
      const useTabIndexHack = restrictFocus && isUsingPortal;
      modalTabIndex = useTabIndexHack ? 1 : 0;
    }
    const childNodes = /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      "aria-hidden": !isOpen || !isTopModal,
      className: maskClasses,
      "data-automationid": qaHook && `${qaHook}--mask`,
      id: id,
      onClick: overlayClickHandler,
      ref: this._maskNode,
      role: "presentation",
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(MainElement, {
        "aria-describedby": ariaDescribedBy
        // If a modal header has been provided, it can be used for the label.
        ,
        "aria-labelledby": ariaLabelledById || undefined,
        className: modalClasses,
        "data-automationid": qaHook,
        onKeyDown: this._manageTabFocus,
        ref: this._modalNode,
        role: isOpen ? 'dialog' : null,
        style: positionSettings,
        tabIndex: modalTabIndex,
        children: [headerElement, finalChildren]
      })
    });
    if (!isUsingPortal) {
      return childNodes;
    }
    return isOpen ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_reactPortal.Portal, {
      node: (0, _portalContainer.default)(),
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: `${_xuiClassNamespace.ns}-container`,
        "data-automationid": qaHook && `${qaHook}--container`,
        children: childNodes
      })
    }) : null;
  }
}
exports.default = XUIModal;
XUIModal.propTypes = {
  /** ID for the element containing an appropriate description for screen readers */
  ariaDescribedBy: _propTypes.default.string,
  /** ID for the element containing an appropriate label for screen readers. If a ModalHeader
   * is provided, it will automatically be used as the labelling element. */
  ariaLabelledBy: _propTypes.default.string,
  children: _propTypes.default.node,
  className: _propTypes.default.string,
  /**
   * Title and accessibility label to be applied to the modal close "X" button.
   * <br />
   * Required when an `onClose` is provided.
   * <br />
   * Recommended English value: *Close*
   */
  closeButtonLabel(props, propName, componentName) {
    return (0, _conditionallyRequiredValidator.default)(props, propName, componentName, props.onClose, 'onClose', 'string');
  },
  /** Custom classes for the close button */
  closeClassName: _propTypes.default.string,
  /** If the modal will use the default XUI style layout */
  hasDefaultLayout: _propTypes.default.bool,
  /** If the modal will be hidden when the user presses the Esc key */
  hideOnEsc: _propTypes.default.bool,
  /** If the modal will be hidden when the user clicks the overlay */
  hideOnOverlayClick: _propTypes.default.bool,
  id: _propTypes.default.string,
  /** Whether the modal wrapping element should be a `<form>` rather than a `<section>`.
   * Allows the enter key to activate the submit button inside native form controls. */
  isForm: _propTypes.default.bool,
  /** Whether the modal is visible */
  isOpen: _propTypes.default.bool,
  /** Renders the modal to the bottom of the current document when true. Otherwise inline. */
  isUsingPortal: _propTypes.default.bool,
  /** The target that should listen to key presses. Defaults to the window. */
  keyListenerTarget: _propTypes.default.object,
  /** Custom classes for the mask */
  maskClassName: _propTypes.default.string,
  /** Bind a function to fire when the modal requests to be hidden */
  onClose: _propTypes.default.func,
  qaHook: _propTypes.default.string,
  /** Restricts focus to elements within the modal while it is open */
  restrictFocus: _propTypes.default.bool,
  /** The size (aka width) of this modal */
  size: _propTypes.default.oneOf(['small', 'medium', 'large', 'xlarge', 'fullscreen'])
};
XUIModal.defaultProps = {
  hasDefaultLayout: true,
  hideOnEsc: true,
  hideOnOverlayClick: false,
  isForm: false,
  isOpen: false,
  isUsingPortal: true,
  restrictFocus: true,
  size: 'medium'
};
//# sourceMappingURL=XUIModal.js.map
import * as React from 'react';

export interface XUIModalBodyProps {
  children?: React.ReactNode;
  className?: string;
  qaHook?: string;
}

declare const XUIModalBody: React.FunctionComponent<XUIModalBodyProps>;
export default XUIModalBody;

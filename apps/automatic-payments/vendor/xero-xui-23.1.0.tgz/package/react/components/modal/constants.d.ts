export declare const baseClass: string;
export declare const modalSizes: {
    small: string;
    medium: string;
    large: string;
    xlarge: string;
    fullscreen: string;
};

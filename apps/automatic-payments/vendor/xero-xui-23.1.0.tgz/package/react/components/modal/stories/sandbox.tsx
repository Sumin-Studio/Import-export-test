import React from 'react';

import {
  XUIActionMenu,
  XUIActionMenuIconButtonTrigger,
  XUIActionMenuItems,
  XUIActionMenuItem,
} from '../../../actionmenu';
import { XUIButton, XUIIconButton } from '../../../button';
import { XUIDropdown, XUIDropdownToggled } from '../../../dropdown';
import { XUIPicklist, XUIPickitem } from '../../../picklist';
import {
  XUISingleSelect,
  XUISingleSelectOption,
  XUISingleSelectOptions,
  XUISingleSelectTrigger,
} from '../../../singleselect';
import XUIPopover from '../../popover/XUIPopover';
import XUIPopoverBody from '../../popover/XUIPopoverBody';
import XUIModal from '../XUIModal';
import XUIModalBody from '../XUIModalBody';

import { overflowIcon } from '@xero/xui-icon';

const Example = () => {
  const triggerRef = React.createRef<XUIButton>();
  const secondTriggerRef = React.createRef<XUIButton>();
  const thirdTriggerRef = React.createRef<XUIButton>();
  const [isPopoverOpen, setIsPopoverOpen] = React.useState(false);
  const [secondPopoverOpen, setSecondPopoverOpen] = React.useState(false);
  const [isModalOpen, setIsModalOpen] = React.useState(false);
  const [isModalWithActionMenuOpen, setIsModalWithActionMenuOpen] = React.useState(false);
  const [isDropdownHidden, setIsDropdownHidden] = React.useState(false);

  const closePopover = () => setIsPopoverOpen(false);
  const closeSecondPopover = () => setSecondPopoverOpen(false);
  const togglePopover = () => setIsPopoverOpen(!isPopoverOpen);
  const toggleSecondPopover = () => setSecondPopoverOpen(!secondPopoverOpen);
  const toggleModal = () => setIsModalOpen(!isModalOpen);
  const toggleModalWithActionMenu = () => setIsModalWithActionMenuOpen(!isModalWithActionMenuOpen);
  const toggleDropdown = () => setIsDropdownHidden(!isDropdownHidden);
  const hideModal = () => setIsModalOpen(false);
  const hideModalWithActionMenu = () => setIsModalWithActionMenuOpen(false);

  const dropdown = (
    <XUIDropdown isHidden={isDropdownHidden}>
      <XUIPicklist closeOnSelect={true}>
        <XUIPickitem id="1" key="1">
          Tim Redmond
        </XUIPickitem>
        <XUIPickitem id="2" key="2">
          James Magness
        </XUIPickitem>
        <XUIPickitem id="3" key="3">
          Finn Clark
        </XUIPickitem>
      </XUIPicklist>
    </XUIDropdown>
  );

  return (
    <div>
      <XUIButton className="xui-margin-horizontal-small" onClick={toggleModal}>
        Modal with a popover
      </XUIButton>
      <XUIButton
        className="xui-margin-horizontal-small"
        onClick={toggleSecondPopover}
        ref={secondTriggerRef}
      >
        Other popover
      </XUIButton>
      <XUIButton
        className="xui-margin-horizontal-small"
        onClick={toggleModalWithActionMenu}
        ref={thirdTriggerRef}
      >
        Modal with an action menu
      </XUIButton>
      {secondPopoverOpen && (
        <XUIPopover
          id="second-popover"
          onClickOutside={closeSecondPopover}
          triggerRef={secondTriggerRef}
        >
          <XUIPopoverBody>
            This popover can be opened and closed by clicking the trigger, and can be closed by
            clicking outside the popover.
            <a className="xui-text-link" href="#popover">
              Popovers with interactive content
            </a>{' '}
            are also accessible via the keyboard.
          </XUIPopoverBody>
        </XUIPopover>
      )}
      <XUIModal closeButtonLabel="Close" isOpen={isModalOpen} onClose={hideModal}>
        <XUIModalBody>
          <XUIButton
            aria-haspopup
            aria-owns={isPopoverOpen && 'informational-popover'}
            onClick={togglePopover}
            ref={triggerRef}
          >
            Toggle a popover
          </XUIButton>
          {isPopoverOpen && (
            <XUIPopover
              id="informational-popover"
              onClickOutside={closePopover}
              triggerRef={triggerRef}
            >
              <XUIPopoverBody>
                This popover can be opened and closed by clicking the trigger, and can be closed by
                clicking outside the popover.
                <a className="xui-text-link" href="#popover">
                  Popovers with interactive content
                </a>{' '}
                are also accessible via the keyboard.
              </XUIPopoverBody>
            </XUIPopover>
          )}
          <XUIButton>Button 1</XUIButton>
          <XUIButton>Button 2</XUIButton>
        </XUIModalBody>
      </XUIModal>
      <XUIModal
        closeButtonLabel="close"
        isOpen={isModalWithActionMenuOpen}
        onClose={hideModalWithActionMenu}
      >
        <XUIModalBody>
          <div className="xui-u-flex xui-u-flex-justify-space-between">
            <span>Action menu</span>
            <XUIActionMenu>
              <XUIActionMenuIconButtonTrigger ariaLabel="More options" icon={overflowIcon} />
              <XUIActionMenuItems>
                <XUIActionMenuItem onSelect={() => console.log('onSelect')}>
                  Edit transactions
                </XUIActionMenuItem>
                <XUIActionMenuItem onSelect={() => console.log('onSelect')}>
                  Approve
                </XUIActionMenuItem>
                <XUIActionMenuItem onSelect={() => console.log('onSelect')}>
                  Decline
                </XUIActionMenuItem>
                <XUIActionMenuItem onSelect={() => console.log('onSelect')}>
                  Delete
                </XUIActionMenuItem>
              </XUIActionMenuItems>
            </XUIActionMenu>
          </div>
          <div className="xui-u-flex xui-u-flex-justify-space-between">
            <span>Picklist</span>
            <XUIDropdownToggled
              dropdown={dropdown}
              trigger={<XUIIconButton ariaLabel="More options" icon={overflowIcon} />}
            />
          </div>
          <div className="xui-u-flex xui-u-flex-justify-space-between">
            <XUISingleSelect>
              <XUISingleSelectTrigger />
              <XUISingleSelectOptions>
                <XUISingleSelectOption>Select bank</XUISingleSelectOption>
                <XUISingleSelectOption>ANZ</XUISingleSelectOption>
                <XUISingleSelectOption>Westpac</XUISingleSelectOption>
              </XUISingleSelectOptions>
            </XUISingleSelect>
          </div>
        </XUIModalBody>
      </XUIModal>
    </div>
  );
};

export default Example;

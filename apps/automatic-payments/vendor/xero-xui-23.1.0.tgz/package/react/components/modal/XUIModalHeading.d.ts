import * as React from 'react';
type XUIModalHeadingProps = {
    children: React.ReactNode;
    className?: string;
    /**
     * The level of heading that should be assigned to the title.
     */
    headingLevel?: number;
    qaHook?: string;
    id?: string;
};
declare const XUIModalHeading: React.ForwardRefExoticComponent<XUIModalHeadingProps & React.RefAttributes<HTMLHeadingElement>>;
export default XUIModalHeading;

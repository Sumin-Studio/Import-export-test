## Modal Header and Footer

Although not required, the header and footer component usage is encouraged with modals. They provide the default layout classes and work well with other elements inside the modal, such as the close button. Additionally, you can optionally make use of the heading component to format text within the header component and provide an accessible [heading element](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/Heading_Elements).

import React from 'react';

import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

import XUIModal from '../XUIModal';
import XUIModalBody from '../XUIModalBody';
import XUIPopover from '../../popover/XUIPopover';
import XUIPopoverBody from '../../popover/XUIPopoverBody';
import XUIButton from '../../button/XUIButton';
import wait from '../../../helpers/wait';

describe('XUIModal - Integration testing', () => {
  describe('XUIPopover', () => {
    test('should allow tabbing to nested popovers', async () => {
      const triggerRef = React.createRef();

      render(
        <div>
          <XUIModal isOpen closeButtonLabel="close">
            <XUIModalBody>
              <XUIButton aria-haspopup aria-owns="informational-popover" ref={triggerRef}>
                Toggle a popover
              </XUIButton>

              <XUIPopover id="informational-popover" triggerRef={triggerRef}>
                <XUIPopoverBody>
                  This popover can be opened and closed by clicking the trigger, and can be closed
                  by clicking outside the popover.{' '}
                  <a className="xui-text-link" href="#popover">
                    Popovers with interactive content
                  </a>{' '}
                  are also accessible via the keyboard.
                </XUIPopoverBody>
              </XUIPopover>

              <XUIButton>Button 1</XUIButton>
              <XUIButton>Button 2</XUIButton>
            </XUIModalBody>
          </XUIModal>
        </div>,
      );

      await userEvent.click(screen.getByText('Toggle a popover'));
      await wait(100);
      await userEvent.tab();

      expect(screen.getByText('Popovers with interactive content')).toHaveFocus();
    });
  });
});

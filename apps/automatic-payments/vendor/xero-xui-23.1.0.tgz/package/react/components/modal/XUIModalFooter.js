"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _clsx = _interopRequireDefault(require("clsx"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react = _interopRequireDefault(require("react"));
var _constants = require("./constants");
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function XUIModalFooter({
  className,
  children,
  qaHook
}) {
  const classNames = (0, _clsx.default)(`${_constants.baseClass}--footer`, className);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("footer", {
    className: classNames,
    "data-automationid": qaHook,
    children: children
  });
}
var _default = exports.default = XUIModalFooter;
XUIModalFooter.propTypes = {
  children: _propTypes.default.node,
  className: _propTypes.default.string,
  qaHook: _propTypes.default.string
};
//# sourceMappingURL=XUIModalFooter.js.map
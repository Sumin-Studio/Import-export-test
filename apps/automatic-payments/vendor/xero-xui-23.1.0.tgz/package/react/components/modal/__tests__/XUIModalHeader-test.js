import React from 'react';
import { render } from '@testing-library/react';
import { axe, toHaveNoViolations } from 'jest-axe';
import XUIModalHeader from '../XUIModalHeader';

expect.extend(toHaveNoViolations);

describe('XUIModalHeader', () => {
  test('renders expected markup', () => {
    const { container } = render(
      <XUIModalHeader qaHook="test-modal--header">
        <div />
      </XUIModalHeader>,
    );

    expect(container).toMatchSnapshot();
  });

  test('should pass accessibility testing', async () => {
    const { container } = render(
      <XUIModalHeader>
        <h1>Meow</h1>
      </XUIModalHeader>,
    );
    const results = await axe(container);
    expect(results).toHaveNoViolations();
  });
});

import React from 'react';
import { render } from '@testing-library/react';
import { axe, toHaveNoViolations } from 'jest-axe';
import XUIModalFooter from '../XUIModalFooter';

expect.extend(toHaveNoViolations);

describe('XUIModalFooter', () => {
  test('renders expected markup', () => {
    const { container } = render(
      <XUIModalFooter qaHook="test-modal--footer">
        <div />
      </XUIModalFooter>,
    );

    expect(container).toMatchSnapshot();
  });

  test('should pass accessibility testing', async () => {
    const { container } = render(
      <XUIModalFooter>
        <h1>Meow</h1>
      </XUIModalFooter>,
    );
    const results = await axe(container);
    expect(results).toHaveNoViolations();
  });
});

import React from 'react';
import { nanoid } from 'nanoid';
import { axe, toHaveNoViolations } from 'jest-axe';
import { fireEvent, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

import XUIModal from '../XUIModal';
import XUIModalHeader from '../XUIModalHeader';
import XUIModalHeading from '../XUIModalHeading';

jest.mock('nanoid');
nanoid.mockImplementation(() => 'generatedHeaderId');

expect.extend(toHaveNoViolations);

const NOOP = () => {};

const createComponent = props => (
  <XUIModal closeButtonLabel="Close" isUsingPortal={false} onClose={NOOP} {...props}>
    <XUIModalHeader>
      <XUIModalHeading qaHook="xui-modal--header-title">Test header</XUIModalHeading>
    </XUIModalHeader>
    <div>test</div>
  </XUIModal>
);

// NOTE: The esc key functionality has not been tested here as event listeners don't work very well in React testing
describe('XUIModal', () => {
  test('renders expected markup', () => {
    const { container } = render(
      createComponent({
        className: 'classyMcClassFace',
        closeClassName: 'closeClassyMcClassFace',
        id: 'test-modal',
        maskClassName: 'maskClassyMcClassFace',
        qaHook: 'xui-modal',
      }),
    );
    expect(container).toMatchSnapshot();
  });

  test('renders the appropriate heading tag when the headingLevel is set', () => {
    render(
      <XUIModal closeButtonLabel="Close" isOpen={true} isUsingPortal={false} onClose={NOOP}>
        <XUIModalHeader>
          <XUIModalHeading headingLevel={3}>Test header</XUIModalHeading>
        </XUIModalHeader>
        <div>test</div>
      </XUIModal>,
    );
    expect(screen.getByRole('heading', { level: 3 })).toBeInTheDocument();
  });

  test('renders the heading tag with an id when a modal heading component is provided', () => {
    render(
      <XUIModal closeButtonLabel="Close" isOpen={true} isUsingPortal={false} onClose={NOOP}>
        <XUIModalHeader id="test-modal-heading">
          <XUIModalHeading>Test header</XUIModalHeading>
        </XUIModalHeader>
        <div>test</div>
      </XUIModal>,
    );
    expect(screen.getByRole('heading')).toHaveAttribute('id', 'test-modal-heading');
  });

  test('renders the header with an id when no modal heading component is provided', () => {
    render(
      <XUIModal closeButtonLabel="Close" isOpen={true} isUsingPortal={false} onClose={NOOP}>
        <XUIModalHeader id="text-modal-heading">Test header text</XUIModalHeader>
        <div>test</div>
      </XUIModal>,
    );
    expect(screen.queryByRole('heading')).not.toBeInTheDocument();
    expect(screen.getByText(/Test header text/i)).toHaveAttribute('id', 'text-modal-heading');
  });

  test('renders using the heading id when id provided in both header and heading', () => {
    render(
      <XUIModal closeButtonLabel="Close" isOpen={true} isUsingPortal={false} onClose={NOOP}>
        <XUIModalHeader id="test-modal-heading">
          <XUIModalHeading id="modal-heading-test-id">Test header</XUIModalHeading>
        </XUIModalHeader>
        <div>test</div>
      </XUIModal>,
    );

    expect(screen.getByRole('banner')).toHaveAttribute('id', 'test-modal-heading');
    expect(screen.getByRole('heading')).toHaveAttribute('id', 'modal-heading-test-id');
    expect(screen.getByRole('dialog')).toHaveAttribute('aria-labelledby', 'modal-heading-test-id');
  });

  test('should pass accessibility testing', async () => {
    const { container } = render(createComponent());
    const results = await axe(container);
    expect(results).toHaveNoViolations();
  });

  test('Should correctly pass close handlers to the close button and mask', async () => {
    const onCloseMock = jest.fn();

    render(
      createComponent({
        hideOnOverlayClick: true,
        isOpen: true,
        onClose: onCloseMock,
        qaHook: 'test',
      }),
    );

    await userEvent.click(screen.getByTestId('test--mask'));
    expect(onCloseMock).toBeCalledTimes(1);

    await userEvent.click(screen.getByLabelText('Close'));
    expect(onCloseMock).toBeCalledTimes(2);
  });

  test('Should not fire onClose on mask click if hideOnOverlayClick is set to false', async () => {
    const onCloseMock = jest.fn();

    render(
      createComponent({
        hideOnOverlayClick: false,
        isOpen: true,
        onClose: onCloseMock,
        qaHook: 'test',
      }),
    );

    await userEvent.click(screen.getByTestId('test--mask'));
    expect(onCloseMock).not.toBeCalled();
  });

  test('Should not fire on close on click of the mask by default', async () => {
    const onCloseMock = jest.fn();

    render(
      createComponent({
        isOpen: true,
        onClose: onCloseMock,
        qaHook: 'test',
      }),
    );

    await userEvent.click(screen.getByTestId('test--mask'));
    expect(onCloseMock).not.toBeCalled();
  });

  test('Should add default layout classes if hasDefaultLayout is explicitly set to true ', function () {
    render(createComponent({ hasDefaultLayout: true, qaHook: 'test' }));
    expect(screen.getByTestId('test')).toHaveClass('xui-modal-layout');
  });

  test('Should not add default layout classes if hasDefaultLayout is set to false', function () {
    render(createComponent({ hasDefaultLayout: false, qaHook: 'test' }));
    expect(screen.getByTestId('test')).not.toHaveClass('xui-modal-layout');
  });

  test('Should render as a form when isForm is true', () => {
    const { container } = render(createComponent({ isForm: true, isOpen: true }));
    expect(container.querySelector('form')).toBeInTheDocument();
  });

  test('should not render as a form if isForm is set to false', () => {
    const { container } = render(createComponent({ isForm: false, isOpen: true }));
    expect(container.querySelector('form')).not.toBeInTheDocument();
  });

  test('should lock the scroll of a window when mounted and unlocked when unmounted', () => {
    const { rerender } = render(createComponent({ isOpen: true }));
    expect(document.querySelector('.xui-lockscroll')).toBeTruthy();

    rerender(createComponent({ isOpen: false }));
    expect(document.querySelector('.xui-lockscroll')).toBeFalsy();
  });

  test('should render closed by default', () => {
    render(createComponent({ qaHook: 'test' }));
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  });

  test('should render open when isOpen is set to true', () => {
    render(createComponent({ isOpen: true, qaHook: 'test' }));
    expect(screen.getByRole('dialog')).toBeInTheDocument();
  });

  test('should close the modal when escape is pressed', async () => {
    const onCloseMock = jest.fn();
    render(createComponent({ isOpen: true, onClose: onCloseMock }));

    await userEvent.keyboard('[Escape]');

    expect(onCloseMock).toHaveBeenCalledTimes(1);
  });

  test('removes the existing listener when the keyListenerTarget prop changes', () => {
    // Arrange
    const mockRemoveKeyListener = jest.fn();

    const { rerender } = render(
      createComponent({
        keyListenerTarget: { removeEventListener: mockRemoveKeyListener, addEventListener: NOOP },
      }),
    );

    // Act
    rerender(
      createComponent({ keyListenerTarget: { removeEventListener: NOOP, addEventListener: NOOP } }),
    );

    // Assert
    expect(mockRemoveKeyListener).toHaveBeenCalled();
  });

  test('adds a new listener when the keyListenerTarget prop changes', () => {
    const mockNewAddKeyListener = jest.fn();

    const { rerender } = render(
      createComponent({
        keyListenerTarget: {
          removeEventListener: NOOP,
          addEventListener: NOOP,
        },
      }),
    );

    // Act
    rerender(
      createComponent({
        keyListenerTarget: {
          removeEventListener: NOOP,
          addEventListener: mockNewAddKeyListener,
        },
      }),
    );

    // Assert
    expect(mockNewAddKeyListener).toHaveBeenCalled();
  });

  describe('Focus behaviour', () => {
    const createModal = () => (
      <XUIModal closeButtonLabel="Close" isOpen={true} isUsingPortal={false} onClose={NOOP}>
        <XUIModalHeader>Test header</XUIModalHeader>
        <button type="button">test</button>
      </XUIModal>
    );

    // TODO[XUI-3783]: Move initial focus to the first interactive control
    test('initial focus is on the modal itself', async () => {
      // Arrange
      render(createModal());

      // Assert
      expect(screen.getByRole('dialog')).toHaveFocus();
    });

    test('tabbing moves focus to the first interactive element inside the modal', async () => {
      // Arrange
      render(createModal());

      // Act
      await userEvent.tab();

      // Assert
      expect(screen.getByLabelText('Close')).toHaveFocus();
    });

    test('shift tabbing moves focus to the last interactive element inside the modal', async () => {
      // Arrange
      render(createModal());

      // Act
      await userEvent.tab({ shift: true });

      // Assert
      expect(screen.getByText('test')).toHaveFocus();
    });

    test('tabbing from the last interactive element in the modal moves focus to the first interactive element', async () => {
      // Arrange
      render(createModal());

      // Act
      fireEvent.focus(screen.getByText('test'));
      await userEvent.tab();

      // Assert
      expect(screen.getByLabelText('Close')).toHaveFocus();
    });

    test('shift tabbing from the first interactive element in the modal moves focus to the last interactive element', async () => {
      // Arrange
      render(createModal());

      // Act
      fireEvent.focus(screen.getByLabelText('Close'));
      await userEvent.tab({ shift: true });

      // Assert
      expect(screen.getByText('test')).toHaveFocus();
    });
  });
});

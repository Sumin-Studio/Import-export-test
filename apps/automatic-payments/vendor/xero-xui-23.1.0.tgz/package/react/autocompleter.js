"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIAutocompleter", {
  enumerable: true,
  get: function () {
    return _XUIAutocompleter.default;
  }
});
Object.defineProperty(exports, "XUIAutocompleterEmptyState", {
  enumerable: true,
  get: function () {
    return _XUIAutocompleterEmptyState.default;
  }
});
Object.defineProperty(exports, "XUIAutocompleterSecondarySearch", {
  enumerable: true,
  get: function () {
    return _XUIAutocompleterSecondarySearch.default;
  }
});
Object.defineProperty(exports, "boldMatch", {
  enumerable: true,
  get: function () {
    return _highlighting.boldMatch;
  }
});
Object.defineProperty(exports, "decorateSubStr", {
  enumerable: true,
  get: function () {
    return _highlighting.decorateSubStr;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIAutocompleter.default;
  }
});
var _highlighting = require("./components/autocompleter/helpers/highlighting");
var _XUIAutocompleter = _interopRequireDefault(require("./components/autocompleter/XUIAutocompleter"));
var _XUIAutocompleterEmptyState = _interopRequireDefault(require("./components/autocompleter/XUIAutocompleterEmptyState"));
var _XUIAutocompleterSecondarySearch = _interopRequireDefault(require("./components/autocompleter/XUIAutocompleterSecondarySearch"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=autocompleter.js.map
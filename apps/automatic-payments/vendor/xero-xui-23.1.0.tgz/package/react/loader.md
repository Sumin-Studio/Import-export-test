<div class="xui-margin-vertical">
	<a href="../section-components-identifiers-loader.html" isDocLink>Loader in the XUI Documentation</a>
</div>

## Examples

### Default Layout

`XUILoader` is given a layout class by default. This is good for putting in large empty states, like panels, while loading data.

Use the required `ariaLabel` prop to provide information to screen readers.

```jsx harmony
import XUILoader from '@xero/xui/react/loader';

<XUILoader ariaLabel="Loading" />;
```

### Disabled Layout

For more flexibility in styling and using Loaders in your application, set the prop `hasDefaultLayout` to `false`.

```jsx harmony
import XUILoader from '@xero/xui/react/loader';

<XUILoader ariaLabel="Loading" hasDefaultLayout={false} />;
```

### Sizes

Apart from the `medium` size, Loaders can also be `small` or `xsmall`.

```jsx harmony
import XUILoader from '@xero/xui/react/loader';

<XUILoader ariaLabel="Loading" hasDefaultLayout={false} size="medium" />;
```

### Inverted

Loaders support inverted backgrounds

```jsx harmony
import XUILoader from '@xero/xui/react/loader';
import ExampleContainer from './docs/ExampleContainer';

<ExampleContainer className="xui-padding-xsmall" isInverted>
  <XUILoader ariaLabel="Loading" isInverted />
</ExampleContainer>;
```

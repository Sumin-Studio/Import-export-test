import XUIIntroBanner, { type XUIIntroBannerProps } from './components/introbanner/XUIIntroBanner';
import XUIIntroBannerBody, { type XUIIntroBannerBodyProps } from './components/introbanner/XUIIntroBannerBody';
import XUIIntroBannerFooter, { type XUIIntroBannerFooterProps } from './components/introbanner/XUIIntroBannerFooter';
export { XUIIntroBanner as default, XUIIntroBanner, XUIIntroBannerBody, type XUIIntroBannerBodyProps, XUIIntroBannerFooter, type XUIIntroBannerFooterProps, type XUIIntroBannerProps, };

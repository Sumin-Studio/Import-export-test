import XUIAccordion, { type XUIAccordionProps } from './components/accordion/XUIAccordion';
import XUIAccordionItem, { type XUIAccordionItemProps } from './components/accordion/XUIAccordionItem';
export { XUIAccordion as default, XUIAccordion, XUIAccordionItem, type XUIAccordionItemProps, type XUIAccordionProps, };

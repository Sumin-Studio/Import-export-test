"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIRadio", {
  enumerable: true,
  get: function () {
    return _XUIRadio.default;
  }
});
Object.defineProperty(exports, "XUIRadioGroup", {
  enumerable: true,
  get: function () {
    return _XUIRadioGroup.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIRadio.default;
  }
});
var _XUIRadio = _interopRequireDefault(require("./components/radio/XUIRadio"));
var _XUIRadioGroup = _interopRequireDefault(require("./components/radio/XUIRadioGroup"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=radio.js.map
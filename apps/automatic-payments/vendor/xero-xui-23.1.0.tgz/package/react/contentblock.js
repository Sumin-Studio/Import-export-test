"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIContentBlock", {
  enumerable: true,
  get: function () {
    return _XUIContentBlock.default;
  }
});
Object.defineProperty(exports, "XUIContentBlockItem", {
  enumerable: true,
  get: function () {
    return _XUIContentBlockItem.default;
  }
});
var _XUIContentBlock = _interopRequireDefault(require("./components/contentblock/XUIContentBlock"));
var _XUIContentBlockItem = _interopRequireDefault(require("./components/contentblock/XUIContentBlockItem"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=contentblock.js.map
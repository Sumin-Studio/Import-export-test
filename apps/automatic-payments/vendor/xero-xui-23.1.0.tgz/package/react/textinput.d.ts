import XUITextInput, { type XUITextInputProps } from './components/textinput/XUITextInput';
import XUITextInputSideElement, { type XUITextInputSideElementProps } from './components/textinput/XUITextInputSideElement';
export { XUITextInput as default, XUITextInput, type XUITextInputProps, XUITextInputSideElement, type XUITextInputSideElementProps, };

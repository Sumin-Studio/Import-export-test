<div class="xui-margin-vertical">
	<a href="../section-components-collectinginput-forms.html" isDocLink>Form overview in the XUI Documentation</a>
</div>

`XUIForm` is a component that wraps a group of form inputs, and provides a React Context that sets default properties on the fields.

Note you must still markup the inputs as required where applicable.

## Examples

### Default

Default to indicating fields that are not required (optional) with `XUIForm`.

```js
import XUIForm from '@xero/xui/react/form';
import XUITextInput from '@xero/xui/react/textinput';

<XUIForm indicate="optional" optionalLabel="(Optional)" requiredLabel="(Required)">
  <XUITextInput label="Label" isFieldLayout />
  <XUITextInput isFieldLayout isRequired label="Label" />
</XUIForm>;
```

### Indicate required

<div class="xui-margin-vertical">
  <a href="../section-components-collectinginput-forms.html#components-collectinginput-forms-4-7-2" isDocLink>Optional and required labels in the XUI Documentation</a>
</div>

When the majority of fields are optional, defer to indicating required fields.

```js
import XUIForm from '@xero/xui/react/form';
import XUITextInput from '@xero/xui/react/textinput';

<XUIForm indicate="required" optionalLabel="(Optional)" requiredLabel="(Required)">
  <XUITextInput label="Label" isFieldLayout />
  <XUITextInput isFieldLayout isRequired label="Label" />
</XUIForm>;
```

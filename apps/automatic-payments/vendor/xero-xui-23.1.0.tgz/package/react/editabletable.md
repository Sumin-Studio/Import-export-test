<div class="xui-margin-vertical">
  <a href="../section-components-displayingdata-editabletable.html" isDocLink>Editable table in the XUI Documentation</a>
</div>

Editable tables are used to display sets of static or interactive data in a way that’s easy for the user to scan, organise, and manipulate.

Unlike `XUITable`, there is no `data` prop requirement for `XUIEditableTable`. Editable tables are structured much like their HTML equivalents using the following basic components:

| HTML element | XUI editable table component  |
| ------------ | ----------------------------- |
| `table`      | `XUIEditableTable`            |
| `thead`      | `XUIEditableTableHead`        |
| `tfoot`      | `XUIEditableTableFoot`        |
| `tbody`      | `XUIEditableTableBody`        |
| `th`         | `XUIEditableTableHeadingCell` |
| `tr`         | `XUIEditableTableRow`         |
| `td`         | `XUIEditableTableCell`        |

## Basic

The bare minimum table component requires `XUIEditableTable`, `XUIEditableTableBody`, and at least one `XUIEditableTableRow` with at least one `XUIEditableTableCell` type.

```jsx harmony
import {
  XUIEditableTable,
  XUIEditableTableBody,
  XUIEditableTableCellReadOnly,
  XUIEditableTableHead,
  XUIEditableTableHeadingCell,
  XUIEditableTableRow
} from '@xero/xui/react/editabletable';

const data = [
  {
    item: 'Golf balls - white',
    description: '9-pack of Bridgestone white golf balls.',
    taxRate: '15% GST on income'
  },
  {
    item: 'Tennis balls - yellow',
    description: '3-pack of yellow tennis balls.',
    taxRate: '20% GST on income'
  },
  {
    item: 'Rugby balls - brown',
    description: '2-pack of brown rugby balls.',
    taxRate: '10% GST on income'
  }
];

<XUIEditableTable ariaLabel="List of items with description and tax rate">
  <XUIEditableTableHead>
    <XUIEditableTableRow>
      <XUIEditableTableHeadingCell>Item</XUIEditableTableHeadingCell>
      <XUIEditableTableHeadingCell>Description</XUIEditableTableHeadingCell>
      <XUIEditableTableHeadingCell>Tax rate</XUIEditableTableHeadingCell>
    </XUIEditableTableRow>
  </XUIEditableTableHead>
  <XUIEditableTableBody>
    {data.map((row, index) => (
      <XUIEditableTableRow key={index}>
        <XUIEditableTableCellReadOnly>{row.item}</XUIEditableTableCellReadOnly>
        <XUIEditableTableCellReadOnly>{row.description}</XUIEditableTableCellReadOnly>
        <XUIEditableTableCellReadOnly>{row.taxRate}</XUIEditableTableCellReadOnly>
      </XUIEditableTableRow>
    ))}
  </XUIEditableTableBody>
</XUIEditableTable>;
```

import XUITab from './components/tabs/XUITab';
import XUITabList, { Orientation } from './components/tabs/XUITabList';
import XUITabListLabel from './components/tabs/XUITabListLabel';
import XUITabPanel from './components/tabs/XUITabPanel';
import XUITabPanels from './components/tabs/XUITabPanels';
import XUITabs, { Activation } from './components/tabs/XUITabs';
export { type Activation, XUITabs as default, type Orientation, XUITab, XUITabList, XUITabListLabel, XUITabPanel, XUITabPanels, XUITabs, };

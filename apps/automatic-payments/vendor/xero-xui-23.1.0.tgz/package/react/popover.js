"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIPopover", {
  enumerable: true,
  get: function () {
    return _XUIPopover.default;
  }
});
Object.defineProperty(exports, "XUIPopoverBody", {
  enumerable: true,
  get: function () {
    return _XUIPopoverBody.default;
  }
});
Object.defineProperty(exports, "XUIPopoverFooter", {
  enumerable: true,
  get: function () {
    return _XUIPopoverFooter.default;
  }
});
Object.defineProperty(exports, "XUIPopoverHeader", {
  enumerable: true,
  get: function () {
    return _XUIPopoverHeader.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIPopover.default;
  }
});
var _XUIPopover = _interopRequireDefault(require("./components/popover/XUIPopover"));
var _XUIPopoverBody = _interopRequireDefault(require("./components/popover/XUIPopoverBody"));
var _XUIPopoverFooter = _interopRequireDefault(require("./components/popover/XUIPopoverFooter"));
var _XUIPopoverHeader = _interopRequireDefault(require("./components/popover/XUIPopoverHeader"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=popover.js.map
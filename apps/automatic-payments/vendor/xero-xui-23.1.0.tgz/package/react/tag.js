"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUITag", {
  enumerable: true,
  get: function () {
    return _XUITag.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUITag.default;
  }
});
var _XUITag = _interopRequireDefault(require("./components/tag/XUITag"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=tag.js.map
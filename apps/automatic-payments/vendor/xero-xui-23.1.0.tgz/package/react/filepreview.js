"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIFilePreview", {
  enumerable: true,
  get: function () {
    return _XUIFilePreview.default;
  }
});
Object.defineProperty(exports, "XUIFilePreviewFooter", {
  enumerable: true,
  get: function () {
    return _XUIFilePreviewFooter.default;
  }
});
Object.defineProperty(exports, "XUIFilePreviewHeader", {
  enumerable: true,
  get: function () {
    return _XUIFilePreviewHeader.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIFilePreview.default;
  }
});
var _XUIFilePreview = _interopRequireDefault(require("./components/filepreview/XUIFilePreview"));
var _XUIFilePreviewFooter = _interopRequireDefault(require("./components/filepreview/XUIFilePreviewFooter"));
var _XUIFilePreviewHeader = _interopRequireDefault(require("./components/filepreview/XUIFilePreviewHeader"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=filepreview.js.map
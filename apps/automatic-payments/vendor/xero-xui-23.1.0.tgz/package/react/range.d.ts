import XUIRange, { type XUIRangeProps } from './components/range/XUIRange';
export { XUIRange as default, XUIRange, type XUIRangeProps };

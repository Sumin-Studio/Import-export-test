"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIProgressCircular", {
  enumerable: true,
  get: function () {
    return _XUIProgressCircular.default;
  }
});
Object.defineProperty(exports, "XUIProgressLinear", {
  enumerable: true,
  get: function () {
    return _XUIProgressLinear.default;
  }
});
exports.progressTypes = exports.default = void 0;
var _XUIProgressCircular = _interopRequireDefault(require("./components/progressindicator/XUIProgressCircular"));
var _XUIProgressLinear = _interopRequireDefault(require("./components/progressindicator/XUIProgressLinear"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Explicitly declaring the type here because of TS bug
const progressTypes = exports.progressTypes = exports.default = {
  XUIProgressLinear: _XUIProgressLinear.default,
  XUIProgressCircular: _XUIProgressCircular.default
};
//# sourceMappingURL=progressindicator.js.map
import XUIPanel, { type XUIPanelProps } from './components/panel/XUIPanel';
import XUIPanelFooter, { type XUIPanelFooterProps } from './components/panel/XUIPanelFooter';
import XUIPanelHeader, { type XUIPanelHeaderProps } from './components/panel/XUIPanelHeader';
import XUIPanelHeading, { type XUIPanelHeadingProps } from './components/panel/XUIPanelHeading';
import XUIPanelSection, { type XUIPanelSectionProps } from './components/panel/XUIPanelSection';
import XUIPanelSectionHeading, { type XUIPanelSectionHeadingProps } from './components/panel/XUIPanelSectionHeading';
export { XUIPanel as default, XUIPanel, XUIPanelFooter, type XUIPanelFooterProps, XUIPanelHeader, type XUIPanelHeaderProps, XUIPanelHeading, type XUIPanelHeadingProps, type XUIPanelProps, XUIPanelSection, XUIPanelSectionHeading, type XUIPanelSectionHeadingProps, type XUIPanelSectionProps, };

<div class="xui-margin-vertical">
	<a href="../section-components-collectinginput-dropdowns.html" isDocLink>Dropdown in the XUI Documentation</a>
</div>

A set of components used to associate a trigger (button, text input etc) with a popup containing content. It can handle any content such as [DatePickers](#datepicker) or forms. They provide the user similar behaviour to a native `<select />` element.

This is a set of components that can be used to associate a trigger (button, text input,etc) with a popup containing content.

XUIDropdown has a number of known accessibility issues of varying severity. If applicable consider using one of the following components instead:

- [Select box](#select-box): A styled implementation of a native `<select />` element. Use this when you have an expanding list of options that a user can choose a value from.
- [Autocompleter](#autocompleter): Like a select box but with a searchable text input that allows the user to search through and select from a list of items.

To use dropdowns, you should create a trigger element and a dropdown element, then pass both as props to `XUIDropdownToggled`.

### Terminology

Dropdowns are deceptively complex, so it's important to understand the terms used throughout this documentation.

#### Dropdown

This is the container for the elements that are conditionally shown on the page. It's a positioned element that floats on top of most other content. Examples of content include the selectable items in a `XUISelectBox` or the `XUIDatePicker` calendar paired up with a text input.

#### Trigger

The trigger is the element that the user interacts with to open or close the dropdown. Examples include the button that opens the selectable list in a `XUISelectBox` or the text input that users type into in order to search for items in `XUIAutocompleter`.

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUIAccordion", {
  enumerable: true,
  get: function () {
    return _XUIAccordion.default;
  }
});
Object.defineProperty(exports, "XUIAccordionItem", {
  enumerable: true,
  get: function () {
    return _XUIAccordionItem.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUIAccordion.default;
  }
});
var _XUIAccordion = _interopRequireDefault(require("./components/accordion/XUIAccordion"));
var _XUIAccordionItem = _interopRequireDefault(require("./components/accordion/XUIAccordionItem"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=accordion.js.map
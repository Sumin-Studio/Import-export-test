"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "XUILoader", {
  enumerable: true,
  get: function () {
    return _XUILoader.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _XUILoader.default;
  }
});
var _XUILoader = _interopRequireDefault(require("./components/loader/XUILoader"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=loader.js.map
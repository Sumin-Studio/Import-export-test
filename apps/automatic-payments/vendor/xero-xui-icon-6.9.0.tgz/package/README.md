xui-icon
========
[![build status](https://teamcity1.inside.xero-support.com/app/rest/builds/buildType:(id:XeroJS_SharedReactComponents_UxeXuiIcon)/statusIcon)](https://teamcity1.inside.xero-support.com/viewType.html?buildTypeId=XeroJS_XuiIcon)
![](https://img.shields.io/badge/XUI-^14.0.0-blue.svg)

## Usage

### NPM

To use the icons in React, you'll need to install the icon package in your project.

```bash
npm install --save @xero/xui-icon
```

Icons can then be imported via the `icons` subfolder.

```js
import accessibilityIcon from '@xero/xui-icon/icons/accessibility';
```

### React

To use the icons with React, import the `XUIIcon` component, and pass an imported icon object in using the `icon` prop.

```jsx
import accessibilityIcon from '@xero/xui-icon/icons/accessibility';
import XUIIcon from '@xero/xui/react/icon';

<XUIIcon icon={accessibilityIcon}/>
```

### Without React - Icon loader

This script replaces the icon blob from previous implementations of `xui-icon`. The advantage is that it inserts icons inline, so they can receive the correct height and width properties.

The icon loader script must be the last thing to be loaded to ensure icons are swapped in correctly.

```html
<script src="https://edge.xero.com/style/xui-icon/6.4.1/iconLoader.js"></script>
```

With this script included in the page, you can load icons into the page as you would have done previously using the icon blob.

```html
<svg focusable="false" class="xui-icon xui-u-rotate-270 xui-icon-blue" role="presentation">
	<use xlink:href="#xui-icon-arrow-small" />
</svg>
```

The svg element will then be replaced by an inline version of the `arrow-small` icon, with correct height and width attributes applied.

You can apply an icon wrapper if you want a fixed width and height that is not specific to the size of each individual icon

```html
<div>
	<div class="xui-iconwrapper xui-iconwrapper-large">
		<svg focusable="false" class="xui-icon xui-icon-large"  role="presentation">
			<use xlink:href="#xui-icon-arrow" />
		</svg>
	</div>
	<div class="xui-iconwrapper">
		<svg focusable="false" class="xui-icon" role="presentation">
			<use xlink:href="#xui-icon-arrow" />
		</svg>
	</div>
</div>
```

### Without React - Vanilla JS

You can import data (the icon path, width and height) for individual icons from the `icons` or `icons-es6` directory and use the
`createSVGElement` utility function to render them to the DOM if you're not using a library
like React. You can also set a class on the svg element by passing a `class` option.

#### ES6 Export Syntax
```js
import menu from '@xero/xui-icon/icons-es6/menu';
import createSVGElement from '@xero/xui-icon/src/createSVGElement';

const svg = createSVGElement({...menu, class: 'xui-icon'});
document.body.appendChild(svg);
```

#### CommonJS Export Syntax
```js
const menu = require('@xero/xui-icon/icons/menu');
const createSVGElement = require('@xero/xui-icon/lib/createSVGElement');

const svg = createSVGElement(menu);
document.body.appendChild(svg);
```
**Note:** If you're using Babel or Webpack yourself, you can use import syntax to include the
babeled output as well.

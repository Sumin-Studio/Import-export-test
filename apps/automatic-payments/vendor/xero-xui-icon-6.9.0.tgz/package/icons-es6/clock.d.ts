declare const clockIcon: { width: number; height: number; path: string; };
export default clockIcon;

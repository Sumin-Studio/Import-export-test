declare const attachIcon: { width: number; height: number; path: string; };
export default attachIcon;

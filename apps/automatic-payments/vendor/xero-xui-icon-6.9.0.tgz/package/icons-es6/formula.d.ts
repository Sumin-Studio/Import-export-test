declare const formulaIcon: { width: number; height: number; path: string; };
export default formulaIcon;

declare const listIcon: { width: number; height: number; path: string; };
export default listIcon;

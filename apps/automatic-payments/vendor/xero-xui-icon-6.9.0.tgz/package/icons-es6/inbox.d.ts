declare const inboxIcon: { width: number; height: number; path: string; };
export default inboxIcon;

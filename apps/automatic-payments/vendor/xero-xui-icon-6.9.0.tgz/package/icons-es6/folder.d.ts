declare const folderIcon: { width: number; height: number; path: string; };
export default folderIcon;

declare const copyIcon: { width: number; height: number; path: string; };
export default copyIcon;

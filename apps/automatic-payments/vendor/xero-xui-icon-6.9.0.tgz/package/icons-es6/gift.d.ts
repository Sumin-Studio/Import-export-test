declare const giftIcon: { width: number; height: number; path: string; };
export default giftIcon;

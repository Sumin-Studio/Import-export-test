declare const fileSpreadsheetIcon: { width: number; height: number; path: string; };
export default fileSpreadsheetIcon;

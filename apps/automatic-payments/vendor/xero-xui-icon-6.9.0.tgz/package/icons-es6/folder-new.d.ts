declare const folderNewIcon: { width: number; height: number; path: string; };
export default folderNewIcon;

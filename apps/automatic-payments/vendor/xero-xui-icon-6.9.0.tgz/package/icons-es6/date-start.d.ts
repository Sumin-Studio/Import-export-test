declare const dateStartIcon: { width: number; height: number; path: string; };
export default dateStartIcon;

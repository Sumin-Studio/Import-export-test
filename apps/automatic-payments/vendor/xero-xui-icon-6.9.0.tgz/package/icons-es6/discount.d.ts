declare const discountIcon: { width: number; height: number; path: string; };
export default discountIcon;

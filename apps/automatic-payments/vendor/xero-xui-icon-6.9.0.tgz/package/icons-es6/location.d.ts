declare const locationIcon: { width: number; height: number; path: string; };
export default locationIcon;

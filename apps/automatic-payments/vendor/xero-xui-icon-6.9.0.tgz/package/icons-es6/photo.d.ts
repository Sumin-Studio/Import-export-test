declare const photoIcon: { width: number; height: number; path: string; };
export default photoIcon;

declare const recentIcon: { width: number; height: number; path: string; };
export default recentIcon;

declare const fileDocumentIcon: { width: number; height: number; path: string; };
export default fileDocumentIcon;

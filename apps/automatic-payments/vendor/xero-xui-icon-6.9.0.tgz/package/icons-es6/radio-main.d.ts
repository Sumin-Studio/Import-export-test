declare const radioMainIcon: { width: number; height: number; path: string; };
export default radioMainIcon;

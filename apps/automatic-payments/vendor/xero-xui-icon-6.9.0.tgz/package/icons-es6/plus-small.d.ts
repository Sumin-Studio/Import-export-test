declare const plusSmallIcon: { width: number; height: number; path: string; };
export default plusSmallIcon;

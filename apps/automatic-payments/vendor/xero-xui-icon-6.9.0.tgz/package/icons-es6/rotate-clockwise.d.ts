declare const rotateClockwiseIcon: { width: number; height: number; path: string; };
export default rotateClockwiseIcon;

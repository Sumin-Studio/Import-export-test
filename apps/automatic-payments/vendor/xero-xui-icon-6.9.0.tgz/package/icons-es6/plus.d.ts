declare const plusIcon: { width: number; height: number; path: string; };
export default plusIcon;

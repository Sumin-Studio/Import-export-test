declare const downIcon: { width: number; height: number; path: string; };
export default downIcon;

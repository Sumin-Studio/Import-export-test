declare const imageIcon: { width: number; height: number; path: string; };
export default imageIcon;

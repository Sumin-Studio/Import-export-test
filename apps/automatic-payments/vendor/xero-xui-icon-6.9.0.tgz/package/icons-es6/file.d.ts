declare const fileIcon: { width: number; height: number; path: string; };
export default fileIcon;

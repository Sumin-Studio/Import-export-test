declare const menuIcon: { width: number; height: number; path: string; };
export default menuIcon;

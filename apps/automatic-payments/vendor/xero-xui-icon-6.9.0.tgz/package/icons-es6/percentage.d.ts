declare const percentageIcon: { width: number; height: number; path: string; };
export default percentageIcon;

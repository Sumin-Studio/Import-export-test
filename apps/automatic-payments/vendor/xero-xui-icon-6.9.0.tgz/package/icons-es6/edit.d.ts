declare const editIcon: { width: number; height: number; path: string; };
export default editIcon;

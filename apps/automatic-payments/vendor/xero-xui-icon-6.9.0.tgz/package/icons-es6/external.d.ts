declare const externalIcon: { width: number; height: number; path: string; };
export default externalIcon;

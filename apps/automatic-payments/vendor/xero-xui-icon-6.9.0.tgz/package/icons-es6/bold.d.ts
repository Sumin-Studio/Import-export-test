declare const boldIcon: { width: number; height: number; path: string; };
export default boldIcon;

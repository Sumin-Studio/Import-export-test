declare const dateEndIcon: { width: number; height: number; path: string; };
export default dateEndIcon;

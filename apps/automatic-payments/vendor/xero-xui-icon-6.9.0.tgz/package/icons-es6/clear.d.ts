declare const clearIcon: { width: number; height: number; path: string; };
export default clearIcon;

declare const bookmarkIcon: { width: number; height: number; path: string; };
export default bookmarkIcon;

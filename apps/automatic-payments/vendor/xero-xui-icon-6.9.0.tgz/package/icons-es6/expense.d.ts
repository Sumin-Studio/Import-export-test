declare const expenseIcon: { width: number; height: number; path: string; };
export default expenseIcon;

declare const gotoIcon: { width: number; height: number; path: string; };
export default gotoIcon;

declare const shieldIcon: { width: number; height: number; path: string; };
export default shieldIcon;

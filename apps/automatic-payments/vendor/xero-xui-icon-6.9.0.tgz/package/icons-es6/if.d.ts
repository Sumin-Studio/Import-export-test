declare const ifIcon: { width: number; height: number; path: string; };
export default ifIcon;

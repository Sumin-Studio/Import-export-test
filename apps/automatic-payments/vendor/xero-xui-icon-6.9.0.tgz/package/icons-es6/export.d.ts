declare const exportIcon: { width: number; height: number; path: string; };
export default exportIcon;

declare const additionIcon: { width: number; height: number; path: string; };
export default additionIcon;

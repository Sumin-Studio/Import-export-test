declare const hashIcon: { width: number; height: number; path: string; };
export default hashIcon;

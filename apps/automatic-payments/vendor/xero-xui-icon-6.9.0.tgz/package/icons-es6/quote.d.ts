declare const quoteIcon: { width: number; height: number; path: string; };
export default quoteIcon;

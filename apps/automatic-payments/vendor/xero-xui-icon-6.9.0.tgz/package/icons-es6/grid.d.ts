declare const gridIcon: { width: number; height: number; path: string; };
export default gridIcon;

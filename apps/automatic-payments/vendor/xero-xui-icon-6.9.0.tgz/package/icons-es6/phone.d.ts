declare const phoneIcon: { width: number; height: number; path: string; };
export default phoneIcon;

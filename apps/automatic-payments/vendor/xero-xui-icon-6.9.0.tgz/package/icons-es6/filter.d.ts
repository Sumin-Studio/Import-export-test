declare const filterIcon: { width: number; height: number; path: string; };
export default filterIcon;

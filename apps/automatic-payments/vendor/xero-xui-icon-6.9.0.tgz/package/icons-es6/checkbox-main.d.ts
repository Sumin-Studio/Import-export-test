declare const checkboxMainIcon: { width: number; height: number; path: string; };
export default checkboxMainIcon;

declare const mergeIcon: { width: number; height: number; path: string; };
export default mergeIcon;

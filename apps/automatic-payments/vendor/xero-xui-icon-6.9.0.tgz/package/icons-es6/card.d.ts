declare const cardIcon: { width: number; height: number; path: string; };
export default cardIcon;

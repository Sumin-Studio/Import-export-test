declare const depositIcon: { width: number; height: number; path: string; };
export default depositIcon;

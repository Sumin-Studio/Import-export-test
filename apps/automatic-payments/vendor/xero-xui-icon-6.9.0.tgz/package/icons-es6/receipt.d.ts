declare const receiptIcon: { width: number; height: number; path: string; };
export default receiptIcon;

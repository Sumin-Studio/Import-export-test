declare const invalidIcon: { width: number; height: number; path: string; };
export default invalidIcon;

declare const radioCheckIcon: { width: number; height: number; path: string; };
export default radioCheckIcon;

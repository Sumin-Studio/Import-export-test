declare const expandIcon: { width: number; height: number; path: string; };
export default expandIcon;

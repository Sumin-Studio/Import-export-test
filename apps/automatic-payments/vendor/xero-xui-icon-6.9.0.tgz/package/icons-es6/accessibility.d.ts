declare const accessibilityIcon: { width: number; height: number; path: string; };
export default accessibilityIcon;

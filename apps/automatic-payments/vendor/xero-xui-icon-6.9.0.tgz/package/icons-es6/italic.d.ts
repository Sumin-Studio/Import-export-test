declare const italicIcon: { width: number; height: number; path: string; };
export default italicIcon;

declare const printIcon: { width: number; height: number; path: string; };
export default printIcon;

declare const footerIcon: { width: number; height: number; path: string; };
export default footerIcon;

declare const divisionIcon: { width: number; height: number; path: string; };
export default divisionIcon;

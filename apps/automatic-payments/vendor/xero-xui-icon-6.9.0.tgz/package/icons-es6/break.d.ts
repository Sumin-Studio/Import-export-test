declare const breakIcon: { width: number; height: number; path: string; };
export default breakIcon;

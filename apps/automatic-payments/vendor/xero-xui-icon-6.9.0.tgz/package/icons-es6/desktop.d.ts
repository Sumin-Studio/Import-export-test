declare const desktopIcon: { width: number; height: number; path: string; };
export default desktopIcon;

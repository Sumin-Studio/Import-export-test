declare const fileExcelIcon: { width: number; height: number; path: string; };
export default fileExcelIcon;

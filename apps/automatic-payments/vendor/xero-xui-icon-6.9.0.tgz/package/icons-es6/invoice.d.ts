declare const invoiceIcon: { width: number; height: number; path: string; };
export default invoiceIcon;

declare const exclamationIcon: { width: number; height: number; path: string; };
export default exclamationIcon;

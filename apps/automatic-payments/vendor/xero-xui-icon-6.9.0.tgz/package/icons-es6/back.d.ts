declare const backIcon: { width: number; height: number; path: string; };
export default backIcon;

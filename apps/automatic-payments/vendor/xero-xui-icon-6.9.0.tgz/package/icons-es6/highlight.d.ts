declare const highlightIcon: { width: number; height: number; path: string; };
export default highlightIcon;

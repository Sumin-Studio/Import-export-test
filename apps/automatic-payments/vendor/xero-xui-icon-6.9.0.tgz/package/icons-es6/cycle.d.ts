declare const cycleIcon: { width: number; height: number; path: string; };
export default cycleIcon;

declare const commentIcon: { width: number; height: number; path: string; };
export default commentIcon;

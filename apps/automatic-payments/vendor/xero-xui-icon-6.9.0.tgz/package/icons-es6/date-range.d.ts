declare const dateRangeIcon: { width: number; height: number; path: string; };
export default dateRangeIcon;

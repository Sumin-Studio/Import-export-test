declare const mobileIcon: { width: number; height: number; path: string; };
export default mobileIcon;

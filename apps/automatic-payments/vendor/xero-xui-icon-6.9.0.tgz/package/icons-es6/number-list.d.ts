declare const numberListIcon: { width: number; height: number; path: string; };
export default numberListIcon;

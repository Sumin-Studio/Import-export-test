declare const documentIcon: { width: number; height: number; path: string; };
export default documentIcon;

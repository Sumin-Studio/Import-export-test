declare const equalsIcon: { width: number; height: number; path: string; };
export default equalsIcon;

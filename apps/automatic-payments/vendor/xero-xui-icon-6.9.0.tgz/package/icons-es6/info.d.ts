declare const infoIcon: { width: number; height: number; path: string; };
export default infoIcon;

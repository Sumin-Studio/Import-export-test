declare const projectIcon: { width: number; height: number; path: string; };
export default projectIcon;

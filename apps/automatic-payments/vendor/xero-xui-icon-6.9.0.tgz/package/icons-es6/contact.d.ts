declare const contactIcon: { width: number; height: number; path: string; };
export default contactIcon;

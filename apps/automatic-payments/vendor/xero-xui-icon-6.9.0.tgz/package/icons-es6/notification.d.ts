declare const notificationIcon: { width: number; height: number; path: string; };
export default notificationIcon;

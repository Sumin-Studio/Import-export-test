declare const bankIcon: { width: number; height: number; path: string; };
export default bankIcon;

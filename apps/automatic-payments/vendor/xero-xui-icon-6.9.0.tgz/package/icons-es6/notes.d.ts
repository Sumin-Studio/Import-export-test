declare const notesIcon: { width: number; height: number; path: string; };
export default notesIcon;

declare const dragIcon: { width: number; height: number; path: string; };
export default dragIcon;

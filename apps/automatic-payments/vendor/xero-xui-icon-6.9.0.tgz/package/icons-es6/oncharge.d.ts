declare const onchargeIcon: { width: number; height: number; path: string; };
export default onchargeIcon;

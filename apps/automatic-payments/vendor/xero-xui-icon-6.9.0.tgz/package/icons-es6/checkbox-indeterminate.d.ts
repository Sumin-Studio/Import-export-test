declare const checkboxIndeterminateIcon: { width: number; height: number; path: string; };
export default checkboxIndeterminateIcon;

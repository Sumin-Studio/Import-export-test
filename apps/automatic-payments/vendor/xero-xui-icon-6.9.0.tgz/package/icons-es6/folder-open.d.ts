declare const folderOpenIcon: { width: number; height: number; path: string; };
export default folderOpenIcon;

declare const rowIcon: { width: number; height: number; path: string; };
export default rowIcon;

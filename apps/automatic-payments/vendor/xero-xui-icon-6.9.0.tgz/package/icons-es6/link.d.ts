declare const linkIcon: { width: number; height: number; path: string; };
export default linkIcon;

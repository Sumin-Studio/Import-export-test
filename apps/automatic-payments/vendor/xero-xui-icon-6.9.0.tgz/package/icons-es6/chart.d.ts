declare const chartIcon: { width: number; height: number; path: string; };
export default chartIcon;

declare const caretIcon: { width: number; height: number; path: string; };
export default caretIcon;

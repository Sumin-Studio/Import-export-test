declare const configureIcon: { width: number; height: number; path: string; };
export default configureIcon;

declare const emailIcon: { width: number; height: number; path: string; };
export default emailIcon;

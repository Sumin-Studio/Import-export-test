declare const currencyIcon: { width: number; height: number; path: string; };
export default currencyIcon;

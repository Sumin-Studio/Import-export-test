declare const paymentIcon: { width: number; height: number; path: string; };
export default paymentIcon;

declare const crossIcon: { width: number; height: number; path: string; };
export default crossIcon;

declare const educationIcon: { width: number; height: number; path: string; };
export default educationIcon;

declare const archiveIcon: { width: number; height: number; path: string; };
export default archiveIcon;

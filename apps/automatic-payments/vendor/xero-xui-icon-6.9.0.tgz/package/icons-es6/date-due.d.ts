declare const dateDueIcon: { width: number; height: number; path: string; };
export default dateDueIcon;

declare const fileZipIcon: { width: number; height: number; path: string; };
export default fileZipIcon;

declare const searchIcon: { width: number; height: number; path: string; };
export default searchIcon;

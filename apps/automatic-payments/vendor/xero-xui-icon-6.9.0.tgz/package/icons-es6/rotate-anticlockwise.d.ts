declare const rotateAnticlockwiseIcon: { width: number; height: number; path: string; };
export default rotateAnticlockwiseIcon;

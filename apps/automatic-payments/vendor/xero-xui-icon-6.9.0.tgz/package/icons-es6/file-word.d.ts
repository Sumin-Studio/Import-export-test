declare const fileWordIcon: { width: number; height: number; path: string; };
export default fileWordIcon;

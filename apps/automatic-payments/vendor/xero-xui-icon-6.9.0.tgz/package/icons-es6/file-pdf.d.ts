declare const filePdfIcon: { width: number; height: number; path: string; };
export default filePdfIcon;

declare const checkCircleIcon: { width: number; height: number; path: string; };
export default checkCircleIcon;

declare const columnIcon: { width: number; height: number; path: string; };
export default columnIcon;

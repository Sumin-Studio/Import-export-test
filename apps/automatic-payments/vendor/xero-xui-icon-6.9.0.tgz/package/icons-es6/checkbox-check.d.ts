declare const checkboxCheckIcon: { width: number; height: number; path: string; };
export default checkboxCheckIcon;

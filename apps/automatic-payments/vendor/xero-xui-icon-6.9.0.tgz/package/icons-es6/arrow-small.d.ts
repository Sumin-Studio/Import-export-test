declare const arrowSmallIcon: { width: number; height: number; path: string; };
export default arrowSmallIcon;

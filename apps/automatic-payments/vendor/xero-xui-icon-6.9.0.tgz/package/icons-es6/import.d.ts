declare const importIcon: { width: number; height: number; path: string; };
export default importIcon;

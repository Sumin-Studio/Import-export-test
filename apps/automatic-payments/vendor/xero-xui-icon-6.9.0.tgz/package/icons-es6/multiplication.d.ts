declare const multiplicationIcon: { width: number; height: number; path: string; };
export default multiplicationIcon;

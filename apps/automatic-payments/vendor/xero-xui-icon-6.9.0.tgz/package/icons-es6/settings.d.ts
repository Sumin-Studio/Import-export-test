declare const settingsIcon: { width: number; height: number; path: string; };
export default settingsIcon;

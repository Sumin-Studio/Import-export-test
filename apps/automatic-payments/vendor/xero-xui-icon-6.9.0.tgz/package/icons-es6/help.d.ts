declare const helpIcon: { width: number; height: number; path: string; };
export default helpIcon;

declare const fileCsvIcon: { width: number; height: number; path: string; };
export default fileCsvIcon;

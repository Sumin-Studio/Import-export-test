declare const crossSmallIcon: { width: number; height: number; path: string; };
export default crossSmallIcon;

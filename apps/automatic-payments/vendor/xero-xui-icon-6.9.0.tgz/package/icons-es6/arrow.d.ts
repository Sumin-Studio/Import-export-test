declare const arrowIcon: { width: number; height: number; path: string; };
export default arrowIcon;

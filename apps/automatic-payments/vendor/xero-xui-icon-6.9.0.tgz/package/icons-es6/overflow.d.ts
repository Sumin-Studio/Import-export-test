declare const overflowIcon: { width: number; height: number; path: string; };
export default overflowIcon;

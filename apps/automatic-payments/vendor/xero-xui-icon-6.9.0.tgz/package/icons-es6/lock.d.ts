declare const lockIcon: { width: number; height: number; path: string; };
export default lockIcon;

declare const bulletListIcon: { width: number; height: number; path: string; };
export default bulletListIcon;
